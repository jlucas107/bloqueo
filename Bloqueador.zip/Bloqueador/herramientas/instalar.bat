@echo off
setlocal EnableDelayedExpansion
title Instalador de Bloqueador
cd /d "%~dp0"
set "PKG=com.example.bloqueador"
set "SVC=com.example.bloqueador/com.example.bloqueador.BlockerService"
set "DNS=family.adguard-dns.com"

echo ==========================================================
echo   Instalador de Bloqueador
echo ==========================================================
echo.
echo Antes de seguir, en el celular:
echo   1. Ajustes - Acerca del telefono - toca 7 veces "Numero de compilacion"
echo   2. Ajustes - Opciones de desarrollador - activa "Depuracion USB"
echo      En Xiaomi activa tambien "Depuracion USB - ajustes de seguridad"
echo   3. Conecta el celular a este PC con el cable USB
echo.

rem ---------- Buscar adb ----------
set "ADBDIR="
if exist "%~dp0adb.exe" set "ADBDIR=%~dp0"
if not defined ADBDIR if exist "%~dp0platform-tools\adb.exe" set "ADBDIR=%~dp0platform-tools\"
if not defined ADBDIR if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "ADBDIR=%LOCALAPPDATA%\Android\Sdk\platform-tools\"
if not defined ADBDIR if exist "C:\platform-tools\adb.exe" set "ADBDIR=C:\platform-tools\"
if defined ADBDIR set "PATH=%ADBDIR%;%PATH%"
where adb >nul 2>&1
if errorlevel 1 goto no_adb

adb start-server >nul 2>&1
echo Esperando el celular... si en la pantalla sale "Permitir depuracion USB", toca Permitir.
adb wait-for-device
echo Celular conectado.
echo.

rem ---------- 1. Instalar el APK ----------
set "APK="
for %%f in ("%~dp0*.apk") do set "APK=%%~ff"
if not defined APK goto check_installed
echo [1/6] Instalando "!APK!" ...
adb install -r "!APK!"
if errorlevel 1 (
  echo     No se pudo instalar. Si dice INSTALL_FAILED_UPDATE_INCOMPATIBLE, la version
  echo     instalada tiene otra firma: desinstalala primero desde el celular.
  goto end
)
goto installed

:check_installed
echo [1/6] No hay ningun .apk en esta carpeta, se usa la app ya instalada.
adb shell pm path %PKG% | findstr /c:"package:" >nul
if errorlevel 1 (
  echo     Bloqueador no esta instalado. Pon el archivo .apk junto a este instalar.bat.
  goto end
)

:installed
rem ---------- 2. Ajustes restringidos (Android 13+) ----------
echo [2/6] Permitiendo ajustes restringidos...
adb shell appops set %PKG% ACCESS_RESTRICTED_SETTINGS allow >nul 2>&1

rem ---------- 3. Permiso especial ----------
echo [3/6] Dando el permiso especial...
adb shell pm grant %PKG% android.permission.WRITE_SECURE_SETTINGS
adb shell dumpsys package %PKG% | findstr /c:"WRITE_SECURE_SETTINGS: granted=true" >nul
if errorlevel 1 (
  echo     NO se pudo dar el permiso especial. En Xiaomi activa "Depuracion USB - ajustes de seguridad".
  set "GRANT_OK=0"
) else (
  echo     Permiso especial: OK
  set "GRANT_OK=1"
)

rem ---------- 4. Bateria ----------
echo [4/6] Quitando restricciones de bateria...
adb shell dumpsys deviceidle whitelist +%PKG% >nul 2>&1

rem ---------- 5. Accesibilidad ----------
echo [5/6] Activando la Accesibilidad de Bloqueador...
set "CUR="
for /f "delims=" %%s in ('adb shell settings get secure enabled_accessibility_services') do set "CUR=%%s"
if /i "!CUR!"=="null" set "CUR="
echo !CUR! | findstr /i /c:"%PKG%" >nul
if not errorlevel 1 goto acc_done
if "!CUR!"=="" (set "NEW=%SVC%") else (set "NEW=!CUR!:%SVC%")
adb shell settings put secure enabled_accessibility_services "!NEW!"
adb shell settings put secure accessibility_enabled 1
:acc_done
echo     Accesibilidad: OK

rem ---------- 6. DNS familiar ----------
echo.
choice /c SN /m "[6/6] Poner el DNS familiar %DNS% (bloquea adultos en todas las apps)"
if errorlevel 2 goto dns_done
adb shell settings put global private_dns_mode hostname
adb shell settings put global private_dns_specifier %DNS%
echo     DNS familiar: OK
:dns_done

rem ---------- Opcional: propietario del dispositivo ----------
echo.
echo OPCIONAL Y AVANZADO: propietario del dispositivo. Bloquea modo seguro y restablecimiento.
echo Solo funciona si quitaste TODAS las cuentas del celular. Si no, responde N.
choice /c SN /d N /t 30 /m "Intentar propietario del dispositivo"
if errorlevel 2 goto open_app
adb shell dpm set-device-owner %PKG%/.AdminReceiver
echo     Si arriba dice Success, ya puedes volver a anadir tus cuentas.

:open_app
echo.
adb shell am start -n %PKG%/.MainActivity >nul 2>&1
echo ==========================================================
echo  Listo. Se abrio Bloqueador en el celular: termina el asistente
echo  y activa el modo estricto en la pestana Proteccion.
echo ==========================================================
goto end

:no_adb
echo No encontre adb.
echo Descarga "SDK Platform-Tools para Windows" de developer.android.com,
echo descomprimelo y pon la carpeta platform-tools junto a este instalar.bat.

:end
echo.
pause
