package com.example.bloqueador

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

/**
 * Autorreparación de Accesibilidad.
 *
 * Android no permite que una app impida que apaguen su servicio de accesibilidad.
 * Lo que sí se puede: si la app tiene el permiso WRITE_SECURE_SETTINGS (se concede una sola
 * vez por ADB), el servicio se vuelve a encender solo en el mismo instante en que lo apagan.
 */
object Guard {

    const val ADB_COMMAND =
        "adb shell pm grant com.example.bloqueador android.permission.WRITE_SECURE_SETTINGS"

    fun canWriteSecure(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED

    /** Enciende el servicio escribiendo el ajuste del sistema. Devuelve false si no se pudo. */
    fun enableService(ctx: Context): Boolean {
        if (!canWriteSecure(ctx)) return false
        return try {
            val cr = ctx.contentResolver
            val cn = ComponentName(ctx, BlockerService::class.java)
            val full = cn.flattenToString()
            val short = cn.flattenToShortString()
            val current = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            val already = current.split(':').any { it.equals(full, true) || it.equals(short, true) }
            if (!already) {
                val updated = if (current.isBlank()) full else "$current:$full"
                Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, updated)
            }
            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Con el modo estricto activo, si el servicio quedó apagado lo vuelve a encender. */
    fun reviveIfNeeded(ctx: Context) {
        if (!StrictMode.isEnabled(ctx)) return
        if (isServiceEnabled(ctx)) return
        enableService(ctx)
    }
}
