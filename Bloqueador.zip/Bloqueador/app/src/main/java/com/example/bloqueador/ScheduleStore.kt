package com.example.bloqueador

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ScheduleStore {
    private const val PREFS = "bloqueador"
    private const val KEY = "schedules"

    // Nunca bloqueamos Ajustes para que no te quedes sin poder desactivar el servicio.
    val NEVER_BLOCK = setOf("com.android.settings")

    fun load(ctx: Context): List<Schedule> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Schedule(
                id = o.getString("id"),
                name = o.getString("name"),
                days = o.getJSONArray("days").toIntSet(),
                startMin = o.getInt("start"),
                endMin = o.getInt("end"),
                packages = o.getJSONArray("packages").toStringSet(),
                enabled = o.optBoolean("enabled", true)
            )
        }
    }

    fun save(ctx: Context, list: List<Schedule>) {
        val arr = JSONArray()
        list.forEach { s ->
            arr.put(JSONObject().apply {
                put("id", s.id)
                put("name", s.name)
                put("days", JSONArray(s.days.toList()))
                put("start", s.startMin)
                put("end", s.endMin)
                put("packages", JSONArray(s.packages.toList()))
                put("enabled", s.enabled)
            })
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    /** Devuelve el horario activo ahora mismo que bloquea [pkg], o null si no hay. */
    fun activeScheduleFor(ctx: Context, pkg: String): Schedule? {
        if (pkg in NEVER_BLOCK) return null
        val now = TrustedClock.now(ctx)
        return load(ctx).firstOrNull { pkg in it.packages && it.isActiveAt(now) }
    }

    private fun JSONArray.toIntSet() = (0 until length()).map { getInt(it) }.toSet()
    private fun JSONArray.toStringSet() = (0 until length()).map { getString(it) }.toSet()
}
