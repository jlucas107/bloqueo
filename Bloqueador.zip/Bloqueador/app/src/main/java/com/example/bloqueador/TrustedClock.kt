package com.example.bloqueador

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Hora que NO depende de lo que el usuario ponga en Ajustes.
 *
 * Guarda un "ancla": (hora real, SystemClock.elapsedRealtime). elapsedRealtime es un
 * contador que no cambia aunque el usuario modifique la fecha/hora del teléfono, así que
 * hora_confiable = hora_real_del_ancla + tiempo_transcurrido.
 * El ancla se renueva con la hora de internet cada vez que hay conexión.
 * Tras reiniciar, el contador vuelve a 0: hasta poder sincronizar se usa la hora del sistema.
 */
object TrustedClock {
    private const val PREFS = "trusted_clock"
    private val syncing = AtomicBoolean(false)
    @Volatile private var lastAttempt = 0L

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun bootCount(ctx: Context): Int =
        try {
            Settings.Global.getInt(ctx.contentResolver, Settings.Global.BOOT_COUNT)
        } catch (e: Exception) {
            -1
        }

    @Synchronized
    private fun setAnchor(ctx: Context, wallMillis: Long) {
        prefs(ctx).edit()
            .putLong("wall", wallMillis)
            .putLong("elapsed", SystemClock.elapsedRealtime())
            .putInt("boot", bootCount(ctx))
            .apply()
    }

    @Synchronized
    fun nowMillis(ctx: Context): Long {
        val p = prefs(ctx)
        val wall = p.getLong("wall", 0L)
        val elapsed = p.getLong("elapsed", 0L)
        val boot = p.getInt("boot", -2)
        val cur = SystemClock.elapsedRealtime()
        if (wall > 0 && boot == bootCount(ctx) && cur >= elapsed) {
            return wall + (cur - elapsed)
        }
        // Primer uso o reinicio: confiamos en el reloj del sistema hasta poder sincronizar.
        val sys = System.currentTimeMillis()
        setAnchor(ctx, sys)
        return sys
    }

    fun now(ctx: Context): LocalDateTime =
        LocalDateTime.ofInstant(Instant.ofEpochMilli(nowMillis(ctx)), ZoneId.systemDefault())

    /** Sincroniza con internet en segundo plano (como máximo cada 30 min; si falla, reintenta en 5). */
    fun maybeSync(ctx: Context, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && lastAttempt != 0L && now - lastAttempt < 30 * 60 * 1000L) return
        if (!syncing.compareAndSet(false, true)) return
        lastAttempt = now
        val app = ctx.applicationContext
        Thread {
            try {
                val t = fetchNetworkTime()
                if (t != null) {
                    setAnchor(app, t)
                } else {
                    lastAttempt = SystemClock.elapsedRealtime() - 25 * 60 * 1000L
                }
            } finally {
                syncing.set(false)
            }
        }.start()
    }

    private fun fetchNetworkTime(): Long? {
        for (u in listOf("https://www.google.com/generate_204", "https://www.cloudflare.com")) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.requestMethod = "HEAD"
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.instanceFollowRedirects = false
                val d = c.date
                c.disconnect()
                if (d > 0) return d
            } catch (e: Exception) {
                // probamos el siguiente servidor
            }
        }
        return null
    }
}
