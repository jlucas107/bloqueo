package com.example.bloqueador

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/**
 * Copia de la configuración (horarios, sitios bloqueados y filtro de adultos) en un archivo .json,
 * para llevarla a otro celular. Las contraseñas NO se copian.
 *
 * Importar solo AÑADE: nunca borra horarios ni sitios ni apaga el filtro, así que no sirve
 * para saltarse el modo estricto.
 */
object ConfigBackup {
    class Result(val schedules: Int, val sites: Int)

    fun export(ctx: Context): String {
        val arr = JSONArray()
        ScheduleStore.load(ctx).forEach { s ->
            arr.put(JSONObject().apply {
                put("id", s.id)
                put("name", s.name)
                put("days", JSONArray(s.days.toList()))
                put("start", s.startMin)
                put("end", s.endMin)
                put("packages", JSONArray(s.packages.toList()))
                put("enabled", s.enabled)
            })
        }
        return JSONObject().apply {
            put("app", "Bloqueador")
            put("version", 1)
            put("schedules", arr)
            put("sites", JSONArray(WebFilter.customSites(ctx)))
            put("adult", WebFilter.adultEnabled(ctx))
        }.toString(2)
    }

    /** Devuelve lo que se añadió, o null si el archivo no es una copia de Bloqueador. */
    fun importText(ctx: Context, text: String): Result? {
        val o = try { JSONObject(text) } catch (e: Exception) { return null }
        if (o.optString("app") != "Bloqueador") return null

        val current = ScheduleStore.load(ctx)
        val known = current.map { it.id }.toSet()
        val added = mutableListOf<Schedule>()
        val arr = o.optJSONArray("schedules") ?: JSONArray()
        for (i in 0 until arr.length()) {
            try {
                val s = arr.getJSONObject(i)
                val id = s.getString("id")
                if (id in known) continue
                val days = s.getJSONArray("days")
                val pk = s.getJSONArray("packages")
                added += Schedule(
                    id = id,
                    name = s.optString("name"),
                    days = (0 until days.length()).map { days.getInt(it) }.toSet(),
                    startMin = s.getInt("start"),
                    endMin = s.getInt("end"),
                    packages = (0 until pk.length()).map { pk.getString(it) }.toSet(),
                    enabled = s.optBoolean("enabled", true)
                )
            } catch (e: Exception) {
                // se salta ese horario
            }
        }
        if (added.isNotEmpty()) ScheduleStore.save(ctx, current + added)

        val before = WebFilter.customSites(ctx).toSet()
        val sites = o.optJSONArray("sites") ?: JSONArray()
        var newSites = 0
        for (i in 0 until sites.length()) {
            val h = WebFilter.addSite(ctx, sites.optString(i)) ?: continue
            if (h !in before) newSites++
        }
        if (o.optBoolean("adult", false)) WebFilter.setAdultEnabled(ctx, true)
        return Result(added.size, newSites)
    }

    fun write(ctx: Context, uri: Uri): Boolean =
        try {
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(export(ctx).toByteArray()) }
            true
        } catch (e: Exception) {
            false
        }

    fun read(ctx: Context, uri: Uri): Result? =
        try {
            val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            if (text == null) null else importText(ctx, text)
        } catch (e: Exception) {
            null
        }
}
