package com.example.bloqueador

import android.content.Context
import android.os.Build
import android.os.UserManager

/**
 * Modo «propietario del dispositivo» (Device Owner).
 *
 * Se activa UNA vez desde el computador con adb:
 *   adb shell dpm set-device-owner com.example.bloqueador/.AdminReceiver
 *
 * Con el modo estricto activo, Android mismo impide (no depende de la Accesibilidad):
 *  - arrancar en modo seguro, restablecer de fábrica desde Ajustes, añadir o cambiar de usuario,
 *  - desinstalar Bloqueador, forzar su detención o borrar sus datos,
 *  - cambiar la fecha y la hora, configurar VPN y (opcional) cambiar el DNS privado,
 *  - (opcional) usar opciones de desarrollador / adb.
 * Al desactivar el modo estricto (tras la espera de 24 h) todo se levanta.
 */
object DeviceOwner {
    const val DNS_HOST = "family.adguard-dns.com"
    const val ADB_COMMAND = "adb shell dpm set-device-owner com.example.bloqueador/.AdminReceiver"

    private fun p(ctx: Context) = ctx.getSharedPreferences("device_owner", Context.MODE_PRIVATE)

    fun isOwner(ctx: Context): Boolean =
        try {
            dpm(ctx).isDeviceOwnerApp(ctx.packageName)
        } catch (e: Exception) {
            false
        }

    /** Fijar el DNS privado familiar y no dejar cambiarlo (activado por defecto). */
    fun forceDns(ctx: Context): Boolean = p(ctx).getBoolean("force_dns", true)
    fun setForceDns(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("force_dns", v).apply()

    /** Bloquear opciones de desarrollador y adb (desactivado por defecto). */
    fun blockDebug(ctx: Context): Boolean = p(ctx).getBoolean("block_debug", false)
    fun setBlockDebug(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("block_debug", v).apply()

    private fun restrictions(ctx: Context): List<String> {
        val list = mutableListOf(
            UserManager.DISALLOW_SAFE_BOOT,
            UserManager.DISALLOW_FACTORY_RESET,
            UserManager.DISALLOW_APPS_CONTROL,
            UserManager.DISALLOW_CONFIG_VPN,
            UserManager.DISALLOW_ADD_USER
        )
        if (Build.VERSION.SDK_INT >= 28) {
            list += UserManager.DISALLOW_CONFIG_DATE_TIME
            list += UserManager.DISALLOW_USER_SWITCH
        }
        if (Build.VERSION.SDK_INT >= 29 && forceDns(ctx)) list += UserManager.DISALLOW_CONFIG_PRIVATE_DNS
        if (blockDebug(ctx)) list += UserManager.DISALLOW_DEBUGGING_FEATURES
        return list
    }

    /** Todas las que esta app puede poner (para levantarlas sin dejar ninguna). */
    private fun allRestrictions(): List<String> {
        val list = mutableListOf(
            UserManager.DISALLOW_SAFE_BOOT,
            UserManager.DISALLOW_FACTORY_RESET,
            UserManager.DISALLOW_APPS_CONTROL,
            UserManager.DISALLOW_CONFIG_VPN,
            UserManager.DISALLOW_ADD_USER,
            UserManager.DISALLOW_DEBUGGING_FEATURES
        )
        if (Build.VERSION.SDK_INT >= 28) {
            list += UserManager.DISALLOW_CONFIG_DATE_TIME
            list += UserManager.DISALLOW_USER_SWITCH
        }
        if (Build.VERSION.SDK_INT >= 29) list += UserManager.DISALLOW_CONFIG_PRIVATE_DNS
        return list
    }

    /** Pone las restricciones del modo estricto. Se puede llamar muchas veces. */
    fun apply(ctx: Context) {
        if (!isOwner(ctx)) return
        val d = dpm(ctx)
        val admin = adminComponent(ctx)
        val wanted = restrictions(ctx)
        // Las opcionales que se apagaron se quitan.
        for (r in allRestrictions() - wanted.toSet()) {
            try { d.clearUserRestriction(admin, r) } catch (e: Exception) { }
        }
        for (r in wanted) {
            try { d.addUserRestriction(admin, r) } catch (e: Exception) {
                DebugLog.add("no se pudo poner $r")
            }
        }
        try { d.setUninstallBlocked(admin, ctx.packageName, true) } catch (e: Exception) { }
        if (Build.VERSION.SDK_INT >= 30) {
            try { d.setAutoTimeEnabled(admin, true) } catch (e: Exception) { }
        }
        if (Build.VERSION.SDK_INT >= 29 && forceDns(ctx)) {
            val app = ctx.applicationContext
            // Android comprueba el servidor por red: no se puede hacer en el hilo principal.
            Thread {
                try {
                    val r = dpm(app).setGlobalPrivateDnsModeSpecifiedHost(adminComponent(app), DNS_HOST)
                    DebugLog.add("DNS privado fijado (resultado $r)")
                } catch (e: Exception) {
                    DebugLog.add("DNS privado: ${e.javaClass.simpleName}")
                }
            }.start()
        }
        DebugLog.add("propietario: ${wanted.size} restricciones activas")
    }

    /** Quita todas las restricciones (al desactivar el modo estricto). El DNS se deja como está. */
    fun release(ctx: Context) {
        if (!isOwner(ctx)) return
        val d = dpm(ctx)
        val admin = adminComponent(ctx)
        for (r in allRestrictions()) {
            try { d.clearUserRestriction(admin, r) } catch (e: Exception) { }
        }
        try { d.setUninstallBlocked(admin, ctx.packageName, false) } catch (e: Exception) { }
    }

    /** Deja de ser propietario del dispositivo. Solo con el modo estricto apagado. */
    fun removeOwner(ctx: Context): Boolean {
        if (!isOwner(ctx) || StrictMode.isEnabled(ctx)) return false
        release(ctx)
        return try {
            dpm(ctx).clearDeviceOwnerApp(ctx.packageName)
            true
        } catch (e: Exception) {
            false
        }
    }
}
