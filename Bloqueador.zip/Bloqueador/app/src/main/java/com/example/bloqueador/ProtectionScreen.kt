@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.bloqueador

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay

@Composable
fun ProtectionScreen(
    modifier: Modifier,
    serviceOn: Boolean,
    adminOn: Boolean,
    strictOn: Boolean,
    onOpenSetup: () -> Unit,
    onChanged: () -> Unit
) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var dialog by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var cleanRecents by remember { mutableStateOf(Prefs.cleanRecents(ctx)) }
    var logTick by remember { mutableStateOf(0) }
    val logLines = remember(logTick) { DebugLog.snapshot() }

    // Se refresca cada 30 s (cuenta atrás) y al volver a la app (p. ej. desde Ajustes).
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            tick++
        }
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val pending = remember(tick, strictOn, dialog) { StrictMode.pending(ctx) }
    val batteryOk = remember(tick) { Battery.isExempt(ctx) }
    val dnsRead = remember(tick) { familyDnsActive(ctx) }
    val dnsOk = dnsRead ?: Prefs.dnsManual(ctx)
    val alerts = remember(tick, adminOn, serviceOn) {
        Tamper.checkAdmin(ctx)
        Tamper.alerts(ctx)
    }
    var chosenWait by remember { mutableStateOf(StrictMode.waitMs(ctx)) }
    val waitText = StrictMode.formatDuration(if (strictOn) StrictMode.waitMs(ctx) else chosenWait)

    var backupMsg by remember { mutableStateOf<String?>(null) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) backupMsg = if (ConfigBackup.write(ctx, uri)) "Configuración exportada." else "No se pudo guardar el archivo."
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val r = ConfigBackup.read(ctx, uri)
            backupMsg = if (r == null) "Ese archivo no es una copia de Bloqueador."
            else "Importados: ${r.schedules} horario(s) y ${r.sites} sitio(s)."
            onChanged()
        }
    }

    val layers = listOf(
        Layer("Accesibilidad", serviceOn),
        Layer("Batería", batteryOk),
        Layer("Anti-desinstalación", adminOn),
        Layer("DNS familiar", dnsOk),
        Layer("Modo estricto", strictOn)
    )

    Column(modifier.fillMaxSize()) {
        ScreenHeader("Protección", "Para que nadie pueda saltarse los bloqueos.") {
            Spacer(Modifier.height(16.dp))
            ProtectionMeter(layers)
        }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (alerts.isNotEmpty()) {
                item {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.errorContainer).padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            "Alguien se saltó la protección",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        alerts.forEach {
                            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                        if (strictOn && !adminOn) {
                            Text(
                                "Vuelve a activar la anti-desinstalación ahora.",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        TextButton(onClick = { Tamper.clear(ctx); tick++ }) { Text("Entendido") }
                    }
                }
            }

            // ---- Las capas, en el mismo orden que el medidor
            item {
                SurfaceCard(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {
                    LayerRow(
                        ok = serviceOn, title = "Accesibilidad",
                        desc = if (serviceOn) "Detecta y cierra las apps y páginas bloqueadas."
                        else "Sin esto no se bloquea nada."
                    ) {
                        if (!serviceOn) Button(onClick = {
                            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }) { Text("Activar") }
                    }
                    SoftDivider()
                    LayerRow(
                        ok = batteryOk, title = "Batería sin restricciones",
                        desc = if (batteryOk) "El teléfono no dormirá a Bloqueador."
                        else "Si el teléfono la duerme, el bloqueo deja de funcionar."
                    ) {
                        if (!batteryOk) Button(onClick = { Battery.request(ctx) }) { Text("Permitir") }
                    }
                    SoftDivider()
                    LayerRow(
                        ok = adminOn, title = "Anti-desinstalación",
                        desc = if (adminOn) "Android no deja desinstalar la app." else "Evita que la app se pueda desinstalar."
                    ) {
                        if (!adminOn) {
                            Button(onClick = { ctx.startActivity(adminIntent(ctx)) }) { Text("Activar") }
                        } else if (!strictOn) {
                            TextButton(onClick = {
                                dpm(ctx).removeActiveAdmin(adminComponent(ctx))
                                onChanged()
                            }) { Text("Quitar") }
                        }
                    }
                    SoftDivider()
                    LayerRow(
                        ok = dnsOk, title = "DNS familiar",
                        desc = if (dnsOk) "Filtra contenido para adultos en todas las apps."
                        else if (strictOn) "Con el modo estricto activo la pantalla del DNS está protegida."
                        else "Filtra contenido para adultos en todas las apps, no solo en el navegador."
                    ) {
                        if (!dnsOk && !strictOn) Button(onClick = { dialog = "dns" }) { Text("Configurar") }
                    }
                }
            }

            // ---- Modo estricto
            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StateGlyph(strictOn)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Modo estricto", style = MaterialTheme.typography.titleLarge)
                            Text(
                                when {
                                    strictOn -> "Activo. Desactivarlo tarda $waitText."
                                    !adminOn -> "Primero activa la anti-desinstalación."
                                    else -> "Pide contraseña y protege Ajustes, la hora y el DNS."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    if (!strictOn) {
                        Text("Espera para poder desactivarlo", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StrictMode.WAIT_OPTIONS.forEach { (ms, label) ->
                                FilterChip(
                                    selected = chosenWait == ms,
                                    onClick = { chosenWait = ms },
                                    label = { Text(label) }
                                )
                            }
                        }
                        Text(
                            "1 min es solo para pruebas. Con el modo activo no se puede cambiar.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            enabled = adminOn,
                            onClick = { dialog = "set" },
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) { Text("Activar modo estricto") }
                    } else {
                        when (val pd = pending) {
                            is StrictMode.Pending.Waiting -> {
                                CountdownBox(
                                    big = StrictMode.formatDuration(pd.remainingMs),
                                    text = "para poder desactivarlo. Mientras tanto todo sigue protegido."
                                )
                                Spacer(Modifier.height(10.dp))
                                OutlinedButton(
                                    onClick = { StrictMode.cancelRequest(ctx); tick++ },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Cancelar solicitud") }
                            }
                            is StrictMode.Pending.Ready -> {
                                CountdownBox(
                                    big = "Ya puedes",
                                    text = "Pasó la espera de $waitText. Tienes ${StrictMode.formatDuration(pd.remainingMs)} " +
                                        "para confirmarlo; si no, la solicitud caduca."
                                )
                                Spacer(Modifier.height(10.dp))
                                Button(onClick = { dialog = "unset" }, modifier = Modifier.fillMaxWidth()) {
                                    Text("Desactivar ahora")
                                }
                                TextButton(
                                    onClick = { StrictMode.cancelRequest(ctx); tick++ },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Mantenerlo activo") }
                            }
                            else -> {
                                OutlinedButton(
                                    onClick = { dialog = "request" },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Pedir desactivación") }
                            }
                        }
                    }
                }
            }

            // ---- Llevar a otro celular
            item {
                SurfaceCard {
                    Text("Llevar a otro celular", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        backupMsg ?: "Guarda tus horarios y sitios en un archivo y cárgalo en el otro celular. " +
                            "Importar solo añade, nunca borra. La contraseña no se copia.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = { exporter.launch("bloqueador_config.json") }) { Text("Exportar") }
                        FilledTonalButton(onClick = { importer.launch(arrayOf("application/json", "text/plain", "*/*")) }) {
                            Text("Importar")
                        }
                    }
                }
            }

            // ---- Ajustes menores
            item {
                SurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Quitar de recientes", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Al bloquear una app, también intenta sacarla de las apps recientes. Puede variar según el teléfono.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Switch(checked = cleanRecents, onCheckedChange = { cleanRecents = it; Prefs.setCleanRecents(ctx, it) })
                    }
                }
            }

            item {
                SurfaceCard {
                    Text("Diagnóstico", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Lo que el servicio ha detectado últimamente. Útil si algo no se bloquea.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (logLines.isEmpty()) "Sin eventos todavía. Usa el teléfono y vuelve a tocar «Actualizar»."
                        else logLines.joinToString("\n"),
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp)
                    )
                    Row {
                        TextButton(onClick = { logTick++ }) { Text("Actualizar") }
                        TextButton(onClick = { clipboard.setText(AnnotatedString(logLines.joinToString("\n"))) }) { Text("Copiar") }
                        TextButton(onClick = { DebugLog.clear(); logTick++ }) { Text("Borrar") }
                    }
                }
            }

            item {
                TextButton(onClick = onOpenSetup, modifier = Modifier.fillMaxWidth()) {
                    Text("Abrir el asistente de configuración")
                }
            }
        }
    }

    // ---------------------------------------------------------------- Diálogos

    if (dialog == "dns") {
        AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text("DNS familiar") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("En Ajustes → Conexiones (o Red e internet) → DNS privado, elige «Nombre de host del proveedor» y pega:")
                    Text(
                        WebFilter.FAMILY_DNS,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp)
                    )
                    if (dnsRead == null) {
                        Text(
                            "Este teléfono no deja comprobarlo: cuando lo hayas puesto, toca «Ya lo puse».",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    clipboard.setText(AnnotatedString(WebFilter.FAMILY_DNS))
                    openNetworkSettings(ctx)
                }) { Text("Copiar y abrir Ajustes") }
            },
            dismissButton = {
                if (dnsRead == null) {
                    TextButton(onClick = { Prefs.setDnsManual(ctx, true); dialog = ""; tick++ }) { Text("Ya lo puse") }
                } else {
                    TextButton(onClick = { dialog = "" }) { Text("Cerrar") }
                }
            }
        )
    }
    if (dialog == "set") {
        PasswordDialog("Crea una contraseña", true, error, "Activar", {
            dialog = ""
            error = null
        }) { a, b ->
            if (a.length < 4) {
                error = "Usa al menos 4 caracteres."
            } else if (a != b) {
                error = "Las contraseñas no coinciden."
            } else {
                StrictMode.enable(ctx, a, chosenWait)
                dialog = ""
                error = null
                onChanged()
            }
        }
    }
    if (dialog == "request") {
        PasswordDialog("Pedir desactivación", false, error, "Pedir", {
            dialog = ""
            error = null
        }) { a, _ ->
            if (StrictMode.requestDisable(ctx, a)) {
                dialog = ""
                error = null
                tick++
            } else {
                error = "Contraseña incorrecta."
            }
        }
    }
    if (dialog == "unset") {
        PasswordDialog("Contraseña para desactivar", false, error, "Desactivar", {
            dialog = ""
            error = null
        }) { a, _ ->
            if (StrictMode.disableIfReady(ctx, a)) {
                dialog = ""
                error = null
                onChanged()
            } else if (StrictMode.pending(ctx) !is StrictMode.Pending.Ready) {
                dialog = ""
                error = null
                tick++
            } else {
                error = "Contraseña incorrecta."
            }
        }
    }
}

fun openNetworkSettings(ctx: android.content.Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
    } catch (e: Exception) {
        ctx.startActivity(Intent(Settings.ACTION_SETTINGS))
    }
}

@Composable
private fun LayerRow(ok: Boolean, title: String, desc: String, action: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        StateGlyph(ok, size = 36.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(8.dp))
        action()
    }
}

/** Cuenta atrás de la desactivación: el número grande es lo único que importa aquí. */
@Composable
private fun CountdownBox(big: String, text: String) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Noche).padding(18.dp)
    ) {
        Text(big, style = MaterialTheme.typography.displaySmall, color = androidx.compose.ui.graphics.Color.White)
        Text(text, style = MaterialTheme.typography.bodySmall, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.72f))
    }
}
