@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.bloqueador

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun ProtectionScreen(
    modifier: Modifier,
    serviceOn: Boolean,
    adminOn: Boolean,
    strictOn: Boolean,
    onOpenSetup: () -> Unit,
    onChanged: () -> Unit
) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var cleanRecents by remember { mutableStateOf(Prefs.cleanRecents(ctx)) }
    var logTick by remember { mutableStateOf(0) }
    val logLines = remember(logTick) { DebugLog.snapshot() }
    val clipboard = LocalClipboardManager.current

    // Estado de la solicitud de desactivación; se refresca cada 30 s para la cuenta atrás.
    var pendingTick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            pendingTick++
        }
    }
    val pending = remember(pendingTick, strictOn, dialog) { StrictMode.pending(ctx) }

    // Al volver a la app (p. ej. desde el diálogo de batería) se refresca todo.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) pendingTick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val batteryOk = remember(pendingTick) { Battery.isExempt(ctx) }
    val isOwner = remember(pendingTick, strictOn) { DeviceOwner.isOwner(ctx) }
    val alerts = remember(pendingTick, adminOn, serviceOn) {
        Tamper.checkAdmin(ctx)
        Tamper.alerts(ctx)
    }
    var forceDns by remember { mutableStateOf(DeviceOwner.forceDns(ctx)) }
    // Espera para desactivar, elegida antes de activar el modo estricto.
    var chosenWait by remember { mutableStateOf(StrictMode.waitMs(ctx)) }
    val waitText = StrictMode.formatDuration(if (strictOn) StrictMode.waitMs(ctx) else chosenWait)
    val elevated = remember(pendingTick) { Elevated.has(ctx) }
    var backupMsg by remember { mutableStateOf<String?>(null) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) backupMsg = if (ConfigBackup.write(ctx, uri)) "Configuración exportada." else "No se pudo guardar el archivo."
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val r = ConfigBackup.read(ctx, uri)
            backupMsg = if (r == null) "Ese archivo no es una copia de Bloqueador."
            else "Importados: ${r.schedules} horario(s) y ${r.sites} sitio(s)."
            onChanged()
        }
    }
    var blockDebug by remember { mutableStateOf(DeviceOwner.blockDebug(ctx)) }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Protección", style = MaterialTheme.typography.headlineLarge)
                Text(
                    "Para que nadie pueda saltarse los bloqueos.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                TextButton(onClick = onOpenSetup, contentPadding = PaddingValues(0.dp)) {
                    Text("Abrir el asistente de configuración")
                }
            }
        }

        if (alerts.isNotEmpty()) {
            item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.errorContainer).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        "Alguien se saltó la protección",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    alerts.forEach {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                    if (strictOn && !adminOn) {
                        Text(
                            "Vuelve a activar la anti-desinstalación ahora.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                    TextButton(onClick = { Tamper.clear(ctx); pendingTick++ }) { Text("Entendido") }
                }
            }
        }

        item {
            SurfaceCard(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {
                StatusRow(
                    ok = serviceOn,
                    title = "Accesibilidad",
                    desc = if (serviceOn) "Activa: detecta y bloquea las apps."
                    else "Necesaria para que el bloqueo funcione."
                ) {
                    if (!serviceOn) {
                        FilledTonalButton(onClick = {
                            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }) { Text("Activar") }
                    }
                }
                SoftDivider()
                StatusRow(
                    ok = batteryOk,
                    title = "Batería sin restricciones",
                    desc = if (batteryOk) "El teléfono no apagará a Bloqueador para ahorrar batería."
                    else "Sin esto, el teléfono puede dormir a Bloqueador y el bloqueo deja de funcionar."
                ) {
                    if (!batteryOk) {
                        FilledTonalButton(onClick = { Battery.request(ctx) }) { Text("Permitir") }
                    }
                }
                SoftDivider()
                StatusRow(
                    ok = adminOn,
                    title = "Anti-desinstalación",
                    desc = if (adminOn) "Android no deja desinstalar la app."
                    else "Evita que la app se pueda desinstalar."
                ) {
                    if (!adminOn) {
                        FilledTonalButton(onClick = { ctx.startActivity(adminIntent(ctx)) }) { Text("Activar") }
                    } else if (!strictOn && !isOwner) {
                        TextButton(onClick = {
                            dpm(ctx).removeActiveAdmin(adminComponent(ctx))
                            onChanged()
                        }) { Text("Quitar") }
                    }
                }
                SoftDivider()
                StatusRow(
                    ok = strictOn,
                    title = "Modo estricto",
                    desc = when {
                        strictOn -> "Contraseña, hora y Ajustes protegidos."
                        !adminOn -> "Primero activa la anti-desinstalación."
                        else -> "Pide contraseña y protege Ajustes y la hora."
                    }
                ) {
                    if (!strictOn) {
                        FilledTonalButton(enabled = adminOn, onClick = { dialog = "set" }) { Text("Activar") }
                    } else if (pending == StrictMode.Pending.None) {
                        TextButton(onClick = { dialog = "request" }) { Text("Desactivar") }
                    }
                }
                if (!strictOn) {
                    Text(
                        "Espera para desactivarlo (1 min es solo para pruebas)",
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.padding(start = 54.dp)
                    )
                    Row(
                        Modifier.padding(start = 54.dp, bottom = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StrictMode.WAIT_OPTIONS.forEach { (ms, label) ->
                            FilterChip(
                                selected = chosenWait == ms,
                                onClick = { chosenWait = ms },
                                label = { Text(label) }
                            )
                        }
                    }
                } else {
                    Text(
                        "Desactivarlo tarda $waitText.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 54.dp, bottom = 10.dp)
                    )
                }
            }
        }

        if (strictOn && pending != StrictMode.Pending.None) {
            item {
                SurfaceCard {
                    when (val pd = pending) {
                        is StrictMode.Pending.Waiting -> {
                            Text("Desactivación solicitada", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Podrás desactivar el modo estricto en ${StrictMode.formatDuration(pd.remainingMs)}. " +
                                    "Mientras tanto todo sigue protegido. Si cambias de opinión, cancela la solicitud.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(8.dp))
                            FilledTonalButton(onClick = {
                                StrictMode.cancelRequest(ctx)
                                pendingTick++
                            }) { Text("Cancelar solicitud") }
                        }
                        is StrictMode.Pending.Ready -> {
                            Text("Ya puedes desactivarlo", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Pasó la espera de $waitText. Tienes ${StrictMode.formatDuration(pd.remainingMs)} " +
                                    "para confirmarlo; después la solicitud caduca y el modo estricto sigue activo.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { dialog = "unset" }) { Text("Desactivar ahora") }
                                TextButton(onClick = {
                                    StrictMode.cancelRequest(ctx)
                                    pendingTick++
                                }) { Text("Mantener activo") }
                            }
                        }
                        else -> {}
                    }
                }
            }
        }

        item {
            SurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StateGlyph(elevated)
                    Spacer(Modifier.width(14.dp))
                    Text("Permiso especial (opcional)", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    if (elevated) "Activo. Con el modo estricto, si alguien apaga la Accesibilidad se vuelve a encender sola, " +
                        "y se mantienen el DNS familiar" + (if (forceDns) "" else " (apagado abajo)") + " y la hora automática."
                    else "Si alguien apaga la Accesibilidad, Bloqueador la vuelve a encender sola. No hace falta quitar cuentas. " +
                        "Se da una vez desde el PC con instalar.bat (o con este comando):",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (!elevated) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        Elevated.GRANT_COMMAND,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant).padding(10.dp)
                    )
                    TextButton(onClick = { clipboard.setText(AnnotatedString(Elevated.GRANT_COMMAND)) }) {
                        Text("Copiar comando")
                    }
                } else if (!isOwner) {
                    OptionRow(
                        "Fijar DNS familiar (${DeviceOwner.DNS_HOST})",
                        "Bloquea contenido para adultos en TODAS las apps.",
                        forceDns, enabled = !strictOn
                    ) { forceDns = it; DeviceOwner.setForceDns(ctx, it) }
                }
            }
        }

        item {
            SurfaceCard {
                Text("Llevar a otro celular", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    backupMsg ?: "Guarda tus horarios y sitios bloqueados en un archivo y cárgalo en el otro celular. " +
                        "Importar solo añade, nunca borra. La contraseña no se copia.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row {
                    TextButton(onClick = { exporter.launch("bloqueador_config.json") }) { Text("Exportar") }
                    TextButton(onClick = { importer.launch(arrayOf("application/json", "text/plain", "*/*")) }) { Text("Importar") }
                }
            }
        }

        item {
            SurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StateGlyph(isOwner)
                    Spacer(Modifier.width(14.dp))
                    Text("Propietario del dispositivo (avanzado)", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(6.dp))
                if (!isOwner) {
                    Text(
                        "La protección más fuerte: con el modo estricto, Android no deja arrancar en modo seguro, " +
                            "restablecer de fábrica desde Ajustes, desinstalar ni detener Bloqueador, cambiar la hora, " +
                            "usar otra VPN ni cambiar el DNS. Se activa una sola vez con adb desde el computador:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "1. Ajustes → Cuentas: quita TODAS las cuentas (Google, Samsung…). Luego las vuelves a añadir.\n" +
                            "2. Activa la depuración USB y conecta el teléfono.\n" +
                            "3. En el computador ejecuta:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        DeviceOwner.ADB_COMMAND,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant).padding(10.dp)
                    )
                    TextButton(onClick = { clipboard.setText(AnnotatedString(DeviceOwner.ADB_COMMAND)) }) {
                        Text("Copiar comando")
                    }
                } else {
                    Text(
                        if (strictOn) "Activo: Android protege el modo seguro, el restablecimiento, la desinstalación, la hora, la VPN" +
                            (if (forceDns) " y el DNS." else ".")
                        else "Listo. Las protecciones se encienden al activar el modo estricto.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    OptionRow(
                        "Fijar DNS familiar (${DeviceOwner.DNS_HOST})",
                        "Bloquea contenido para adultos en TODAS las apps y obliga a usar SafeSearch.",
                        forceDns, enabled = !strictOn
                    ) { forceDns = it; DeviceOwner.setForceDns(ctx, it) }
                    OptionRow(
                        "Bloquear opciones de desarrollador",
                        "Impide usar adb para saltarse el bloqueo. Para volver a usar adb tendrás que desactivar el modo estricto ($waitText).",
                        blockDebug, enabled = !strictOn
                    ) { blockDebug = it; DeviceOwner.setBlockDebug(ctx, it) }
                    if (strictOn) {
                        Text(
                            "Estas opciones solo se cambian con el modo estricto apagado.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        TextButton(onClick = { dialog = "owner" }) { Text("Dejar de ser propietario") }
                    }
                }
            }
        }

        item {
            SurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Quitar de recientes", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "Al bloquear una app, además de cerrarla, intenta sacarla de la lista de apps recientes. Es experimental y puede variar según el teléfono.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Switch(
                        checked = cleanRecents,
                        onCheckedChange = { cleanRecents = it; Prefs.setCleanRecents(ctx, it) }
                    )
                }
            }
        }

        item {
            SurfaceCard {
                Text("Diagnóstico", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Servicio: ${if (serviceOn) "activo" else "apagado"} · Modo estricto: ${if (strictOn) "sí" else "no"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    if (logLines.isEmpty()) "Sin eventos todavía. Abre Ajustes y vuelve aquí a pulsar «Actualizar»."
                    else logLines.joinToString("\n"),
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant).padding(10.dp)
                )
                Row {
                    TextButton(onClick = { logTick++ }) { Text("Actualizar") }
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(logLines.joinToString("\n")))
                    }) { Text("Copiar") }
                    TextButton(onClick = { DebugLog.clear(); logTick++ }) { Text("Borrar") }
                }
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    Icons.Filled.Info, contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    "Con el modo estricto activo, si entras en Ajustes a la pantalla de Accesibilidad de Bloqueador (o a cualquiera que muestre «Bloqueador»), la app la cierra y te manda al inicio. Tampoco podrás cambiar la fecha y la hora ni el DNS privado. Para quitarlo, entra a la app con tu contraseña y pide la desactivación: se hace efectiva tras la espera ($waitText).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
    }

    if (dialog == "set") {
        PasswordDialog("Crea una contraseña", true, error, "Activar", {
            dialog = ""
            error = null
        }) { a, b ->
            if (a.length < 4) {
                error = "Usa al menos 4 caracteres."
            } else if (a != b) {
                error = "Las contraseñas no coinciden."
            } else {
                StrictMode.enable(ctx, a, chosenWait)
                dialog = ""
                error = null
                onChanged()
            }
        }
    }
    if (dialog == "owner") {
        AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text("¿Dejar de ser propietario?") },
            text = { Text("Bloqueador perderá la protección contra modo seguro y restablecimiento. Para volver a activarla tendrás que usar adb otra vez (y quitar las cuentas).") },
            confirmButton = {
                TextButton(onClick = { DeviceOwner.removeOwner(ctx); dialog = ""; pendingTick++; onChanged() }) { Text("Quitar") }
            },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Cancelar") } }
        )
    }
    if (dialog == "request") {
        PasswordDialog("Pedir desactivación", false, error, "Pedir", {
            dialog = ""
            error = null
        }) { a, _ ->
            if (StrictMode.requestDisable(ctx, a)) {
                dialog = ""
                error = null
                pendingTick++
            } else {
                error = "Contraseña incorrecta."
            }
        }
    }
    if (dialog == "unset") {
        PasswordDialog("Contraseña para desactivar", false, error, "Desactivar", {
            dialog = ""
            error = null
        }) { a, _ ->
            if (StrictMode.disableIfReady(ctx, a)) {
                dialog = ""
                error = null
                onChanged()
            } else if (StrictMode.pending(ctx) !is StrictMode.Pending.Ready) {
                dialog = ""
                error = null
                pendingTick++
            } else {
                error = "Contraseña incorrecta."
            }
        }
    }
}

@Composable
private fun StatusRow(ok: Boolean, title: String, desc: String, action: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StateGlyph(ok)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(8.dp))
        action()
    }
}

@Composable
private fun OptionRow(title: String, desc: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
