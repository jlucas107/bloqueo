@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.bloqueador

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

@Composable
fun ProtectionScreen(
    modifier: Modifier,
    serviceOn: Boolean,
    adminOn: Boolean,
    strictOn: Boolean,
    onChanged: () -> Unit
) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var cleanRecents by remember { mutableStateOf(Prefs.cleanRecents(ctx)) }
    var logTick by remember { mutableStateOf(0) }
    val logLines = remember(logTick) { DebugLog.snapshot() }
    val clipboard = LocalClipboardManager.current

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Protección", style = MaterialTheme.typography.headlineLarge)
                Text(
                    "Para que nadie pueda saltarse los bloqueos.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            SurfaceCard(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {
                StatusRow(
                    ok = serviceOn,
                    title = "Accesibilidad",
                    desc = if (serviceOn) "Activa: detecta y bloquea las apps."
                    else "Necesaria para que el bloqueo funcione."
                ) {
                    if (!serviceOn) {
                        FilledTonalButton(onClick = {
                            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }) { Text("Activar") }
                    }
                }
                SoftDivider()
                StatusRow(
                    ok = adminOn,
                    title = "Anti-desinstalación",
                    desc = if (adminOn) "Android no deja desinstalar la app."
                    else "Evita que la app se pueda desinstalar."
                ) {
                    if (!adminOn) {
                        FilledTonalButton(onClick = { ctx.startActivity(adminIntent(ctx)) }) { Text("Activar") }
                    } else if (!strictOn) {
                        TextButton(onClick = {
                            dpm(ctx).removeActiveAdmin(adminComponent(ctx))
                            onChanged()
                        }) { Text("Quitar") }
                    }
                }
                SoftDivider()
                StatusRow(
                    ok = strictOn,
                    title = "Modo estricto",
                    desc = when {
                        strictOn -> "Contraseña, hora y Ajustes protegidos."
                        !adminOn -> "Primero activa la anti-desinstalación."
                        else -> "Pide contraseña y protege Ajustes y la hora."
                    }
                ) {
                    if (!strictOn) {
                        FilledTonalButton(enabled = adminOn, onClick = { dialog = "set" }) { Text("Activar") }
                    } else {
                        TextButton(onClick = { dialog = "unset" }) { Text("Desactivar") }
                    }
                }
            }
        }

        item {
            SurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Quitar de recientes", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "Al bloquear una app, además de cerrarla, intenta sacarla de la lista de apps recientes. Es experimental y puede variar según el teléfono.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Switch(
                        checked = cleanRecents,
                        onCheckedChange = { cleanRecents = it; Prefs.setCleanRecents(ctx, it) }
                    )
                }
            }
        }

        item {
            SurfaceCard {
                Text("Diagnóstico", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Servicio: ${if (serviceOn) "activo" else "apagado"} · Modo estricto: ${if (strictOn) "sí" else "no"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    if (logLines.isEmpty()) "Sin eventos todavía. Abre Ajustes y vuelve aquí a pulsar «Actualizar»."
                    else logLines.joinToString("\n"),
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant).padding(10.dp)
                )
                Row {
                    TextButton(onClick = { logTick++ }) { Text("Actualizar") }
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(logLines.joinToString("\n")))
                    }) { Text("Copiar") }
                    TextButton(onClick = { DebugLog.clear(); logTick++ }) { Text("Borrar") }
                }
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    Icons.Filled.Info, contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    "Con el modo estricto activo, si entras en Ajustes a la pantalla de Accesibilidad de Bloqueador (o a cualquiera que muestre «Bloqueador»), la app la cierra y te manda al inicio. Tampoco podrás cambiar la fecha y la hora ni el DNS privado. Para quitarlo, entra a la app con tu contraseña.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
    }

    if (dialog == "set") {
        PasswordDialog("Crea una contraseña", true, error, "Activar", {
            dialog = ""
            error = null
        }) { a, b ->
            if (a.length < 4) {
                error = "Usa al menos 4 caracteres."
            } else if (a != b) {
                error = "Las contraseñas no coinciden."
            } else {
                StrictMode.enable(ctx, a)
                dialog = ""
                error = null
                onChanged()
            }
        }
    }
    if (dialog == "unset") {
        PasswordDialog("Contraseña para desactivar", false, error, "Desactivar", {
            dialog = ""
            error = null
        }) { a, _ ->
            if (StrictMode.disable(ctx, a)) {
                dialog = ""
                error = null
                onChanged()
            } else {
                error = "Contraseña incorrecta."
            }
        }
    }
}

@Composable
private fun StatusRow(ok: Boolean, title: String, desc: String, action: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StateGlyph(ok)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(8.dp))
        action()
    }
}
