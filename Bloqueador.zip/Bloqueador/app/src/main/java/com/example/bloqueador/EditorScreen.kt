@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.bloqueador

import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun EditorScreen(
    initial: Schedule,
    isNew: Boolean,
    onSave: (Schedule) -> Unit,
    onCancel: () -> Unit
) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(initial.name) }
    var days by remember { mutableStateOf(initial.days) }
    var start by remember { mutableStateOf(initial.startMin) }
    var end by remember { mutableStateOf(initial.endMin) }
    var pkgs by remember { mutableStateOf(initial.packages) }
    var query by remember { mutableStateOf("") }
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { loadApps(ctx) }
        loading = false
    }

    val filtered = apps.filter { it.label.contains(query, ignoreCase = true) }

    val hint: String? = when {
        name.isBlank() -> "Ponle un nombre al horario."
        days.isEmpty() -> "Elige al menos un día."
        start == end -> "La hora de inicio y la de fin deben ser distintas."
        pkgs.isEmpty() -> "Elige al menos una app."
        else -> null
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(if (isNew) "Nuevo horario" else "Editar horario") },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.background, tonalElevation = 3.dp) {
                Column(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (hint != null) {
                        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Button(
                        enabled = hint == null,
                        onClick = {
                            onSave(initial.copy(name = name.trim(), days = days, startMin = start, endMin = end, packages = pkgs))
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text("Guardar horario") }
                }
            }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ---- Nombre
            item {
                SurfaceCard {
                    SectionLabel("Nombre")
                    OutlinedTextField(
                        value = name, onValueChange = { name = it },
                        placeholder = { Text("Ej. Trabajo, Estudio, Dormir") },
                        singleLine = true,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // ---- Días
            item {
                SurfaceCard {
                    SectionLabel("Días")
                    val presets = listOf(
                        "Lun–Vie" to setOf(1, 2, 3, 4, 5),
                        "Fin de semana" to setOf(6, 7),
                        "Todos" to (1..7).toSet()
                    )
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        presets.forEach { (label, set) ->
                            FilterChip(selected = days == set, onClick = { days = set }, label = { Text(label) })
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        DAY_NAMES.forEachIndexed { i, n ->
                            val d = i + 1
                            val selected = d in days
                            Box(
                                Modifier.size(40.dp).clip(CircleShape)
                                    .background(
                                        if (selected) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .clickable { days = if (selected) days - d else days + d },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    n, fontWeight = FontWeight.SemiBold,
                                    color = if (selected) MaterialTheme.colorScheme.onPrimary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // ---- Horas
            item {
                SurfaceCard {
                    SectionLabel("Franja de horas")
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        TimeTile("Desde", start, Modifier.weight(1f)) {
                            TimePickerDialog(ctx, { _, h, m -> start = h * 60 + m }, start / 60, start % 60, true).show()
                        }
                        TimeTile("Hasta", end, Modifier.weight(1f)) {
                            TimePickerDialog(ctx, { _, h, m -> end = h * 60 + m }, end / 60, end % 60, true).show()
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    TimeBar(startMin = start, endMin = end, nowMin = null)
                    Spacer(Modifier.height(8.dp))
                    val dur = if (end > start) end - start else 24 * 60 - start + end
                    val durText = if (dur % 60 == 0) "${dur / 60} h" else "${dur / 60} h ${dur % 60} min"
                    Text(
                        if (start == end) "Elige dos horas distintas."
                        else "Bloquea durante $durText y se desbloquea a las ${formatMinutes(end)}" +
                            (if (end < start) " del día siguiente." else "."),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (start == end) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // ---- Apps
            item {
                Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Apps a bloquear", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        if (pkgs.isNotEmpty()) {
                            Pill(
                                "${pkgs.size} elegidas",
                                MaterialTheme.colorScheme.primaryContainer,
                                MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        placeholder = { Text("Buscar app") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        singleLine = true,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            if (loading) {
                item {
                    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }

            items(filtered, key = { it.pkg }) { a ->
                val checked = a.pkg in pkgs
                Row(
                    Modifier.fillMaxWidth()
                        .clip(MaterialTheme.shapes.medium)
                        .background(if (checked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) else Color.Transparent)
                        .clickable { pkgs = if (checked) pkgs - a.pkg else pkgs + a.pkg }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppIcon(a.pkg, 40.dp, a.label)
                    Spacer(Modifier.width(14.dp))
                    Text(
                        a.label, style = MaterialTheme.typography.bodyLarge,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Checkbox(checked = checked, onCheckedChange = null)
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 10.dp))
}

@Composable
private fun TimeTile(label: String, minutes: Int, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(formatMinutes(minutes), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
}
