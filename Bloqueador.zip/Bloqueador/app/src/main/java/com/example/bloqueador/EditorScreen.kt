@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.bloqueador

import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun EditorScreen(
    initial: Schedule,
    isNew: Boolean,
    onSave: (Schedule) -> Unit,
    onCancel: () -> Unit
) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(initial.name) }
    var days by remember { mutableStateOf(initial.days) }
    var start by remember { mutableStateOf(initial.startMin) }
    var end by remember { mutableStateOf(initial.endMin) }
    var pkgs by remember { mutableStateOf(initial.packages) }
    var cats by remember { mutableStateOf(initial.categories) }
    var query by remember { mutableStateOf("") }
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { loadApps(ctx) }
        loading = false
    }

    var cat by remember { mutableStateOf<AppCategory?>(null) }
    val byCat = remember(apps) { apps.groupBy { it.category } }
    // Las categorías bloqueadas completas ya están en su tarjeta: la lista solo muestra el resto.
    val presentCats = remember(byCat, cats) {
        AppCategory.values().filter { it !in cats && !byCat[it].isNullOrEmpty() }
    }
    val extraPkgs = remember(pkgs, apps, cats) {
        pkgs.filter { p -> apps.firstOrNull { it.pkg == p }?.category !in cats }.toSet()
    }
    val filtered = remember(apps, query, cat, cats) {
        apps.filter {
            it.category !in cats && (cat == null || it.category == cat) && it.label.contains(query, ignoreCase = true)
        }
    }

    val hint: String? = when {
        name.isBlank() -> "Ponle un nombre al horario."
        days.isEmpty() -> "Elige al menos un día."
        start == end -> "La hora de inicio y la de fin deben ser distintas."
        extraPkgs.isEmpty() && cats.isEmpty() -> "Elige al menos una app o categoría."
        else -> null
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            // Banda Noche con un resumen en vivo de lo que estás armando.
            Column(
                Modifier.fillMaxWidth()
                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                    .background(Noche)
                    .statusBarsPadding()
                    .padding(start = 8.dp, end = 22.dp, top = 4.dp, bottom = 22.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver", tint = Color.White)
                    }
                    Text(
                        if (isNew) "Nuevo horario" else "Editar horario",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
                Column(Modifier.padding(start = 14.dp)) {
                    Text(
                        "${formatMinutes(start)} – ${formatMinutes(end)}",
                        style = MaterialTheme.typography.displayMedium,
                        color = Color.White
                    )
                    val dayText = when (days) {
                        setOf(1, 2, 3, 4, 5) -> "De lunes a viernes"
                        setOf(6, 7) -> "Fines de semana"
                        (1..7).toSet() -> "Todos los días"
                        emptySet<Int>() -> "Sin días elegidos"
                        else -> "${days.size} ${if (days.size == 1) "día" else "días"} por semana"
                    }
                    val what = buildList {
                        if (cats.isNotEmpty()) add(cats.sortedBy { it.ordinal }.joinToString(" y ") { it.label.lowercase() })
                        if (extraPkgs.isNotEmpty()) add("${extraPkgs.size} ${if (extraPkgs.size == 1) "app" else "apps"} más")
                    }.joinToString(" + ").ifEmpty { "sin apps" }
                    Text(
                        "$dayText · $what",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.72f)
                    )
                }
            }
        },
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surface) {
                Column(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (hint != null) {
                        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Button(
                        enabled = hint == null,
                        onClick = {
                            onSave(
                                initial.copy(
                                    name = name.trim(), days = days, startMin = start, endMin = end,
                                    packages = extraPkgs, categories = cats
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text("Guardar horario") }
                }
            }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ---- Nombre
            item {
                SurfaceCard {
                    SectionLabel("Nombre")
                    OutlinedTextField(
                        value = name, onValueChange = { name = it },
                        placeholder = { Text("Ej. Trabajo, Estudio, Dormir") },
                        singleLine = true,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // ---- Días
            item {
                SurfaceCard {
                    SectionLabel("Días")
                    val presets = listOf(
                        "Lun–Vie" to setOf(1, 2, 3, 4, 5),
                        "Fin de semana" to setOf(6, 7),
                        "Todos" to (1..7).toSet()
                    )
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        presets.forEach { (label, set) ->
                            FilterChip(selected = days == set, onClick = { days = set }, label = { Text(label) })
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        DAY_NAMES.forEachIndexed { i, n ->
                            val d = i + 1
                            val selected = d in days
                            Box(
                                Modifier.size(40.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                                    .background(
                                        if (selected) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .clickable { days = if (selected) days - d else days + d },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    n, fontWeight = FontWeight.SemiBold,
                                    color = if (selected) MaterialTheme.colorScheme.onPrimary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // ---- Horas
            item {
                SurfaceCard {
                    SectionLabel("Franja de horas")
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        TimeTile("Desde", start, Modifier.weight(1f)) {
                            TimePickerDialog(ctx, { _, h, m -> start = h * 60 + m }, start / 60, start % 60, true).show()
                        }
                        TimeTile("Hasta", end, Modifier.weight(1f)) {
                            TimePickerDialog(ctx, { _, h, m -> end = h * 60 + m }, end / 60, end % 60, true).show()
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    TimeBar(startMin = start, endMin = end, nowMin = null)
                    Spacer(Modifier.height(8.dp))
                    val dur = if (end > start) end - start else 24 * 60 - start + end
                    val durText = if (dur % 60 == 0) "${dur / 60} h" else "${dur / 60} h ${dur % 60} min"
                    Text(
                        if (start == end) "Elige dos horas distintas."
                        else "Bloquea durante $durText y se desbloquea a las ${formatMinutes(end)}" +
                            (if (end < start) " del día siguiente." else "."),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (start == end) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // ---- Categorías completas
            item {
                SurfaceCard {
                    SectionLabel("Siempre bloqueadas")
                    Text(
                        "Todas las apps de estas categorías, también las que se instalen después.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    Schedule.DEFAULT_CATEGORIES.sortedBy { it.ordinal }.forEach { c ->
                        val on = c in cats
                        val group = byCat[c].orEmpty()
                        Row(
                            Modifier.fillMaxWidth()
                                .clip(MaterialTheme.shapes.medium)
                                .clickable { cats = if (on) cats - c else cats + c }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(c.label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                                Text(
                                    if (loading) "Buscando apps…"
                                    else "${group.size} instaladas ahora",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (group.isNotEmpty()) {
                                AppStack(group.map { it.pkg }, size = 26.dp)
                                Spacer(Modifier.width(10.dp))
                            }
                            Switch(checked = on, onCheckedChange = { cats = if (on) cats - c else cats + c })
                        }
                    }
                }
            }

            // ---- Apps
            item {
                Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Otras apps", style = MaterialTheme.typography.titleLarge)
                            Text(
                                "Opcional: apps sueltas que también quieras bloquear.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (extraPkgs.isNotEmpty()) {
                            Pill(
                                "${extraPkgs.size} elegidas",
                                MaterialTheme.colorScheme.primaryContainer,
                                MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        placeholder = { Text("Buscar app") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        singleLine = true,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    )
                    // Filtros por categoría (solo las que tienes instaladas)
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(selected = cat == null, onClick = { cat = null }, label = { Text("Todas") })
                        presentCats.forEach { c ->
                            val n = byCat[c]?.size ?: 0
                            val chosen = byCat[c]?.count { it.pkg in pkgs } ?: 0
                            FilterChip(
                                selected = cat == c,
                                onClick = { cat = if (cat == c) null else c },
                                label = { Text(if (chosen > 0) "${c.label} $chosen/$n" else "${c.label} $n") }
                            )
                        }
                    }
                }
            }

            if (loading) {
                item {
                    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }

            if (cat == null && query.isBlank()) {
                // Vista agrupada: cada categoría con su título y un atajo para elegirlas todas.
                presentCats.forEach { c ->
                    val group = byCat[c].orEmpty()
                    item(key = "h_${c.name}") {
                        CategoryHeader(c.label, group, pkgs) { pkgs = it }
                    }
                    items(group, key = { it.pkg }) { a ->
                        AppRow(a, a.pkg in pkgs, showCategory = false) {
                            pkgs = if (a.pkg in pkgs) pkgs - a.pkg else pkgs + a.pkg
                        }
                    }
                }
            } else {
                val c = cat
                if (c != null && query.isBlank()) {
                    item(key = "h_sel") { CategoryHeader(c.label, byCat[c].orEmpty(), pkgs) { pkgs = it } }
                }
                if (filtered.isEmpty() && !loading) {
                    item {
                        Text(
                            "Ninguna app coincide con «$query».",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
                items(filtered, key = { it.pkg }) { a ->
                    AppRow(a, a.pkg in pkgs, showCategory = c == null) {
                        pkgs = if (a.pkg in pkgs) pkgs - a.pkg else pkgs + a.pkg
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 10.dp))
}

@Composable
private fun TimeTile(label: String, minutes: Int, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(formatMinutes(minutes), style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
    }
}

/** Título de una categoría con el atajo para elegir o quitar todas sus apps. */
@Composable
private fun CategoryHeader(label: String, group: List<AppInfo>, pkgs: Set<String>, onChange: (Set<String>) -> Unit) {
    val all = group.map { it.pkg }.toSet()
    val allChosen = all.isNotEmpty() && pkgs.containsAll(all)
    Row(
        Modifier.fillMaxWidth().padding(start = 4.dp, top = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.titleMedium)
            Text(
                "${group.size} ${if (group.size == 1) "app" else "apps"}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        TextButton(onClick = { onChange(if (allChosen) pkgs - all else pkgs + all) }) {
            Text(if (allChosen) "Quitar todas" else "Elegir todas")
        }
    }
}

@Composable
private fun AppRow(a: AppInfo, checked: Boolean, showCategory: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .background(if (checked) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) else Color.Transparent)
            .clickable(onClick = onToggle)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(a.pkg, 40.dp, a.label)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(a.label, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (showCategory) {
                Text(a.category.label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Checkbox(checked = checked, onCheckedChange = null)
    }
}
