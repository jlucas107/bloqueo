package com.example.bloqueador

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun LockScreen(onTry: (String) -> Boolean) {
    var pw by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    var site by remember { mutableStateOf("") }
    var siteMsg by remember { mutableStateOf<String?>(null) }
    var siteIsError by remember { mutableStateOf(false) }

    // Añadir un sitio solo refuerza el bloqueo, por eso no pide contraseña. Quitarlos sí la pide.
    fun addSite() {
        val host = WebFilter.addSite(ctx, site)
        if (host == null) {
            siteMsg = "Escribe un sitio válido, por ejemplo ejemplo.com"
            siteIsError = true
        } else {
            siteMsg = "Bloqueado: $host"
            siteIsError = false
            site = ""
        }
    }

    // Campos claros sobre el fondo Noche.
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
        focusedBorderColor = Color.White, unfocusedBorderColor = Color.White.copy(alpha = 0.35f),
        focusedLabelColor = Color.White, unfocusedLabelColor = Color.White.copy(alpha = 0.7f),
        focusedPlaceholderColor = Color.White.copy(alpha = 0.5f), unfocusedPlaceholderColor = Color.White.copy(alpha = 0.5f),
        cursorColor = Ambar,
        focusedSupportingTextColor = Color.White.copy(alpha = 0.8f), unfocusedSupportingTextColor = Color.White.copy(alpha = 0.8f)
    )
    Box(
        Modifier.fillMaxSize().background(Noche).systemBarsPadding().imePadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(28.dp).widthIn(max = 420.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            IconBubble(Icons.Filled.Lock, Color.White, NocheAlta, size = 84.dp)
            Text("Modo estricto activo", style = MaterialTheme.typography.headlineLarge, color = Color.White, textAlign = TextAlign.Center)
            Text(
                "Escribe tu contraseña para entrar.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.72f),
                textAlign = TextAlign.Center
            )
            OutlinedTextField(
                value = pw, onValueChange = { pw = it; wrong = false },
                label = { Text("Contraseña") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                isError = wrong,
                supportingText = { if (wrong) Text("Contraseña incorrecta") },
                shape = MaterialTheme.shapes.medium,
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = { wrong = !onTry(pw); pw = "" },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Noche),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Entrar") }

            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.14f)))
            Spacer(Modifier.height(2.dp))
            Text("Bloquear otro sitio web", style = MaterialTheme.typography.titleMedium, color = Color.White)
            Text(
                "Puedes añadir sitios sin contraseña. Para quitarlos tendrás que entrar.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.72f),
                textAlign = TextAlign.Center
            )
            OutlinedTextField(
                value = site, onValueChange = { site = it; siteMsg = null },
                label = { Text("Sitio web") }, placeholder = { Text("ejemplo.com") },
                singleLine = true,
                isError = siteMsg != null && siteIsError,
                supportingText = {
                    val m = siteMsg
                    if (m != null) Text(m, color = if (siteIsError) Color(0xFFFFB4AB) else Color(0xFF5BD3A2))
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { addSite() }),
                shape = MaterialTheme.shapes.medium,
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedButton(
                onClick = { addSite() },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) { Text("Bloquear sitio") }
        }
    }
}

@Composable
fun PasswordDialog(
    title: String,
    askConfirm: Boolean,
    errorMsg: String?,
    confirmLabel: String,
    onCancel: () -> Unit,
    onOk: (String, String) -> Unit
) {
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = p1, onValueChange = { p1 = it },
                    label = { Text("Contraseña") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    shape = MaterialTheme.shapes.medium
                )
                if (askConfirm) {
                    OutlinedTextField(
                        value = p2, onValueChange = { p2 = it },
                        label = { Text("Repite la contraseña") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        shape = MaterialTheme.shapes.medium
                    )
                    Text(
                        "No se puede recuperar. Guárdala en un lugar seguro.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (errorMsg != null) {
                    Text(errorMsg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = { TextButton(onClick = { onOk(p1, p2) }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancelar") } }
    )
}
