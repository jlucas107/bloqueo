@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.bloqueador

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay

data class AppInfo(val label: String, val pkg: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BloqueadorTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
}

// ------------------------------------------------------------------ Ayudas

fun isServiceEnabled(ctx: Context): Boolean {
    val enabled = Settings.Secure.getString(
        ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val cn = ComponentName(ctx, BlockerService::class.java)
    return enabled.split(':').any {
        it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
    }
}

internal fun adminComponent(ctx: Context) = ComponentName(ctx, AdminReceiver::class.java)

internal fun dpm(ctx: Context) =
    ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

fun isAdminActive(ctx: Context): Boolean = dpm(ctx).isAdminActive(adminComponent(ctx))

internal fun adminIntent(ctx: Context) =
    Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent(ctx))
        putExtra(
            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "Evita que Bloqueador pueda desinstalarse mientras esté activo."
        )
    }

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter {
            val pkg = it.activityInfo.packageName
            pkg != ctx.packageName && pkg !in ScheduleStore.NEVER_BLOCK
        }
        .distinctBy { it.activityInfo.packageName }
        .map { ri ->
            val pkg = ri.activityInfo.packageName
            // Se carga el ícono del lanzador (el mismo que se ve en la pantalla de inicio).
            IconCache.preload(pkg) { ri.loadIcon(pm) }
            AppInfo(ri.loadLabel(pm).toString(), pkg)
        }
        .sortedBy { it.label.lowercase() }
}

// ------------------------------------------------------------------ Pantalla raíz

@Composable
fun App() {
    val ctx = LocalContext.current
    var schedules by remember { mutableStateOf(ScheduleStore.load(ctx)) }
    var serviceOn by remember { mutableStateOf(isServiceEnabled(ctx)) }
    var adminOn by remember { mutableStateOf(isAdminActive(ctx)) }
    var strictOn by remember { mutableStateOf(StrictMode.isEnabled(ctx)) }
    var unlocked by remember { mutableStateOf(!StrictMode.isEnabled(ctx)) }
    var editing by remember { mutableStateOf<Schedule?>(null) }
    var tab by rememberSaveable { mutableStateOf(0) }

    // Reloj para refrescar "Activo ahora" y la marca de hora cada 30 s.
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            tick++
        }
    }
    val now = remember(tick, schedules) { TrustedClock.now(ctx) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                serviceOn = isServiceEnabled(ctx)
                adminOn = isAdminActive(ctx)
                strictOn = StrictMode.isEnabled(ctx)
                tick++
            } else if (e == Lifecycle.Event.ON_STOP) {
                // Con el modo estricto, al salir de la app se vuelve a pedir la contraseña.
                if (StrictMode.isEnabled(ctx)) {
                    unlocked = false
                    editing = null
                }
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    fun persist(list: List<Schedule>) {
        schedules = list
        ScheduleStore.save(ctx, list)
    }

    if (!unlocked) {
        LockScreen { pw ->
            val ok = StrictMode.check(ctx, pw)
            if (ok) unlocked = true
            ok
        }
    } else {
        val current = editing
        if (current != null) {
            BackHandler { editing = null }
            EditorScreen(
                initial = current,
                isNew = schedules.none { it.id == current.id },
                onSave = { s ->
                    persist(
                        if (schedules.any { it.id == s.id }) schedules.map { if (it.id == s.id) s else it }
                        else schedules + s
                    )
                    editing = null
                },
                onCancel = { editing = null }
            )
        } else {
            val newSchedule = {
                editing = Schedule(
                    name = "", days = setOf(1, 2, 3, 4, 5),
                    startMin = 9 * 60, endMin = 17 * 60, packages = emptySet()
                )
            }
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar {
                        NavigationBarItem(
                            selected = tab == 0, onClick = { tab = 0 },
                            icon = { Icon(Icons.Filled.DateRange, contentDescription = null) },
                            label = { Text("Horarios") }
                        )
                        NavigationBarItem(
                            selected = tab == 1, onClick = { tab = 1 },
                            icon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                            label = { Text("Protección") }
                        )
                    }
                },
                floatingActionButton = {
                    if (tab == 0) {
                        ExtendedFloatingActionButton(
                            text = { Text("Nuevo horario") },
                            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                            onClick = newSchedule
                        )
                    }
                }
            ) { pad ->
                if (tab == 0) {
                    HomeScreen(
                        modifier = Modifier.padding(pad),
                        schedules = schedules,
                        now = now,
                        serviceOn = serviceOn,
                        onOpenAccessibility = {
                            if (!Guard.enableService(ctx)) {
                                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                            }
                            serviceOn = isServiceEnabled(ctx)
                        },
                        onAdd = newSchedule,
                        onEdit = { editing = it },
                        onToggle = { s, on -> persist(schedules.map { if (it.id == s.id) it.copy(enabled = on) else it }) },
                        onDelete = { s -> persist(schedules.filter { it.id != s.id }) }
                    )
                } else {
                    ProtectionScreen(
                        modifier = Modifier.padding(pad),
                        serviceOn = serviceOn,
                        adminOn = adminOn,
                        strictOn = strictOn,
                        onChanged = {
                            serviceOn = isServiceEnabled(ctx)
                            adminOn = isAdminActive(ctx)
                            strictOn = StrictMode.isEnabled(ctx)
                        }
                    )
                }
            }
        }
    }
}
