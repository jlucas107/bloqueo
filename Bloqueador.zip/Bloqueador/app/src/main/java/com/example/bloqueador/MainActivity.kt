@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.bloqueador

import android.app.TimePickerDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val DAY_NAMES = listOf("L", "M", "X", "J", "V", "S", "D")

data class AppInfo(val label: String, val pkg: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

fun isServiceEnabled(ctx: Context): Boolean {
    val enabled = Settings.Secure.getString(
        ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val cn = ComponentName(ctx, BlockerService::class.java)
    return enabled.split(':').any {
        it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
    }
}

private fun adminComponent(ctx: Context) = ComponentName(ctx, AdminReceiver::class.java)

private fun dpm(ctx: Context) =
    ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

fun isAdminActive(ctx: Context): Boolean = dpm(ctx).isAdminActive(adminComponent(ctx))

private fun adminIntent(ctx: Context) =
    Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent(ctx))
        putExtra(
            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "Evita que Bloqueador pueda desinstalarse mientras esté activo."
        )
    }

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .filter { it.pkg != ctx.packageName && it.pkg !in ScheduleStore.NEVER_BLOCK }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var schedules by remember { mutableStateOf(ScheduleStore.load(ctx)) }
    var serviceOn by remember { mutableStateOf(isServiceEnabled(ctx)) }
    var adminOn by remember { mutableStateOf(isAdminActive(ctx)) }
    var strictOn by remember { mutableStateOf(StrictMode.isEnabled(ctx)) }
    var unlocked by remember { mutableStateOf(!StrictMode.isEnabled(ctx)) }
    var editing by remember { mutableStateOf<Schedule?>(null) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                serviceOn = isServiceEnabled(ctx)
                adminOn = isAdminActive(ctx)
                strictOn = StrictMode.isEnabled(ctx)
            } else if (e == Lifecycle.Event.ON_STOP) {
                // Con el modo estricto, al salir de la app se vuelve a pedir la contraseña.
                if (StrictMode.isEnabled(ctx)) {
                    unlocked = false
                    editing = null
                }
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    fun persist(list: List<Schedule>) {
        schedules = list
        ScheduleStore.save(ctx, list)
    }

    if (!unlocked) {
        LockScreen { pw ->
            val ok = StrictMode.check(ctx, pw)
            if (ok) unlocked = true
            ok
        }
    } else {
        val current = editing
        if (current != null) {
            BackHandler { editing = null }
            Editor(
                initial = current,
                onSave = { s ->
                    persist(
                        if (schedules.any { it.id == s.id }) schedules.map { if (it.id == s.id) s else it }
                        else schedules + s
                    )
                    editing = null
                },
                onCancel = { editing = null }
            )
        } else {
            ListScreen(
                schedules = schedules,
                serviceOn = serviceOn,
                header = {
                    StrictSection(strictOn = strictOn, adminOn = adminOn) {
                        adminOn = isAdminActive(ctx)
                        strictOn = StrictMode.isEnabled(ctx)
                    }
                },
                onAdd = {
                    editing = Schedule(
                        name = "", days = setOf(1, 2, 3, 4, 5),
                        startMin = 9 * 60, endMin = 17 * 60, packages = emptySet()
                    )
                },
                onEdit = { editing = it },
                onToggle = { s, on -> persist(schedules.map { if (it.id == s.id) it.copy(enabled = on) else it }) },
                onDelete = { s -> persist(schedules.filter { it.id != s.id }) }
            )
        }
    }
}

@Composable
fun LockScreen(onTry: (String) -> Boolean) {
    var pw by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🔒", fontSize = 56.sp)
        Spacer(Modifier.height(12.dp))
        Text("Modo estricto activo", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = pw, onValueChange = { pw = it; wrong = false },
            label = { Text("Contraseña") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            isError = wrong
        )
        if (wrong) Text("Contraseña incorrecta", color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            wrong = !onTry(pw)
            pw = ""
        }) { Text("Desbloquear") }
    }
}

@Composable
fun PasswordDialog(
    title: String,
    askConfirm: Boolean,
    errorMsg: String?,
    onCancel: () -> Unit,
    onOk: (String, String) -> Unit
) {
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = p1, onValueChange = { p1 = it },
                    label = { Text("Contraseña") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                if (askConfirm) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = p2, onValueChange = { p2 = it },
                        label = { Text("Repite la contraseña") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                }
                if (errorMsg != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(errorMsg, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = { TextButton(onClick = { onOk(p1, p2) }) { Text("Aceptar") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancelar") } }
    )
}

@Composable
fun StrictSection(strictOn: Boolean, adminOn: Boolean, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Modo estricto", style = MaterialTheme.typography.titleMedium)

            Text(
                if (adminOn) "✅ Protección contra desinstalación: activa"
                else "⚠️ Protección contra desinstalación: inactiva"
            )
            if (!adminOn) {
                Button(onClick = { ctx.startActivity(adminIntent(ctx)) }) { Text("Activar protección") }
            }

            Text(
                if (strictOn) "✅ Modo estricto: activo (contraseña requerida, hora protegida, Ajustes protegidos)"
                else "Modo estricto: desactivado"
            )
            if (!strictOn) {
                Button(enabled = adminOn, onClick = { dialog = "set" }) { Text("Activar modo estricto") }
                if (!adminOn) Text("Primero activa la protección.", style = MaterialTheme.typography.bodySmall)
            } else {
                OutlinedButton(onClick = { dialog = "unset" }) { Text("Desactivar modo estricto") }
            }

            if (adminOn && !strictOn) {
                TextButton(onClick = {
                    dpm(ctx).removeActiveAdmin(adminComponent(ctx))
                    onChanged()
                }) { Text("Quitar protección de desinstalación") }
            }
        }
    }

    if (dialog == "set") {
        PasswordDialog("Crea una contraseña", true, error, {
            dialog = ""
            error = null
        }) { a, b ->
            if (a.length < 4) {
                error = "Mínimo 4 caracteres"
            } else if (a != b) {
                error = "Las contraseñas no coinciden"
            } else {
                StrictMode.enable(ctx, a)
                dialog = ""
                error = null
                onChanged()
            }
        }
    }
    if (dialog == "unset") {
        PasswordDialog("Contraseña para desactivar", false, error, {
            dialog = ""
            error = null
        }) { a, _ ->
            if (StrictMode.disable(ctx, a)) {
                dialog = ""
                error = null
                onChanged()
            } else {
                error = "Contraseña incorrecta"
            }
        }
    }
}

@Composable
fun ListScreen(
    schedules: List<Schedule>,
    serviceOn: Boolean,
    header: @Composable () -> Unit,
    onAdd: () -> Unit,
    onEdit: (Schedule) -> Unit,
    onToggle: (Schedule, Boolean) -> Unit,
    onDelete: (Schedule) -> Unit
) {
    val ctx = LocalContext.current
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) { Text("+", fontSize = 28.sp) }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Text("Bloqueador de apps", style = MaterialTheme.typography.headlineMedium) }

            if (!serviceOn) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("El bloqueo está desactivado. Activa «Bloqueador» en Accesibilidad para que funcione.")
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = {
                                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                            }) { Text("Abrir Accesibilidad") }
                        }
                    }
                }
            }

            item { header() }

            if (schedules.isEmpty()) {
                item { Text("Aún no tienes horarios. Toca + para crear el primero.") }
            }

            items(schedules, key = { it.id }) { s ->
                Card(Modifier.fillMaxWidth().clickable { onEdit(s) }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.name, style = MaterialTheme.typography.titleMedium)
                            Text(s.days.sorted().joinToString(" ") { DAY_NAMES[it - 1] })
                            Text("${formatMinutes(s.startMin)} – ${formatMinutes(s.endMin)}  ·  ${s.packages.size} apps")
                        }
                        Switch(checked = s.enabled, onCheckedChange = { onToggle(s, it) })
                        TextButton(onClick = { onDelete(s) }) { Text("Borrar") }
                    }
                }
            }
        }
    }
}

@Composable
fun Editor(initial: Schedule, onSave: (Schedule) -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(initial.name) }
    var days by remember { mutableStateOf(initial.days) }
    var start by remember { mutableStateOf(initial.startMin) }
    var end by remember { mutableStateOf(initial.endMin) }
    var pkgs by remember { mutableStateOf(initial.packages) }
    var query by remember { mutableStateOf("") }
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }

    val filtered = apps.filter { it.label.contains(query, ignoreCase = true) }
    val valid = name.isNotBlank() && days.isNotEmpty() && pkgs.isNotEmpty() && start != end

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        LazyColumn(Modifier.weight(1f)) {
            item {
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text("Nombre (ej. Trabajo)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                Text("Días", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    DAY_NAMES.forEachIndexed { i, n ->
                        val d = i + 1
                        val selected = d in days
                        Box(
                            Modifier.size(40.dp).clip(CircleShape)
                                .background(
                                    if (selected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { days = if (selected) days - d else days + d },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                n,
                                color = if (selected) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("Horas", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = {
                        TimePickerDialog(ctx, { _, h, m -> start = h * 60 + m }, start / 60, start % 60, true).show()
                    }) { Text("Desde ${formatMinutes(start)}") }
                    OutlinedButton(onClick = {
                        TimePickerDialog(ctx, { _, h, m -> end = h * 60 + m }, end / 60, end % 60, true).show()
                    }) { Text("Hasta ${formatMinutes(end)}") }
                }
                if (end < start) {
                    Text("Cruza la medianoche: termina al día siguiente.", style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(16.dp))
                Text("Apps a bloquear (${pkgs.size})", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    label = { Text("Buscar app") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            items(filtered, key = { it.pkg }) { a ->
                val checked = a.pkg in pkgs
                Row(
                    Modifier.fillMaxWidth()
                        .clickable { pkgs = if (checked) pkgs - a.pkg else pkgs + a.pkg }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = checked, onCheckedChange = null)
                    Spacer(Modifier.width(12.dp))
                    Text(a.label)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onCancel) { Text("Cancelar") }
            Spacer(Modifier.width(8.dp))
            Button(
                enabled = valid,
                onClick = {
                    onSave(initial.copy(name = name.trim(), days = days, startMin = start, endMin = end, packages = pkgs))
                }
            ) { Text("Guardar") }
        }
    }
}
