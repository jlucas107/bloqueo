package com.example.bloqueador

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri

/** Categorías para ordenar las apps en el editor. El orden es el de los filtros. */
enum class AppCategory(val label: String) {
    REDES("Redes sociales"),
    JUEGOS("Juegos"),
    VIDEO("Videos"),
    MENSAJERIA("Mensajería"),
    NAVEGADORES("Navegadores"),
    MUSICA("Música"),
    COMPRAS("Compras"),
    NOTICIAS("Noticias"),
    FOTOS("Fotos"),
    ESTUDIO("Estudio y trabajo"),
    OTRAS("Otras")
}

/**
 * Clasifica las apps instaladas. Se combinan tres fuentes, de la más fiable a la menos:
 *  1. Una lista de apps conocidas (Instagram, TikTok, Free Fire...).
 *  2. La categoría que la propia app declara a Android (ApplicationInfo.category).
 *  3. Pistas en el nombre del paquete («game», «browser»...).
 */
object AppCategories {

    fun classify(pkg: String, info: ApplicationInfo?, browsers: Set<String>): AppCategory {
        KNOWN[pkg]?.let { return it }
        KNOWN_PREFIXES.firstOrNull { pkg.startsWith(it.first) }?.let { return it.second }
        if (pkg in browsers) return AppCategory.NAVEGADORES

        if (info != null) {
            when (info.category) {
                ApplicationInfo.CATEGORY_GAME -> return AppCategory.JUEGOS
                ApplicationInfo.CATEGORY_SOCIAL -> return AppCategory.REDES
                ApplicationInfo.CATEGORY_VIDEO -> return AppCategory.VIDEO
                ApplicationInfo.CATEGORY_AUDIO -> return AppCategory.MUSICA
                ApplicationInfo.CATEGORY_NEWS -> return AppCategory.NOTICIAS
                ApplicationInfo.CATEGORY_IMAGE -> return AppCategory.FOTOS
                ApplicationInfo.CATEGORY_PRODUCTIVITY -> return AppCategory.ESTUDIO
            }
            @Suppress("DEPRECATION")
            if (info.flags and ApplicationInfo.FLAG_IS_GAME != 0) return AppCategory.JUEGOS
        }

        val p = pkg.lowercase()
        if (GAME_HINTS.any { p.contains(it) }) return AppCategory.JUEGOS
        if (p.contains("browser")) return AppCategory.NAVEGADORES
        return AppCategory.OTRAS
    }

    /** Apps que abren enlaces web (los navegadores instalados). */
    fun browsers(ctx: Context): Set<String> =
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")).addCategory(Intent.CATEGORY_BROWSABLE)
            ctx.packageManager.queryIntentActivities(i, PackageManager.MATCH_ALL)
                .map { it.activityInfo.packageName }.toSet()
        } catch (e: Exception) {
            emptySet()
        }

    private val GAME_HINTS = listOf(
        ".game", "games", "gaming", "puzzle", "racing", "arcade", "casino", "slots", "solitaire",
        "chess", "sudoku", "shooter", "battle", "royale", "craft", "idle", "simulator"
    )

    /** Grupos de juegos y apps conocidos por el comienzo del paquete. */
    private val KNOWN_PREFIXES = listOf(
        "com.supercell." to AppCategory.JUEGOS,
        "com.king." to AppCategory.JUEGOS,
        "com.garena." to AppCategory.JUEGOS,
        "com.dts.freefire" to AppCategory.JUEGOS,
        "com.ea." to AppCategory.JUEGOS,
        "com.gameloft." to AppCategory.JUEGOS,
        "com.outfit7." to AppCategory.JUEGOS,
        "com.playrix." to AppCategory.JUEGOS,
        "com.rovio." to AppCategory.JUEGOS,
        "com.miniclip." to AppCategory.JUEGOS,
        "com.mojang." to AppCategory.JUEGOS,
        "com.mihoyo." to AppCategory.JUEGOS,
        "com.miHoYo." to AppCategory.JUEGOS,
        "com.HoYoverse." to AppCategory.JUEGOS,
        "com.tencent.ig" to AppCategory.JUEGOS,
        "com.pubg." to AppCategory.JUEGOS,
        "com.activision." to AppCategory.JUEGOS,
        "com.epicgames." to AppCategory.JUEGOS,
        "com.netmarble." to AppCategory.JUEGOS,
        "com.nianticlabs." to AppCategory.JUEGOS,
        "com.facebook.katana" to AppCategory.REDES,
        "com.facebook.lite" to AppCategory.REDES,
        "com.instagram." to AppCategory.REDES,
        "com.zhiliaoapp." to AppCategory.REDES,
        "com.ss.android.ugc." to AppCategory.REDES,
        "com.microsoft.office" to AppCategory.ESTUDIO,
        "com.google.android.apps.docs" to AppCategory.ESTUDIO
    )

    private val KNOWN: Map<String, AppCategory> = buildMap {
        // Redes sociales
        listOf(
            "com.twitter.android", "com.snapchat.android", "com.pinterest", "com.reddit.frontpage",
            "com.linkedin.android", "com.tumblr", "com.bereal.ft", "com.vk.vkclient",
            "com.kwai.video", "com.likee.video", "video.like", "com.triller.triller", "com.quora.android",
            "tv.twitch.android.app", "com.ninegag.android.app"
        ).forEach { put(it, AppCategory.REDES) }
        // Mensajería
        listOf(
            "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "org.telegram.plus",
            "com.facebook.orca", "com.facebook.mlite", "com.discord", "org.thoughtcrime.securesms",
            "com.google.android.apps.messaging", "com.samsung.android.messaging", "jp.naver.line.android",
            "com.viber.voip", "com.skype.raider", "com.kakao.talk"
        ).forEach { put(it, AppCategory.MENSAJERIA) }
        // Videos y streaming
        listOf(
            "com.google.android.youtube", "com.google.android.apps.youtube.kids", "com.netflix.mediaclient",
            "com.disney.disneyplus", "com.amazon.avod.thirdpartyclient", "com.wbd.stream", "com.hbo.hbonow",
            "com.crunchyroll.crunchyroid", "com.univision.prendetv", "com.star.app", "com.paramountplus.android",
            "com.apple.atve.androidtv.appletv", "com.plexapp.android", "com.mxtech.videoplayer.ad",
            "com.kick.mobile", "tv.pluto.android", "com.vimeo.android.videoapp"
        ).forEach { put(it, AppCategory.VIDEO) }
        // Música
        listOf(
            "com.spotify.music", "com.google.android.apps.youtube.music", "deezer.android.app",
            "com.soundcloud.android", "com.amazon.mp3", "com.shazam.android", "com.apple.android.music"
        ).forEach { put(it, AppCategory.MUSICA) }
        // Compras
        listOf(
            "com.mercadolibre", "com.amazon.mShop.android.shopping", "com.alibaba.aliexpresshd",
            "com.einnovation.temu", "com.zzkko", "com.grability.rappi", "com.shopee.co", "com.falabella.falabellaApp",
            "com.exito.appcompania", "com.ebay.mobile", "com.contextlogic.wish"
        ).forEach { put(it, AppCategory.COMPRAS) }
        // Juegos sueltos
        listOf(
            "com.roblox.client", "com.innersloth.spacemafia", "com.kiloo.subwaysurf", "com.mobile.legends",
            "com.ubisoft.hungrysharkevolution", "com.imangi.templerun2", "com.halfbrick.fruitninjafree",
            "com.dts.freefireth", "com.dts.freefiremax", "com.chess", "com.duolingo.chess"
        ).forEach { put(it, AppCategory.JUEGOS) }
        // Estudio y trabajo
        listOf(
            "com.google.android.apps.classroom", "com.duolingo", "com.notion.id", "com.google.android.keep",
            "org.wikipedia", "com.microsoft.teams", "us.zoom.videomeetings", "com.google.android.apps.meetings",
            "com.google.android.calendar", "com.google.android.gm", "com.microsoft.office.outlook",
            "com.adobe.reader", "com.canva.editor", "com.photomath.mathsolver", "com.quizlet.quizletandroid",
            "com.google.android.apps.translate", "com.todoist", "com.evernote", "com.dropbox.android",
            "com.google.android.apps.tasks", "com.wolfram.android.alpha", "com.symbolab.symbolablibrary"
        ).forEach { put(it, AppCategory.ESTUDIO) }
        // Noticias
        listOf(
            "com.google.android.apps.magazines", "flipboard.app", "com.eltiempo.etapp", "com.elespectador.app"
        ).forEach { put(it, AppCategory.NOTICIAS) }
        // Fotos
        listOf(
            "com.google.android.apps.photos", "com.sec.android.gallery3d", "com.miui.gallery",
            "com.vsco.cam", "com.picsart.studio", "com.lemon.lvoverseas.capcut", "com.camerasideas.instashot"
        ).forEach { put(it, AppCategory.FOTOS) }
        // Navegadores comunes (por si no se detectan por enlace)
        listOf(
            "com.android.chrome", "org.mozilla.firefox", "com.sec.android.app.sbrowser", "com.microsoft.emmx",
            "com.brave.browser", "com.opera.browser", "com.opera.mini.native", "com.duckduckgo.mobile.android",
            "com.mi.globalbrowser", "com.UCMobile.intl", "com.kiwibrowser.browser", "com.vivaldi.browser"
        ).forEach { put(it, AppCategory.NAVEGADORES) }
    }
}
