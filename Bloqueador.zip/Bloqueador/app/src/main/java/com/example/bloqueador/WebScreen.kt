@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.bloqueador

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

private const val PRIVATE_DNS_HOST = "family.adguard-dns.com"

@Composable
fun WebScreen(modifier: Modifier, serviceOn: Boolean) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var adult by remember { mutableStateOf(WebFilter.adultEnabled(ctx)) }
    var sites by remember { mutableStateOf(WebFilter.customSites(ctx)) }
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var copied by remember { mutableStateOf(false) }

    fun add() {
        val host = WebFilter.addSite(ctx, input)
        if (host == null) {
            error = "Escribe un sitio válido, por ejemplo ejemplo.com"
        } else {
            sites = WebFilter.customSites(ctx)
            input = ""
            error = null
        }
    }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Sitios web", style = MaterialTheme.typography.headlineLarge)
                Text(
                    "Bloquea páginas concretas y todo el contenido para adultos en los navegadores.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (!serviceOn) {
            item {
                SurfaceCard {
                    Text("Accesibilidad apagada", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "Sin el servicio de accesibilidad no se pueden vigilar los navegadores. Actívalo en la pestaña Protección.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            SurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Contenido para adultos", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "Bloquea sitios para adultos conocidos, direcciones con palabras como porn o xxx y búsquedas relacionadas.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Switch(
                        checked = adult,
                        onCheckedChange = { adult = it; WebFilter.setAdultEnabled(ctx, it) }
                    )
                }
            }
        }

        item {
            SurfaceCard {
                Text("Sitios bloqueados", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(2.dp))
                Text(
                    "También se bloquean sus subdominios (m.ejemplo.com, www.ejemplo.com...).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it; error = null },
                        label = { Text("Sitio web") },
                        placeholder = { Text("ejemplo.com") },
                        singleLine = true,
                        isError = error != null,
                        supportingText = { if (error != null) Text(error ?: "") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { add() }),
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.weight(1f)
                    )
                    Button(onClick = { add() }, modifier = Modifier.padding(top = 6.dp).height(48.dp)) {
                        Text("Añadir")
                    }
                }

                if (sites.isEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Todavía no has añadido ninguno.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Spacer(Modifier.height(6.dp))
                    sites.forEachIndexed { i, site ->
                        if (i > 0) SoftDivider()
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(site, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                            IconButton(onClick = {
                                WebFilter.removeSite(ctx, site)
                                sites = WebFilter.customSites(ctx)
                            }) {
                                Icon(
                                    Icons.Filled.Delete, contentDescription = "Quitar $site",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            SurfaceCard {
                Text("Refuerzo opcional: DNS privado", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(2.dp))
                Text(
                    "El bloqueo de arriba funciona en los navegadores. Para filtrar contenido para adultos y anuncios en TODAS las apps (AdGuard modo Familia), " +
                        "ve a Ajustes → Red e internet → DNS privado, elige «Nombre de host del proveedor» y escribe:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(PRIVATE_DNS_HOST, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(PRIVATE_DNS_HOST))
                        copied = true
                    }) { Text(if (copied) "Copiado" else "Copiar") }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Configúralo ANTES de activar el modo estricto: con el modo estricto activo, la pantalla de DNS privado " +
                        "queda protegida y no se puede abrir ni cambiar sin desactivarlo con tu contraseña.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
