package com.example.bloqueador

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings

/**
 * «Permiso especial» opcional: WRITE_SECURE_SETTINGS, que se da UNA vez con adb (o con instalar.bat):
 *   adb shell pm grant com.example.bloqueador android.permission.WRITE_SECURE_SETTINGS
 * No pide quitar cuentas. Con el modo estricto activo, Bloqueador:
 *  - vuelve a encender su Accesibilidad si alguien la apaga,
 *  - mantiene el DNS privado familiar (si «Fijar DNS familiar» está activo),
 *  - mantiene la hora automática.
 * Se revisa al abrir la app, al reiniciar, cada 15 min y justo después de que se apague el servicio.
 */
object Elevated {
    const val GRANT_COMMAND =
        "adb shell pm grant com.example.bloqueador android.permission.WRITE_SECURE_SETTINGS"

    fun has(ctx: Context): Boolean =
        ctx.checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED

    /** Enciende el servicio de Accesibilidad de Bloqueador sin quitar los demás. */
    fun enableAccessibility(ctx: Context): Boolean {
        if (!has(ctx)) return false
        if (isServiceEnabled(ctx)) return true
        return try {
            val me = ComponentName(ctx, BlockerService::class.java).flattenToString()
            val cur = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            val list = (cur ?: "").split(':').filter { it.isNotBlank() }.toMutableList()
            if (list.none { it.equals(me, true) }) list += me
            Settings.Secure.putString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, list.joinToString(":"))
            Settings.Secure.putInt(ctx.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            DebugLog.add("Accesibilidad reactivada con permiso especial")
            true
        } catch (e: Exception) {
            DebugLog.add("no se pudo reactivar Accesibilidad: ${e.javaClass.simpleName}")
            false
        }
    }

    /** Pone el DNS privado familiar. */
    fun setFamilyDns(ctx: Context): Boolean {
        if (!has(ctx)) return false
        return try {
            val cr = ctx.contentResolver
            if (Settings.Global.getString(cr, "private_dns_mode") != "hostname" ||
                Settings.Global.getString(cr, "private_dns_specifier") != DeviceOwner.DNS_HOST
            ) {
                Settings.Global.putString(cr, "private_dns_mode", "hostname")
                Settings.Global.putString(cr, "private_dns_specifier", DeviceOwner.DNS_HOST)
                DebugLog.add("DNS privado familiar puesto con permiso especial")
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Lo que se hace siempre que el modo estricto esté activo. Se puede llamar muchas veces. */
    fun enforce(ctx: Context) {
        if (!has(ctx) || !StrictMode.isEnabled(ctx)) return
        enableAccessibility(ctx)
        if (DeviceOwner.forceDns(ctx)) setFamilyDns(ctx)
        try {
            Settings.Global.putInt(ctx.contentResolver, Settings.Global.AUTO_TIME, 1)
        } catch (e: Exception) {
            // sin cambios
        }
    }

    /** Programa la revisión periódica (cada ~15 min, sobrevive a reinicios). */
    fun schedule(ctx: Context) {
        try {
            val js = ctx.getSystemService(JobScheduler::class.java)
            if (js.getPendingJob(JOB_ID) != null) return
            js.schedule(
                JobInfo.Builder(JOB_ID, ComponentName(ctx, GuardJob::class.java))
                    .setPeriodic(15 * 60 * 1000L)
                    .setPersisted(true)
                    .build()
            )
        } catch (e: Exception) {
            // mejor esfuerzo
        }
    }

    private const val JOB_ID = 4711
}

/** Revisión periódica: aunque la Accesibilidad esté apagada, este trabajo sigue corriendo. */
class GuardJob : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        Elevated.enforce(this)
        Tamper.checkAdmin(this)
        return false
    }

    override fun onStopJob(params: JobParameters?): Boolean = true
}

/** Al encender el teléfono o actualizar la app. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Elevated.enforce(context)
        Elevated.schedule(context)
    }
}
