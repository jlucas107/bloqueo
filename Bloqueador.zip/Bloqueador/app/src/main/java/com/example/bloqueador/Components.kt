package com.example.bloqueador

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

val DAY_NAMES = listOf("L", "M", "X", "J", "V", "S", "D")

// ---------------------------------------------------------------- Iconos de apps

object IconCache {
    private val cache = ConcurrentHashMap<String, ImageBitmap>()
    private const val PX = 128

    fun peek(pkg: String): ImageBitmap? = cache[pkg]

    /** Dibuja el ícono a mano en un bitmap (más fiable que toBitmap con íconos adaptativos). */
    private fun render(d: Drawable): ImageBitmap {
        val bmp = Bitmap.createBitmap(PX, PX, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        d.setBounds(0, 0, PX, PX)
        d.draw(canvas)
        return bmp.asImageBitmap()
    }

    fun preload(pkg: String, loader: () -> Drawable?) {
        if (cache.containsKey(pkg)) return
        try {
            loader()?.let { cache[pkg] = render(it) }
        } catch (e: Throwable) {
            // si falla, AppIcon muestra la inicial de la app
        }
    }

    fun get(ctx: Context, pkg: String): ImageBitmap? {
        cache[pkg]?.let { return it }
        preload(pkg) {
            val pm = ctx.packageManager
            pm.getLaunchIntentForPackage(pkg)?.let { pm.getActivityIcon(it) }
                ?: pm.getApplicationIcon(pkg)
        }
        return cache[pkg]
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 40.dp, label: String = "") {
    val ctx = LocalContext.current
    val icon by produceState<ImageBitmap?>(IconCache.peek(pkg), pkg) {
        if (value == null) value = withContext(Dispatchers.IO) { IconCache.get(ctx, pkg) }
    }
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.26f))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val img = icon
        if (img != null) {
            Image(bitmap = img, contentDescription = null, modifier = Modifier.fillMaxSize())
        } else if (label.isNotBlank()) {
            Text(
                label.first().uppercase(),
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun AppStack(packages: List<String>, size: Dp = 30.dp) {
    val shown = packages.take(4)
    val extra = packages.size - shown.size
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        shown.forEach { AppIcon(it, size) }
        if (extra > 0) {
            Text("+$extra", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---------------------------------------------------------------- Piezas básicas

@Composable
fun IconBubble(icon: ImageVector, tint: Color, background: Color, size: Dp = 44.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(background), contentAlignment = Alignment.Center) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun StateGlyph(ok: Boolean, size: Dp = 40.dp) {
    val c = if (ok) okColor() else warnColor()
    IconBubble(
        icon = if (ok) Icons.Filled.CheckCircle else Icons.Filled.Warning,
        tint = c, background = c.copy(alpha = 0.14f), size = size
    )
}

@Composable
fun Pill(text: String, container: Color, content: Color) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(container)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, color = content, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SurfaceCard(
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(contentPadding), content = content)
    }
}

@Composable
fun SoftDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant))
}

@Composable
fun DayDots(days: Set<Int>, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        DAY_NAMES.forEachIndexed { i, n ->
            val selected = (i + 1) in days
            Box(
                Modifier.size(26.dp).clip(CircleShape).background(
                    if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    n, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                    color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Línea de tiempo de 24 h

/**
 * Línea de 24 horas: la franja azul es el tiempo bloqueado y la marca ámbar es "ahora".
 * Si el horario cruza la medianoche se dibuja en dos tramos.
 */
@Composable
fun TimeBar(startMin: Int, endMin: Int, nowMin: Int?, enabled: Boolean = true, modifier: Modifier = Modifier) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    val fill = MaterialTheme.colorScheme.primary.copy(alpha = if (enabled) 1f else 0.35f)
    val marker = warnColor()
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant

    Column(modifier) {
        Canvas(Modifier.fillMaxWidth().height(16.dp)) {
            val w = size.width
            val barH = 10.dp.toPx()
            val top = (size.height - barH) / 2f
            val radius = CornerRadius(barH / 2f, barH / 2f)

            drawRoundRect(track, topLeft = Offset(0f, top), size = Size(w, barH), cornerRadius = radius)

            fun seg(a: Int, b: Int) {
                val x0 = w * a / 1440f
                val x1 = w * b / 1440f
                val width = (x1 - x0).coerceAtLeast(barH)
                drawRoundRect(
                    fill,
                    topLeft = Offset(x0.coerceAtMost(w - width), top),
                    size = Size(width, barH),
                    cornerRadius = radius
                )
            }
            if (startMin < endMin) {
                seg(startMin, endMin)
            } else if (startMin > endMin) {
                seg(startMin, 1440)
                seg(0, endMin)
            }

            if (nowMin != null) {
                val x = w * nowMin / 1440f
                val mw = 3.dp.toPx()
                drawRoundRect(
                    marker,
                    topLeft = Offset((x - mw / 2f).coerceIn(0f, w - mw), 0f),
                    size = Size(mw, size.height),
                    cornerRadius = CornerRadius(mw / 2f, mw / 2f)
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("0", "6", "12", "18", "24").forEach {
                Text(it, fontSize = 10.sp, color = labelColor)
            }
        }
    }
}
