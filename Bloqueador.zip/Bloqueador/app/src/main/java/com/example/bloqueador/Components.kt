package com.example.bloqueador

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

val DAY_NAMES = listOf("L", "M", "X", "J", "V", "S", "D")

// ---------------------------------------------------------------- Iconos de apps

object IconCache {
    private val cache = ConcurrentHashMap<String, ImageBitmap>()
    private const val PX = 128

    fun peek(pkg: String): ImageBitmap? = cache[pkg]

    /** Dibuja el ícono a mano en un bitmap (más fiable que toBitmap con íconos adaptativos). */
    private fun render(d: Drawable): ImageBitmap {
        val bmp = Bitmap.createBitmap(PX, PX, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        d.setBounds(0, 0, PX, PX)
        d.draw(canvas)
        return bmp.asImageBitmap()
    }

    fun preload(pkg: String, loader: () -> Drawable?) {
        if (cache.containsKey(pkg)) return
        try {
            loader()?.let { cache[pkg] = render(it) }
        } catch (e: Throwable) {
            // si falla, AppIcon muestra la inicial de la app
        }
    }

    fun get(ctx: Context, pkg: String): ImageBitmap? {
        cache[pkg]?.let { return it }
        preload(pkg) {
            val pm = ctx.packageManager
            pm.getLaunchIntentForPackage(pkg)?.let { pm.getActivityIcon(it) }
                ?: pm.getApplicationIcon(pkg)
        }
        return cache[pkg]
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 40.dp, label: String = "") {
    val ctx = LocalContext.current
    val icon by produceState<ImageBitmap?>(IconCache.peek(pkg), pkg) {
        if (value == null) value = withContext(Dispatchers.IO) { IconCache.get(ctx, pkg) }
    }
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.26f))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val img = icon
        if (img != null) {
            Image(bitmap = img, contentDescription = null, modifier = Modifier.fillMaxSize())
        } else if (label.isNotBlank()) {
            Text(
                label.first().uppercase(),
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun AppStack(packages: List<String>, size: Dp = 30.dp) {
    val shown = packages.take(4)
    val extra = packages.size - shown.size
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        shown.forEach { AppIcon(it, size) }
        if (extra > 0) {
            Text("+$extra", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---------------------------------------------------------------- Piezas básicas

@Composable
fun IconBubble(icon: ImageVector, tint: Color, background: Color, size: Dp = 44.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(background), contentAlignment = Alignment.Center) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun StateGlyph(ok: Boolean, size: Dp = 40.dp) {
    val c = if (ok) okColor() else warnColor()
    IconBubble(
        icon = if (ok) Icons.Filled.CheckCircle else Icons.Filled.Warning,
        tint = c, background = c.copy(alpha = 0.14f), size = size
    )
}

@Composable
fun Pill(text: String, container: Color, content: Color) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(container)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, color = content, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SurfaceCard(
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    // Sin borde ni sombra: la tarjeta blanca se separa del fondo Niebla solo por color.
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(contentPadding), content = content)
    }
}

@Composable
fun SoftDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant))
}

@Composable
fun DayDots(days: Set<Int>, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        DAY_NAMES.forEachIndexed { i, n ->
            val selected = (i + 1) in days
            Box(
                Modifier.size(26.dp).clip(RoundedCornerShape(8.dp)).background(
                    if (selected) color else MaterialTheme.colorScheme.surfaceVariant
                ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    n, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Línea de tiempo de 24 h

/**
 * Línea de 24 horas: la franja azul es el tiempo bloqueado y la marca ámbar es "ahora".
 * Si el horario cruza la medianoche se dibuja en dos tramos.
 */
@Composable
fun TimeBar(
    startMin: Int, endMin: Int, nowMin: Int?, enabled: Boolean = true, modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary
) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    val fill = color.copy(alpha = if (enabled) 1f else 0.35f)
    val marker = warnColor()
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant

    Column(modifier) {
        Canvas(Modifier.fillMaxWidth().height(16.dp)) {
            val w = size.width
            val barH = 10.dp.toPx()
            val top = (size.height - barH) / 2f
            val radius = CornerRadius(barH / 2f, barH / 2f)

            drawRoundRect(track, topLeft = Offset(0f, top), size = Size(w, barH), cornerRadius = radius)

            fun seg(a: Int, b: Int) {
                val x0 = w * a / 1440f
                val x1 = w * b / 1440f
                val width = (x1 - x0).coerceAtLeast(barH)
                drawRoundRect(
                    fill,
                    topLeft = Offset(x0.coerceAtMost(w - width), top),
                    size = Size(width, barH),
                    cornerRadius = radius
                )
            }
            if (startMin < endMin) {
                seg(startMin, endMin)
            } else if (startMin > endMin) {
                seg(startMin, 1440)
                seg(0, endMin)
            }

            if (nowMin != null) {
                val x = w * nowMin / 1440f
                val mw = 3.dp.toPx()
                drawRoundRect(
                    marker,
                    topLeft = Offset((x - mw / 2f).coerceIn(0f, w - mw), 0f),
                    size = Size(mw, size.height),
                    cornerRadius = CornerRadius(mw / 2f, mw / 2f)
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("0", "6", "12", "18", "24").forEach {
                Text(it, fontSize = 10.sp, color = labelColor)
            }
        }
    }
}

// ---------------------------------------------------------------- Encabezado oscuro común

/**
 * Banda Noche de arriba, igual en todas las pestañas: título, una línea de contexto y,
 * opcionalmente, algo propio de la pantalla (el reloj, el medidor de protección...).
 */
@Composable
fun ScreenHeader(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit = {}
) {
    Column(
        modifier.fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
            .background(Noche)
            .statusBarsPadding()
            .padding(start = 22.dp, end = 22.dp, top = 14.dp, bottom = 24.dp)
    ) {
        Text(title, style = MaterialTheme.typography.headlineLarge, color = Color.White)
        if (subtitle != null) {
            Spacer(Modifier.height(4.dp))
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.72f))
        }
        content()
    }
}

// ---------------------------------------------------------------- Reloj del día (24 h)

/** Un tramo del reloj: de [startMin] a [endMin] (minutos del día), en el color de su horario. */
class DialArc(val startMin: Int, val endMin: Int, val color: Color)

/** Los tramos de hoy de un horario (si cruza la medianoche, la parte que viene de ayer también). */
fun arcsForToday(s: Schedule, today: Int, color: Color): List<DialArc> {
    if (!s.enabled || s.startMin == s.endMin) return emptyList()
    val yesterday = if (today == 1) 7 else today - 1
    val out = mutableListOf<DialArc>()
    if (s.startMin < s.endMin) {
        if (today in s.days) out += DialArc(s.startMin, s.endMin, color)
    } else {
        if (yesterday in s.days) out += DialArc(0, s.endMin, color)
        if (today in s.days) out += DialArc(s.startMin, 1440, color)
    }
    return out
}

/**
 * El reloj de 24 horas: la medianoche arriba, el mediodía abajo.
 * Cada horario es un arco de su color; la aguja ámbar es la hora actual.
 * [lanes] agrupa los arcos por horario: cada horario va en su propio carril para que no se tapen.
 */
@Composable
fun DayDial(
    lanes: List<List<DialArc>>,
    nowMin: Int?,
    modifier: Modifier = Modifier,
    size: Dp = 248.dp,
    onDark: Boolean = true,
    center: @Composable BoxScope.() -> Unit = {}
) {
    val track = if (onDark) Color.White.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant
    val tick = if (onDark) Color.White.copy(alpha = 0.28f) else MaterialTheme.colorScheme.outline
    val label = if (onDark) Color.White.copy(alpha = 0.55f) else MaterialTheme.colorScheme.onSurfaceVariant
    val needle = Ambar
    val shown = lanes.filter { it.isNotEmpty() }.take(3)

    // Geometría en dp: un carril por horario, de fuera hacia dentro; las marcas de hora van justo por dentro
    // del último carril y el centro usa el espacio que queda libre.
    val laneCount = shown.size.coerceAtLeast(1)
    val stroke = if (laneCount == 1) 18.dp else 11.dp
    val gap = 4.dp
    val pad = 18.dp
    val outerEdge = size / 2 - pad
    val innerEdge = outerEdge - stroke * laneCount - gap * (laneCount - 1)
    val tickOut = innerEdge - 4.dp
    val tickIn = tickOut - 10.dp
    val centerSize = (tickIn - 6.dp) * 2

    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(this.size.width / 2f, this.size.height / 2f)
            val sw = stroke.toPx()
            fun laneR(i: Int) = outerEdge.toPx() - sw / 2f - i * (sw + gap.toPx())

            // Pista de cada carril
            for (i in 0 until laneCount) drawCircle(track, radius = laneR(i), center = c, style = Stroke(sw))

            // Marcas de cada hora (más largas cada 6 h)
            for (h in 0 until 24) {
                val a = Math.toRadians(h * 15.0 - 90.0)
                val major = h % 6 == 0
                val r1 = tickOut.toPx()
                val r0 = if (major) tickIn.toPx() else r1 - 5.dp.toPx()
                drawLine(
                    tick,
                    Offset(c.x + (r0 * Math.cos(a)).toFloat(), c.y + (r0 * Math.sin(a)).toFloat()),
                    Offset(c.x + (r1 * Math.cos(a)).toFloat(), c.y + (r1 * Math.sin(a)).toFloat()),
                    strokeWidth = if (major) 2.dp.toPx() else 1.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // Arcos de los horarios, un carril por horario
            shown.forEachIndexed { lane, arcs ->
                val r = laneR(lane)
                arcs.forEach { arc ->
                    val sweep = (arc.endMin - arc.startMin) / 1440f * 360f
                    drawArc(
                        arc.color,
                        startAngle = arc.startMin / 1440f * 360f - 90f,
                        sweepAngle = sweep.coerceAtLeast(2f),
                        useCenter = false,
                        topLeft = Offset(c.x - r, c.y - r),
                        size = Size(r * 2, r * 2),
                        style = Stroke(sw, cap = StrokeCap.Round)
                    )
                }
            }

            // Aguja del «ahora»: cruza todos los carriles y termina en un punto por fuera.
            if (nowMin != null) {
                val a = Math.toRadians(nowMin / 1440.0 * 360.0 - 90.0)
                val rIn = tickIn.toPx() - 2.dp.toPx()
                val rOut = outerEdge.toPx() + 6.dp.toPx()
                val p0 = Offset(c.x + (rIn * Math.cos(a)).toFloat(), c.y + (rIn * Math.sin(a)).toFloat())
                val p1 = Offset(c.x + (rOut * Math.cos(a)).toFloat(), c.y + (rOut * Math.sin(a)).toFloat())
                drawLine(needle, p0, p1, strokeWidth = 3.5.dp.toPx(), cap = StrokeCap.Round)
                drawCircle(needle, radius = 5.dp.toPx(), center = p1)
            }
        }
        // Horas de referencia, fuera del aro
        Text("0", style = MaterialTheme.typography.labelSmall, color = label, modifier = Modifier.align(Alignment.TopCenter))
        Text("6", style = MaterialTheme.typography.labelSmall, color = label, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 2.dp))
        Text("12", style = MaterialTheme.typography.labelSmall, color = label, modifier = Modifier.align(Alignment.BottomCenter))
        Text("18", style = MaterialTheme.typography.labelSmall, color = label, modifier = Modifier.align(Alignment.CenterStart).padding(start = 2.dp))
        Box(Modifier.size(centerSize), contentAlignment = Alignment.Center, content = center)
    }
}

// ---------------------------------------------------------------- Medidor de protección

/** Una capa de protección y si está encendida. */
class Layer(val name: String, val on: Boolean)

/** Barra de segmentos: cuántas capas de protección están encendidas (va sobre el encabezado Noche). */
@Composable
fun ProtectionMeter(layers: List<Layer>, modifier: Modifier = Modifier) {
    val on = layers.count { it.on }
    val ok = Color(0xFF5BD3A2)
    Column(modifier) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text("$on", style = MaterialTheme.typography.displayMedium, color = Color.White)
            Text(
                " de ${layers.size} capas activas",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.72f),
                modifier = Modifier.padding(bottom = 9.dp)
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            layers.forEach { l ->
                Box(
                    Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp))
                        .background(if (l.on) ok else Color.White.copy(alpha = 0.14f))
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        val missing = layers.filter { !it.on }.map { it.name }
        Text(
            if (missing.isEmpty()) "Todo encendido. Nadie puede saltarse los bloqueos fácilmente."
            else "Falta: " + missing.joinToString(", ") + ".",
            style = MaterialTheme.typography.bodySmall,
            color = Color.White.copy(alpha = 0.72f)
        )
    }
}
