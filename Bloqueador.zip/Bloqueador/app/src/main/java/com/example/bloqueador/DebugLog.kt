package com.example.bloqueador

/**
 * Registro interno. La pantalla de Diagnóstico se quitó, así que no guarda nada:
 * así no se gasta tiempo armando textos en cada evento.
 */
object DebugLog {
    @Suppress("UNUSED_PARAMETER")
    fun add(msg: String) {}

    fun snapshot(): List<String> = emptyList()

    fun clear() {}
}
