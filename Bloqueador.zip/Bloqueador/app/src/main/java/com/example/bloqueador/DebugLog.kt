package com.example.bloqueador

import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/** Registro corto en memoria para ver qué detecta el servicio (se muestra en Protección). */
object DebugLog {
    private val lines = ArrayDeque<String>()

    @Synchronized
    fun add(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        lines.addFirst("$t $msg")
        while (lines.size > 30) lines.removeLast()
    }

    @Synchronized
    fun snapshot(): List<String> = lines.toList()

    @Synchronized
    fun clear() = lines.clear()
}
