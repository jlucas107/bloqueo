package com.example.bloqueador

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class BlockActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val title = intent.getStringExtra("title") ?: ""
        val subtitle = intent.getStringExtra("subtitle") ?: ""
        val schedule = intent.getStringExtra("schedule") ?: ""
        val until = intent.getStringExtra("until") ?: ""

        setContent {
            BloqueadorTheme {
                BackHandler { goHome() }
                BlockScreen(title, subtitle, schedule, until) { goHome() }
            }
        }
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
        finish()
    }
}

/**
 * Pantalla de bloqueo: fondo Noche y, si viene de un horario, el reloj con el tramo que falta
 * y la hora de desbloqueo en grande. Es lo único que hay que leer.
 */
@Composable
private fun BlockScreen(title: String, subtitle: String, schedule: String, until: String, onHome: () -> Unit) {
    val soft = Color.White.copy(alpha = 0.72f)
    val now = java.time.LocalTime.now()
    val nowMin = now.hour * 60 + now.minute
    val untilMin = until.split(":").let { p ->
        if (p.size == 2) (p[0].toIntOrNull() ?: -1) * 60 + (p[1].toIntOrNull() ?: 0) else -1
    }

    Column(
        Modifier.fillMaxSize().background(Noche).systemBarsPadding().padding(horizontal = 28.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            IconBubble(Icons.Filled.Lock, Color.White, NocheAlta, size = 44.dp)
            Text("Bloqueador", color = soft, style = MaterialTheme.typography.titleMedium)
        }

        if (untilMin >= 0) {
            // El tramo que queda bloqueado, de ahora hasta el desbloqueo.
            val arcs = if (untilMin > nowMin) listOf(DialArc(nowMin, untilMin, ScheduleHues[0]))
            else listOf(DialArc(nowMin, 1440, ScheduleHues[0]), DialArc(0, untilMin, ScheduleHues[0]))
            DayDial(
                lanes = listOf(arcs),
                nowMin = nowMin,
                modifier = Modifier.align(Alignment.CenterHorizontally),
                size = 220.dp
            ) {
                Icon(Icons.Filled.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(40.dp))
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (until.isNotBlank()) {
                Text("Se desbloquea a las", color = soft, style = MaterialTheme.typography.bodyLarge)
                Text(until, color = Color.White, style = MaterialTheme.typography.displayLarge)
                Spacer(Modifier.height(6.dp))
            }
            Text(title, color = Color.White, style = MaterialTheme.typography.headlineSmall)
            if (subtitle.isNotBlank()) {
                Text(subtitle, color = soft, style = MaterialTheme.typography.bodyLarge)
            }
            if (schedule.isNotBlank()) {
                Text("Horario «$schedule»", color = soft, style = MaterialTheme.typography.bodyMedium)
            }
        }

        Button(
            onClick = onHome,
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Noche),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("Volver al inicio", style = MaterialTheme.typography.labelLarge) }
    }
}
