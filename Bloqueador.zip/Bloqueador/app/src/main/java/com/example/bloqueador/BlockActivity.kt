package com.example.bloqueador

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class BlockActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val title = intent.getStringExtra("title") ?: ""
        val subtitle = intent.getStringExtra("subtitle") ?: ""
        val schedule = intent.getStringExtra("schedule") ?: ""
        val until = intent.getStringExtra("until") ?: ""

        setContent {
            BloqueadorTheme {
                BackHandler { goHome() }
                BlockScreen(title, subtitle, schedule, until) { goHome() }
            }
        }
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
        finish()
    }
}

/** Fondo tinta plano; el protagonista es la hora a la que se desbloquea. */
@Composable
private fun BlockScreen(title: String, subtitle: String, schedule: String, until: String, onHome: () -> Unit) {
    val soft = Color.White.copy(alpha = 0.7f)

    Column(
        Modifier.fillMaxSize().background(InkNavy).systemBarsPadding().padding(28.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            IconBubble(Icons.Filled.Lock, Color.White, Color.White.copy(alpha = 0.14f), size = 44.dp)
            Text("Bloqueador", color = soft, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (until.isNotBlank()) {
                Text("Se desbloquea a las", color = soft, fontSize = 18.sp)
                Text(
                    until, color = Color.White, fontSize = 96.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = (-3).sp, lineHeight = 100.sp
                )
            }
            Text(title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, lineHeight = 30.sp)
            if (subtitle.isNotBlank()) {
                Text(subtitle, color = soft, fontSize = 16.sp, lineHeight = 22.sp)
            }
            if (schedule.isNotBlank()) {
                Text("Horario: $schedule", color = soft, fontSize = 14.sp)
            }
        }

        Button(
            onClick = onHome,
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = InkNavy),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("Ir al inicio", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
    }
}
