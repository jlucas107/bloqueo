package com.example.bloqueador

import android.content.Context
import java.text.Normalizer
import java.util.Locale

/**
 * Decide si una dirección (o un texto escrito en la barra del navegador) debe bloquearse.
 *
 * Tres capas:
 *  1. Tu lista de sitios bloqueados (incluye subdominios: bloquear "ejemplo.com" bloquea "m.ejemplo.com").
 *  2. Lista incluida de sitios para adultos.
 *  3. Palabras clave en la dirección o en lo que se busca (porn, xxx, sexo...).
 */
object WebFilter {

    class Verdict(val label: String, val subtitle: String)

    private const val PREFS = "webfilter"
    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ------------------------------------------------------------ Ajustes

    /** Filtro de contenido para adultos (activado por defecto). */
    fun adultEnabled(ctx: Context): Boolean = p(ctx).getBoolean("adult", true)

    fun setAdultEnabled(ctx: Context, value: Boolean) {
        p(ctx).edit().putBoolean("adult", value).apply()
    }

    private fun siteSet(ctx: Context): Set<String> = p(ctx).getStringSet("sites", null) ?: emptySet()

    fun customSites(ctx: Context): List<String> = siteSet(ctx).sorted()

    /** Guarda un sitio. Devuelve el dominio normalizado, o null si lo escrito no es válido. */
    fun addSite(ctx: Context, input: String): String? {
        val host = hostOf(input) ?: return null
        val set = siteSet(ctx).toMutableSet()
        set.add(host)
        p(ctx).edit().putStringSet("sites", set).apply()
        return host
    }

    fun removeSite(ctx: Context, site: String) {
        val set = siteSet(ctx).toMutableSet()
        set.remove(site)
        p(ctx).edit().putStringSet("sites", set).apply()
    }

    /** ¿Hay algo que vigilar? Así el servicio no gasta recursos si todo está apagado. */
    fun isActive(ctx: Context): Boolean = adultEnabled(ctx) || siteSet(ctx).isNotEmpty()

    // ------------------------------------------------------------ Decisión

    /** [raw] es el texto de la barra de direcciones: una URL, un dominio o lo que la persona esté escribiendo. */
    fun check(ctx: Context, raw: String): Verdict? {
        val text = raw.trim()
        if (text.isEmpty()) return null
        val host = hostOf(text)
        val adult = adultEnabled(ctx)

        if (host != null) {
            if (siteSet(ctx).any { matches(host, it) }) {
                return Verdict(host, "$host está en tu lista de sitios bloqueados.")
            }
            if (adult) {
                if (ADULT_DOMAINS.any { matches(host, it) }) {
                    return Verdict(host, "Contenido para adultos bloqueado.")
                }
                // En sitios de referencia (enciclopedias, salud) solo se revisa el dominio, no el artículo.
                val scan = if (SAFE_HOSTS.any { matches(host, it) }) host else text
                if (hasAdultToken(scan)) return Verdict(host, "Contenido para adultos bloqueado.")
            }
            return null
        }

        // Texto con espacios o sin punto: lo que se escribe o se busca.
        if (adult && hasAdultToken(text)) {
            return Verdict("búsqueda", "Búsqueda con contenido para adultos bloqueada.")
        }
        return null
    }

    // ------------------------------------------------------------ Ayudas

    private val HOST_CHARS = Regex("^[\\p{L}\\p{N}.-]+$")
    private val SPLIT = Regex("[^a-z0-9]+")
    private val ACCENTS = Regex("\\p{Mn}+")
    private val XL = Regex("x+l") // tallas: xxxl no es contenido para adultos

    private fun matches(host: String, domain: String) = host == domain || host.endsWith(".$domain")

    /** Saca el dominio de una URL o texto. Devuelve null si no parece una dirección web. */
    fun hostOf(raw: String): String? {
        var s = raw.trim().lowercase(Locale.ROOT)
        if (s.isEmpty() || s.any { it.isWhitespace() }) return null
        if ("://" in s) s = s.substringAfter("://")
        s = s.substringBefore('/').substringBefore('?').substringBefore('#')
        s = s.substringAfterLast('@').substringBefore(':')
        s = s.trimEnd('.')
        if (s.startsWith("www.")) s = s.removePrefix("www.")
        if (!s.contains('.') || !HOST_CHARS.matches(s)) return null
        return s
    }

    private fun hasAdultToken(s: String): Boolean {
        val clean = ACCENTS.replace(Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD), "")
        return clean.split(SPLIT).any { it.isNotEmpty() && isAdultToken(it) }
    }

    private fun isAdultToken(t: String): Boolean {
        if (t in ADULT_TOKENS) return true
        if (XL.matches(t)) return false
        return STRONG.any { t.contains(it) }
    }

    // ------------------------------------------------------------ Listas

    /** Si una palabra de la dirección CONTIENE alguno de estos fragmentos, se bloquea. */
    private val STRONG = listOf(
        "porn", "xxx", "hentai", "xvideos", "xnxx", "xhamster", "brazzers",
        "chaturbate", "stripchat", "livejasmin", "bongacams", "onlyfans", "rule34"
    )

    /** Palabras completas (así "sussex" o "essex" no se bloquean por llevar "sex"). */
    private val ADULT_TOKENS = setOf(
        "sex", "sexo", "sexe", "nude", "nudes", "nsfw", "porno", "pornos",
        "erotico", "erotica", "erotic", "desnuda", "desnudas", "desnudo", "desnudos",
        "tetas", "putas", "follando", "milf", "bdsm", "fetish", "fetiche",
        "camgirl", "camgirls", "gonewild", "swinger", "swingers", "e621"
    )

    /** Sitios de referencia donde no se revisa el texto del artículo, solo el dominio. */
    private val SAFE_HOSTS = listOf(
        "wikipedia.org", "wikimedia.org", "who.int", "nih.gov", "medlineplus.gov",
        "mayoclinic.org", "britannica.com", "cdc.gov"
    )

    /** Lista inicial; puedes añadir más desde la app en «Sitios web». */
    private val ADULT_DOMAINS = listOf(
        "pornhub.com", "xvideos.com", "xnxx.com", "xhamster.com", "redtube.com",
        "youporn.com", "spankbang.com", "eporner.com", "tnaflix.com", "tube8.com",
        "motherless.com", "thumbzilla.com", "4tube.com", "beeg.com", "drtuber.com",
        "hqporner.com", "txxx.com", "erome.com", "fapello.com", "camsoda.com",
        "myfreecams.com", "cam4.com", "imlive.com", "flirt4free.com", "fansly.com",
        "manyvids.com", "clips4sale.com", "e621.net", "nhentai.net", "hanime.tv",
        "gelbooru.com", "literotica.com", "sex.com", "realitykings.com", "bangbros.com",
        "mofos.com", "naughtyamerica.com", "pornpics.com", "xtube.com", "porntrex.com",
        "fuq.com", "heavy-r.com", "efukt.com", "xmovies8.es", "playboy.com",
        "adultfriendfinder.com", "ashleymadison.com", "livejasmin.com", "stripchat.com",
        "chaturbate.com", "bongacams.com", "onlyfans.com", "rule34.xxx"
    )
}
