package com.example.bloqueador

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/** Mientras este administrador esté activo, Android no deja desinstalar la app. */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Si desactivas esto, Bloqueador podrá desinstalarse."
}
