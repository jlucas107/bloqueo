@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.bloqueador

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.time.LocalDateTime
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun HomeScreen(
    modifier: Modifier,
    schedules: List<Schedule>,
    now: LocalDateTime,
    serviceOn: Boolean,
    onOpenAccessibility: () -> Unit,
    onAdd: () -> Unit,
    onEdit: (Schedule) -> Unit,
    onToggle: (Schedule, Boolean) -> Unit,
    onDelete: (Schedule) -> Unit
) {
    var toDelete by remember { mutableStateOf<Schedule?>(null) }
    val activeCount = schedules.count { it.isActiveAt(now) }

    val dayName = now.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.forLanguageTag("es"))
        .replaceFirstChar { it.uppercase() }
    val dateText = "$dayName ${now.dayOfMonth}, ${formatMinutes(now.hour * 60 + now.minute)}"

    val sentence = when {
        !serviceOn -> "El bloqueo está apagado"
        activeCount > 0 -> "Bloqueando $activeCount ${if (activeCount == 1) "horario" else "horarios"}"
        schedules.isEmpty() -> "Crea tu primer horario"
        else -> "Nada bloqueado ahora"
    }
    val detail = when {
        !serviceOn -> "Activa la accesibilidad para que funcione."
        activeCount > 0 -> "Las apps de esos horarios están cerradas."
        else -> "Tus horarios se activan y se desactivan solos."
    }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 104.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(dateText, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(sentence, style = MaterialTheme.typography.headlineLarge)
                Text(detail, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        if (!serviceOn) {
            item { WarnBanner(onOpenAccessibility) }
        }

        if (schedules.isEmpty()) {
            item { EmptyState(onAdd) }
        } else {
            item { Text("Tus horarios", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 6.dp)) }
            items(schedules, key = { it.id }) { s ->
                ScheduleCard(
                    s = s, now = now,
                    onClick = { onEdit(s) },
                    onToggle = { onToggle(s, it) },
                    onDelete = { toDelete = s }
                )
            }
        }
    }

    toDelete?.let { s ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("¿Borrar este horario?") },
            text = { Text("Se eliminará «${s.name}». No se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = { onDelete(s); toDelete = null }) {
                    Text("Borrar", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun WarnBanner(onAction: () -> Unit) {
    val warn = warnColor()
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(warn.copy(alpha = 0.12f))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        IconBubble(Icons.Filled.Warning, warn, warn.copy(alpha = 0.18f), size = 40.dp)
        Text(
            "Sin accesibilidad, los horarios no bloquean nada.",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        FilledTonalButton(onClick = onAction) { Text("Activar") }
    }
}

@Composable
private fun EmptyState(onAdd: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        IconBubble(
            Icons.Filled.DateRange,
            MaterialTheme.colorScheme.onPrimaryContainer,
            MaterialTheme.colorScheme.primaryContainer,
            size = 72.dp
        )
        Text("Aún no hay horarios", style = MaterialTheme.typography.titleLarge)
        Text(
            "Elige las apps, los días y la franja de horas. Se bloquean y desbloquean solas.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        FilledTonalButton(onClick = onAdd) { Text("Crear horario") }
    }
}

@Composable
private fun ScheduleCard(
    s: Schedule,
    now: LocalDateTime,
    onClick: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onDelete: () -> Unit
) {
    val active = s.isActiveAt(now)
    val dim = if (s.enabled) 1f else 0.5f

    SurfaceCard(Modifier.clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                s.name, style = MaterialTheme.typography.titleMedium,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).alpha(dim)
            )
            Switch(checked = s.enabled, onCheckedChange = onToggle)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "${formatMinutes(s.startMin)} – ${formatMinutes(s.endMin)}",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.alpha(dim)
            )
            if (active) Pill("Activo ahora", MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
        }
        Spacer(Modifier.height(12.dp))
        TimeBar(
            startMin = s.startMin, endMin = s.endMin,
            nowMin = now.hour * 60 + now.minute,
            enabled = s.enabled
        )
        Spacer(Modifier.height(12.dp))
        DayDots(s.days, Modifier.alpha(dim))
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppStack(s.packages.toList())
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Borrar horario", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
