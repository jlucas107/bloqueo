@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.bloqueador

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.time.LocalDateTime
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun HomeScreen(
    modifier: Modifier,
    schedules: List<Schedule>,
    now: LocalDateTime,
    serviceOn: Boolean,
    onOpenAccessibility: () -> Unit,
    onAdd: () -> Unit,
    onEdit: (Schedule) -> Unit,
    onToggle: (Schedule, Boolean) -> Unit,
    onDelete: (Schedule) -> Unit
) {
    var toDelete by remember { mutableStateOf<Schedule?>(null) }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 112.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { DayHero(schedules, now, serviceOn) }

        if (!serviceOn) {
            item { WarnBanner(onOpenAccessibility, Modifier.padding(horizontal = 20.dp)) }
        }

        if (schedules.isEmpty()) {
            item { EmptyState(onAdd) }
        } else {
            item {
                Text(
                    "Tus horarios",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(start = 22.dp, end = 22.dp, top = 10.dp)
                )
            }
            itemsIndexed(schedules, key = { _, s -> s.id }) { i, s ->
                ScheduleCard(
                    s = s, now = now, hue = scheduleHue(i),
                    onClick = { onEdit(s) },
                    onToggle = { onToggle(s, it) },
                    onDelete = { toDelete = s },
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }
    }

    toDelete?.let { s ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("¿Borrar este horario?") },
            text = { Text("Se eliminará «${s.name}». No se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = { onDelete(s); toDelete = null }) {
                    Text("Borrar", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }
}

/** La parte de arriba: la fecha, el reloj del día y en el centro el estado de ahora. */
@Composable
private fun DayHero(schedules: List<Schedule>, now: LocalDateTime, serviceOn: Boolean) {
    val nowMin = now.hour * 60 + now.minute
    val today = now.dayOfWeek.value
    val dayName = now.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.forLanguageTag("es"))
        .replaceFirstChar { it.uppercase() }

    val lanes = schedules.mapIndexed { i, s -> arcsForToday(s, today, scheduleHue(i)) }
    val active = schedules.filter { it.isActiveAt(now) }
    val next = schedules
        .filter { it.enabled && today in it.days && it.startMin > nowMin }
        .minByOrNull { it.startMin }

    val (state, detail) = when {
        !serviceOn -> "Apagado" to "Activa la accesibilidad"
        active.size == 1 -> "Bloqueando" to "${active[0].name} hasta las ${formatMinutes(active[0].endMin)}"
        active.size > 1 -> "Bloqueando" to "${active.size} horarios a la vez"
        next != null -> "Libre" to "${next.name} empieza a las ${formatMinutes(next.startMin)}"
        schedules.isEmpty() -> "Libre" to "Aún no tienes horarios"
        else -> "Libre" to "No hay más bloqueos hoy"
    }

    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
            .background(Noche)
            .statusBarsPadding()
            .padding(start = 22.dp, end = 22.dp, top = 14.dp, bottom = 26.dp)
    ) {
        Text(
            "$dayName ${now.dayOfMonth}",
            style = MaterialTheme.typography.headlineLarge,
            color = Color.White
        )
        Text(
            "Así va tu día",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White.copy(alpha = 0.72f)
        )
        Spacer(Modifier.height(12.dp))
        DayDial(
            lanes = lanes,
            nowMin = nowMin,
            modifier = Modifier.align(Alignment.CenterHorizontally),
            size = 268.dp
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    formatMinutes(nowMin),
                    style = MaterialTheme.typography.labelLarge,
                    color = Ambar
                )
                // Con más carriles el centro del reloj es más pequeño: el estado se achica para caber.
                val laneCount = lanes.count { it.isNotEmpty() }
                Text(
                    state,
                    style = if (laneCount >= 3) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineSmall,
                    maxLines = 1,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.72f),
                    textAlign = TextAlign.Center,
                    maxLines = 3
                )
            }
        }
    }
}

@Composable
private fun WarnBanner(onAction: () -> Unit, modifier: Modifier = Modifier) {
    val warn = warnColor()
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(warn.copy(alpha = 0.14f))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        IconBubble(Icons.Filled.Warning, warn, warn.copy(alpha = 0.18f), size = 40.dp)
        Text(
            "Sin accesibilidad, los horarios no bloquean nada.",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        Button(onClick = onAction) { Text("Activar") }
    }
}

@Composable
private fun EmptyState(onAdd: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        IconBubble(
            Icons.Filled.DateRange,
            MaterialTheme.colorScheme.onPrimaryContainer,
            MaterialTheme.colorScheme.primaryContainer,
            size = 72.dp
        )
        Text("Protege tus primeras horas", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text(
            "Elige las apps, los días y la franja de horas. Se bloquean y se desbloquean solas, y aparecen en el reloj.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Button(onClick = onAdd) { Text("Crear horario") }
    }
}

/** Tarjeta de un horario. La franja de color de la izquierda es la misma de su arco en el reloj. */
@Composable
private fun ScheduleCard(
    s: Schedule,
    now: LocalDateTime,
    hue: Color,
    onClick: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val active = s.isActiveAt(now)
    val dim = if (s.enabled) 1f else 0.45f

    Card(
        modifier = modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(Modifier.width(8.dp).fillMaxHeight().background(hue.copy(alpha = if (s.enabled) 1f else 0.35f)))
            Column(Modifier.weight(1f).padding(start = 16.dp, end = 12.dp, top = 14.dp, bottom = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).alpha(dim)) {
                        Text(
                            s.name, style = MaterialTheme.typography.titleMedium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "${formatMinutes(s.startMin)} – ${formatMinutes(s.endMin)}",
                            style = MaterialTheme.typography.headlineMedium
                        )
                    }
                    Switch(checked = s.enabled, onCheckedChange = onToggle)
                }
                if (active) {
                    Spacer(Modifier.height(6.dp))
                    Pill("Bloqueando ahora", Ambar.copy(alpha = 0.22f), MaterialTheme.colorScheme.onSecondaryContainer)
                }
                Spacer(Modifier.height(12.dp))
                DayDots(s.days, Modifier.alpha(dim), color = hue)
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppStack(s.packages.toList())
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Filled.Delete, contentDescription = "Borrar horario", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
