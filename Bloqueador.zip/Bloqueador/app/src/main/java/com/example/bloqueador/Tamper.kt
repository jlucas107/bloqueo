package com.example.bloqueador

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Detecta cuándo alguien se saltó la protección y lo deja anotado para que lo veas en Protección.
 *
 * Sin propietario del dispositivo, Android deja arrancar en modo seguro: ahí Bloqueador no funciona
 * y se puede quitar la anti-desinstalación. No se puede impedir, pero sí detectar:
 *  - Arranques en los que el servicio nunca se encendió (cuenta de arranques que se salta números).
 *  - Ratos en que el servicio estuvo apagado sin reiniciar el teléfono.
 *  - Anti-desinstalación quitada con el modo estricto activo.
 */
object Tamper {
    private fun p(ctx: Context) = ctx.getSharedPreferences("tamper", Context.MODE_PRIVATE)

    private fun bootCount(ctx: Context): Int =
        try {
            Settings.Global.getInt(ctx.contentResolver, Settings.Global.BOOT_COUNT)
        } catch (e: Exception) {
            -1
        }

    fun alerts(ctx: Context): List<String> =
        (p(ctx).getString("alerts", "") ?: "").split('\n').filter { it.isNotBlank() }

    fun record(ctx: Context, msg: String) {
        val t = SimpleDateFormat("dd/MM HH:mm", Locale.US).format(Date())
        val list = (listOf("$t  $msg") + alerts(ctx)).take(15)
        p(ctx).edit().putString("alerts", list.joinToString("\n")).apply()
        DebugLog.add("ALERTA: $msg")
    }

    fun clear(ctx: Context) = p(ctx).edit().remove("alerts").apply()

    /** El servicio sigue vivo (se llama cada pocos segundos). */
    fun heartbeat(ctx: Context) {
        p(ctx).edit()
            .putLong("beat", SystemClock.elapsedRealtime())
            .putInt("boot", bootCount(ctx))
            .apply()
    }

    /** Al encenderse el servicio: revisa si hubo un hueco sospechoso desde la última vez. */
    fun onServiceStart(ctx: Context) {
        val strict = StrictMode.isEnabled(ctx)
        val lastBoot = p(ctx).getInt("boot", -1)
        val lastBeat = p(ctx).getLong("beat", 0L)
        val boot = bootCount(ctx)
        if (strict && lastBoot >= 0 && boot >= 0) {
            if (boot == lastBoot) {
                val gapMin = (SystemClock.elapsedRealtime() - lastBeat) / 60_000
                if (gapMin >= 3) {
                    record(ctx, "Bloqueador estuvo apagado unos $gapMin min sin reiniciar (¿se quitó la Accesibilidad?).")
                }
            } else if (boot > lastBoot + 1) {
                record(ctx, "Hubo ${boot - lastBoot - 1} arranque(s) sin Bloqueador (posible modo seguro).")
            }
        }
        heartbeat(ctx)
        checkAdmin(ctx)
    }

    /** Con el modo estricto activo, la anti-desinstalación no debería estar apagada. */
    fun checkAdmin(ctx: Context) {
        val strict = StrictMode.isEnabled(ctx)
        val missing = strict && !isAdminActive(ctx)
        val noted = p(ctx).getBoolean("admin_noted", false)
        if (missing && !noted) {
            record(ctx, "Se quitó la anti-desinstalación con el modo estricto activo.")
            p(ctx).edit().putBoolean("admin_noted", true).apply()
        } else if (!missing && noted) {
            p(ctx).edit().putBoolean("admin_noted", false).apply()
        }
    }
}

/** Exclusión del ahorro de batería, para que el teléfono no duerma a Bloqueador. */
object Battery {
    /** Hasta cuándo el servicio deja pasar el diálogo de batería que abrimos nosotros. */
    @Volatile var allowDialogUntil = 0L

    fun isExempt(ctx: Context): Boolean =
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)

    fun request(ctx: Context) {
        allowDialogUntil = SystemClock.elapsedRealtime() + 30_000
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
            )
        } catch (e: Exception) {
            allowDialogUntil = 0L
            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }
}
