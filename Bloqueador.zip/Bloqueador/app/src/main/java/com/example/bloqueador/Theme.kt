package com.example.bloqueador

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * Identidad visual de Bloqueador: «el reloj del día».
 * - Noche: el color de las horas protegidas. Encabezados, pantalla de bloqueo, ícono.
 * - Niebla: fondo claro y tranquilo donde viven las listas.
 * - Cobalto: acciones y elementos activos.
 * - Ámbar: SOLO marca el «ahora» (la aguja del reloj y lo que está activo en este momento).
 * Títulos y horas en Bricolage Grotesque (con carácter); texto en Figtree (muy legible).
 */

val Noche = Color(0xFF151B3D)
val NocheAlta = Color(0xFF222A57)     // superficies dentro de Noche
val Niebla = Color(0xFFF1F2F7)
val Cobalto = Color(0xFF3446D4)
val Ambar = Color(0xFFF2A93B)
val Coral = Color(0xFFD9534A)
val Pino = Color(0xFF1E9467)

/** Se conserva el nombre antiguo para no romper referencias. */
val InkNavy = Noche

/** Color propio de cada horario: el mismo en su arco del reloj y en su tarjeta. Sin ámbar (es del «ahora»). */
val ScheduleHues = listOf(
    Color(0xFF6C7BFF), // cobalto claro
    Color(0xFF22B3AC), // turquesa
    Color(0xFFB57BFF), // violeta
    Color(0xFFEF6F98), // rosa
    Color(0xFF8DBA3F), // oliva
    Color(0xFF4FA3E8)  // celeste
)

fun scheduleHue(index: Int): Color = ScheduleHues[((index % ScheduleHues.size) + ScheduleHues.size) % ScheduleHues.size]

val Bricolage = FontFamily(
    Font(R.font.bricolage_500, FontWeight.Medium),
    Font(R.font.bricolage_700, FontWeight.Bold),
    Font(R.font.bricolage_800, FontWeight.ExtraBold)
)

val Figtree = FontFamily(
    Font(R.font.figtree_400, FontWeight.Normal),
    Font(R.font.figtree_500, FontWeight.Medium),
    Font(R.font.figtree_600, FontWeight.SemiBold),
    Font(R.font.figtree_700, FontWeight.Bold)
)

private val LightColors = lightColorScheme(
    primary = Cobalto, onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE1FF), onPrimaryContainer = Color(0xFF101A63),
    secondary = Noche, onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE7C2), onSecondaryContainer = Color(0xFF5A3A00),
    tertiary = Pino, onTertiary = Color.White,
    background = Niebla, onBackground = Color(0xFF151B3D),
    surface = Color.White, onSurface = Color(0xFF151B3D),
    surfaceVariant = Color(0xFFE6E8F1), onSurfaceVariant = Color(0xFF5A5F7A),
    surfaceContainerHighest = Color(0xFFE6E8F1),
    outline = Color(0xFFB7BBD0), outlineVariant = Color(0xFFE0E2EC),
    error = Coral, onError = Color.White,
    errorContainer = Color(0xFFFCE3E0), onErrorContainer = Color(0xFF5C1712)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9AA6FF), onPrimary = Color(0xFF0E1550),
    primaryContainer = Color(0xFF2B3A9E), onPrimaryContainer = Color(0xFFDDE1FF),
    secondary = Color(0xFFC9CEEA), onSecondary = Noche,
    secondaryContainer = Color(0xFF4A3510), onSecondaryContainer = Color(0xFFFFE7C2),
    tertiary = Color(0xFF5BD3A2), onTertiary = Color(0xFF00381F),
    background = Color(0xFF0D1129), onBackground = Color(0xFFE7E9F6),
    surface = Color(0xFF181E42), onSurface = Color(0xFFE7E9F6),
    surfaceVariant = Color(0xFF252C57), onSurfaceVariant = Color(0xFFA6ACCB),
    surfaceContainerHighest = Color(0xFF252C57),
    outline = Color(0xFF4B527C), outlineVariant = Color(0xFF2A3160),
    error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
    errorContainer = Color(0xFF6B1D17), onErrorContainer = Color(0xFFFFDAD6)
)

private val AppTypography = Typography(
    displayLarge = TextStyle(fontFamily = Bricolage, fontWeight = FontWeight.ExtraBold, fontSize = 88.sp, lineHeight = 88.sp, letterSpacing = (-3).sp),
    displayMedium = TextStyle(fontFamily = Bricolage, fontWeight = FontWeight.ExtraBold, fontSize = 52.sp, lineHeight = 54.sp, letterSpacing = (-1.6).sp),
    displaySmall = TextStyle(fontFamily = Bricolage, fontWeight = FontWeight.Bold, fontSize = 38.sp, lineHeight = 42.sp, letterSpacing = (-1).sp),
    headlineLarge = TextStyle(fontFamily = Bricolage, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 36.sp, letterSpacing = (-0.8).sp),
    headlineMedium = TextStyle(fontFamily = Bricolage, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 32.sp, letterSpacing = (-0.6).sp),
    headlineSmall = TextStyle(fontFamily = Bricolage, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontFamily = Bricolage, fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 26.sp, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.Bold, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.Bold, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 19.sp),
    labelLarge = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp)
)

@Composable
fun BloqueadorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = AppTypography,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(10.dp),
            small = RoundedCornerShape(14.dp),
            medium = RoundedCornerShape(16.dp),
            large = RoundedCornerShape(24.dp),
            extraLarge = RoundedCornerShape(32.dp)
        ),
        content = content
    )
}

/** Verde para «todo bien». */
@Composable
fun okColor(): Color = if (isSystemInDarkTheme()) Color(0xFF5BD3A2) else Pino

/** Ámbar: avisos y la marca del «ahora». */
@Composable
fun warnColor(): Color = if (isSystemInDarkTheme()) Color(0xFFF6BE62) else Color(0xFFC77A0A)
