package com.example.bloqueador

import android.content.Context

object Prefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    /** Si está activo, al bloquear una app también se intenta quitarla de la lista de recientes. */
    fun cleanRecents(ctx: Context): Boolean = p(ctx).getBoolean("clean_recents", true)

    fun setCleanRecents(ctx: Context, value: Boolean) {
        p(ctx).edit().putBoolean("clean_recents", value).apply()
    }
}
