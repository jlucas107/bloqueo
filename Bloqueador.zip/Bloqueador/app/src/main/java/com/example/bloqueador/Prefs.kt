package com.example.bloqueador

import android.content.Context

object Prefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    /** Si está activo, al bloquear una app también se intenta quitarla de la lista de recientes. */
    fun cleanRecents(ctx: Context): Boolean = p(ctx).getBoolean("clean_recents", true)

    fun setCleanRecents(ctx: Context, value: Boolean) {
        p(ctx).edit().putBoolean("clean_recents", value).apply()
    }

    /** El asistente de configuración ya se completó o se omitió. */
    fun setupDone(ctx: Context): Boolean = p(ctx).getBoolean("setup_done", false)
    fun setSetupDone(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("setup_done", v).apply()

    /** La persona marcó a mano que ya configuró el DNS privado (cuando la app no puede leerlo). */
    fun dnsManual(ctx: Context): Boolean = p(ctx).getBoolean("dns_manual", false)
    fun setDnsManual(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("dns_manual", v).apply()
}
