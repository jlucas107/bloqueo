package com.example.bloqueador

import java.time.LocalDateTime
import java.util.UUID

/**
 * Un horario de bloqueo.
 * days: 1 = lunes ... 7 = domingo.
 * startMin / endMin: minutos desde medianoche (ej. 9:30 = 570).
 * Si endMin < startMin el rango cruza la medianoche (ej. 22:00 -> 06:00).
 * categories: categorías que se bloquean completas, incluidas las apps que se instalen después.
 * packages: apps sueltas que se bloquean además de las categorías.
 */
data class Schedule(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val days: Set<Int>,
    val startMin: Int,
    val endMin: Int,
    val packages: Set<String>,
    val enabled: Boolean = true,
    val categories: Set<AppCategory> = emptySet()
) {
    companion object {
        /** Lo que bloquea un horario nuevo por defecto. */
        val DEFAULT_CATEGORIES = setOf(AppCategory.REDES, AppCategory.JUEGOS)
    }

    fun isActiveAt(now: LocalDateTime): Boolean {
        if (!enabled || startMin == endMin) return false
        val minute = now.hour * 60 + now.minute
        val today = now.dayOfWeek.value
        val yesterday = if (today == 1) 7 else today - 1
        return if (startMin < endMin) {
            today in days && minute in startMin until endMin
        } else {
            (today in days && minute >= startMin) ||
                (yesterday in days && minute < endMin)
        }
    }
}

fun formatMinutes(min: Int): String = "%02d:%02d".format(min / 60, min % 60)
