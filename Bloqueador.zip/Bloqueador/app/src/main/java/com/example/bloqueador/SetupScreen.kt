@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.bloqueador

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

/** null = no se puede leer en este teléfono. */
fun familyDnsActive(ctx: Context): Boolean? =
    try {
        val cr = ctx.contentResolver
        val mode = Settings.Global.getString(cr, "private_dns_mode")
        val host = Settings.Global.getString(cr, "private_dns_specifier")
        if (mode == null && host == null) null
        else mode == "hostname" && host == DeviceOwner.DNS_HOST
    } catch (e: Exception) {
        null
    }

/**
 * Asistente para dejar todo listo en un celular nuevo, paso a paso.
 * [onFinish] recibe true si hay que ir a la pestaña Protección (para activar el modo estricto).
 */
@Composable
fun SetupScreen(onFinish: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var tick by remember { mutableStateOf(0) }
    var importMsg by remember { mutableStateOf<String?>(null) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val elevated = remember(tick) { Elevated.has(ctx) }
    val access = remember(tick) { isServiceEnabled(ctx) }
    val battery = remember(tick) { Battery.isExempt(ctx) }
    val admin = remember(tick) { isAdminActive(ctx) }
    val dnsRead = remember(tick) { familyDnsActive(ctx) }
    val dns = dnsRead ?: Prefs.dnsManual(ctx)
    val doneCount = listOf(access, battery, admin, dns).count { it }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val r = ConfigBackup.read(ctx, uri)
            importMsg = if (r == null) "Ese archivo no es una copia de Bloqueador."
            else "Importados: ${r.schedules} horario(s) y ${r.sites} sitio(s)."
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().systemBarsPadding(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Configuración", style = MaterialTheme.typography.headlineLarge)
                Text(
                    "Deja Bloqueador listo en este celular. Van $doneCount de 4 pasos.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (elevated) {
                    Text(
                        "Permiso especial activo: algunos pasos se hacen solos.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // ---- 0. Importar
        item {
            SetupStep(
                ok = importMsg != null && !importMsg!!.startsWith("Ese"),
                title = "¿Vienes de otro celular? (opcional)",
                desc = importMsg ?: "Carga el archivo de configuración que exportaste allá: horarios y sitios bloqueados."
            ) {
                FilledTonalButton(onClick = { importer.launch(arrayOf("application/json", "text/plain", "*/*")) }) {
                    Text("Importar")
                }
            }
        }

        // ---- 1. Accesibilidad
        item {
            SetupStep(
                ok = access,
                title = "1. Accesibilidad",
                desc = if (access) "Activa." else "Es lo que detecta y cierra las apps y páginas bloqueadas. " +
                    "En Ajustes → Accesibilidad → Apps instaladas → Bloqueador, actívala."
            ) {
                if (!access) {
                    if (elevated) {
                        FilledTonalButton(onClick = { Elevated.enableAccessibility(ctx); tick++ }) { Text("Activar") }
                    } else {
                        FilledTonalButton(onClick = {
                            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }) { Text("Abrir") }
                    }
                }
            }
            if (!access && !elevated && Build.VERSION.SDK_INT >= 33) {
                Spacer(Modifier.height(8.dp))
                Hint(
                    "¿Sale «Ajuste restringido» y no te deja activarla? Abre la información de la app, toca ⋮ " +
                        "(arriba a la derecha) → «Permitir ajustes restringidos», y vuelve a intentarlo.",
                    "Info de la app"
                ) {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    )
                }
            }
        }

        // ---- 2. Batería
        item {
            SetupStep(
                ok = battery,
                title = "2. Batería sin restricciones",
                desc = if (battery) "Listo." else "Para que el teléfono no apague a Bloqueador por ahorrar batería."
            ) {
                if (!battery) FilledTonalButton(onClick = { Battery.request(ctx) }) { Text("Permitir") }
            }
        }

        // ---- 3. Anti-desinstalación
        item {
            SetupStep(
                ok = admin,
                title = "3. Anti-desinstalación",
                desc = if (admin) "Activa." else "Android no dejará desinstalar Bloqueador."
            ) {
                if (!admin) FilledTonalButton(onClick = { ctx.startActivity(adminIntent(ctx)) }) { Text("Activar") }
            }
        }

        // ---- 4. DNS familiar
        item {
            SetupStep(
                ok = dns,
                title = "4. DNS familiar",
                desc = if (dns) "Listo: bloquea contenido para adultos en todas las apps."
                else "Bloquea contenido para adultos en todas las apps, no solo en el navegador. " +
                    "En Ajustes → Conexiones / Red e internet → DNS privado, elige «Nombre de host» y pega:"
            ) {
                if (!dns && elevated) {
                    FilledTonalButton(onClick = { Elevated.setFamilyDns(ctx); tick++ }) { Text("Poner") }
                }
            }
            if (!dns && !elevated) {
                Spacer(Modifier.height(8.dp))
                Text(
                    DeviceOwner.DNS_HOST,
                    fontFamily = FontFamily.Monospace,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant).padding(10.dp)
                )
                Row {
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(DeviceOwner.DNS_HOST))
                        try {
                            ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                        } catch (e: Exception) {
                            ctx.startActivity(Intent(Settings.ACTION_SETTINGS))
                        }
                    }) { Text("Copiar y abrir Ajustes") }
                    if (dnsRead == null) {
                        TextButton(onClick = { Prefs.setDnsManual(ctx, true); tick++ }) { Text("Ya lo hice") }
                    }
                }
            }
        }

        // ---- Final
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Último paso: modo estricto",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    "En la pestaña Protección crea tu contraseña y actívalo. Ahí eliges cuánto tarda en poder apagarse (1 min para pruebas, 1 h o 24 h). " +
                        "Hazlo cuando todo lo de arriba esté en verde.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Button(onClick = { Prefs.setSetupDone(ctx, true); onFinish(true) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Ir a Protección")
                }
                TextButton(onClick = { Prefs.setSetupDone(ctx, true); onFinish(false) }) {
                    Text("Terminar después")
                }
            }
        }
    }
}

@Composable
private fun SetupStep(ok: Boolean, title: String, desc: String, action: @Composable () -> Unit) {
    SurfaceCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StateGlyph(ok)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(8.dp))
            action()
        }
    }
}

@Composable
private fun Hint(text: String, button: String, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp)
    ) {
        Text(text, style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = onClick) { Text(button) }
    }
}
