@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.bloqueador

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

/** ¿Está puesto el DNS familiar? null = este teléfono no deja leerlo. */
fun familyDnsActive(ctx: Context): Boolean? =
    try {
        val cr = ctx.contentResolver
        val mode = Settings.Global.getString(cr, "private_dns_mode")
        val host = Settings.Global.getString(cr, "private_dns_specifier")
        if (mode == null && host == null) null
        else mode == "hostname" && host == WebFilter.FAMILY_DNS
    } catch (e: Exception) {
        null
    }

/**
 * Asistente para dejar todo listo en un celular nuevo, paso a paso.
 * [onFinish] recibe true si hay que ir a la pestaña Protección (para activar el modo estricto).
 */
@Composable
fun SetupScreen(onFinish: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var tick by remember { mutableStateOf(0) }
    var importMsg by remember { mutableStateOf<String?>(null) }
    var imported by remember { mutableStateOf(false) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val access = remember(tick) { isServiceEnabled(ctx) }
    val battery = remember(tick) { Battery.isExempt(ctx) }
    val admin = remember(tick) { isAdminActive(ctx) }
    val dnsRead = remember(tick) { familyDnsActive(ctx) }
    val dns = dnsRead ?: Prefs.dnsManual(ctx)
    val steps = listOf(access, battery, admin, dns)
    val done = steps.count { it }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val r = ConfigBackup.read(ctx, uri)
            imported = r != null
            importMsg = if (r == null) "Ese archivo no es una copia de Bloqueador."
            else "Importados: ${r.schedules} horario(s) y ${r.sites} sitio(s)."
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        ScreenHeader("Configuración", "Deja Bloqueador listo en este celular. Tarda unos 2 minutos.") {
            Spacer(Modifier.height(16.dp))
            ProtectionMeter(
                listOf(
                    Layer("Accesibilidad", access), Layer("Batería", battery),
                    Layer("Anti-desinstalación", admin), Layer("DNS familiar", dns)
                )
            )
        }

        LazyColumn(
            Modifier.fillMaxSize().navigationBarsPadding(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SurfaceCard {
                    Text("¿Vienes de otro celular?", style = MaterialTheme.typography.titleMedium)
                    Text(
                        importMsg ?: "Carga el archivo que exportaste allá para traer tus horarios y sitios bloqueados.",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (importMsg != null && !imported) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    FilledTonalButton(onClick = { importer.launch(arrayOf("application/json", "text/plain", "*/*")) }) {
                        Text("Importar configuración")
                    }
                }
            }

            item {
                Step(
                    n = 1, ok = access, title = "Accesibilidad",
                    desc = if (access) "Activa." else "Es lo que detecta y cierra las apps y páginas bloqueadas. " +
                        "En Ajustes → Accesibilidad → Apps instaladas → Bloqueador, actívala."
                ) {
                    Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Abrir Accesibilidad") }
                    if (Build.VERSION.SDK_INT >= 33) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "¿Dice «Ajuste restringido»? Abre la información de la app, toca ⋮ arriba a la derecha → " +
                                "«Permitir ajustes restringidos» y vuelve a intentarlo.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        TextButton(onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                            )
                        }, contentPadding = PaddingValues(0.dp)) { Text("Abrir información de la app") }
                    }
                }
            }

            item {
                Step(
                    n = 2, ok = battery, title = "Batería sin restricciones",
                    desc = if (battery) "Listo." else "Para que el teléfono no apague a Bloqueador por ahorrar batería."
                ) {
                    Button(onClick = { Battery.request(ctx) }) { Text("Permitir") }
                }
            }

            item {
                Step(
                    n = 3, ok = admin, title = "Anti-desinstalación",
                    desc = if (admin) "Activa." else "Android no dejará desinstalar Bloqueador."
                ) {
                    Button(onClick = { ctx.startActivity(adminIntent(ctx)) }) { Text("Activar") }
                }
            }

            item {
                Step(
                    n = 4, ok = dns, title = "DNS familiar",
                    desc = if (dns) "Listo: filtra contenido para adultos en todas las apps."
                    else "Filtra contenido para adultos en todas las apps, no solo en el navegador. " +
                        "En Ajustes → Conexiones / Red e internet → DNS privado, elige «Nombre de host» y pega:"
                ) {
                    Text(
                        WebFilter.FAMILY_DNS,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            clipboard.setText(AnnotatedString(WebFilter.FAMILY_DNS))
                            openNetworkSettings(ctx)
                        }) { Text("Copiar y abrir") }
                        if (dnsRead == null) {
                            TextButton(onClick = { Prefs.setDnsManual(ctx, true); tick++ }) { Text("Ya lo puse") }
                        }
                    }
                }
            }

            item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Noche).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        if (done == steps.size) "Todo listo. Falta el modo estricto" else "Último paso: el modo estricto",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White
                    )
                    Text(
                        "En Protección creas tu contraseña y eliges cuánto tarda en poder apagarse (1 min para pruebas, 1 h o 24 h).",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.72f)
                    )
                    Spacer(Modifier.height(4.dp))
                    Button(
                        onClick = { Prefs.setSetupDone(ctx, true); onFinish(true) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Noche),
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text("Ir a Protección") }
                    TextButton(
                        onClick = { Prefs.setSetupDone(ctx, true); onFinish(false) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Terminar después", color = Color.White.copy(alpha = 0.8f)) }
                }
            }
        }
    }
}

/**
 * Un paso del asistente. El número es real (van en orden); cuando el paso está listo se vuelve una palomita
 * y las instrucciones se esconden.
 */
@Composable
private fun Step(n: Int, ok: Boolean, title: String, desc: String, actions: @Composable ColumnScope.() -> Unit) {
    SurfaceCard {
        Row(verticalAlignment = Alignment.Top) {
            val c = if (ok) okColor() else MaterialTheme.colorScheme.primary
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(if (ok) c.copy(alpha = 0.16f) else c),
                contentAlignment = Alignment.Center
            ) {
                if (ok) Icon(Icons.Filled.Check, contentDescription = "Listo", tint = c, modifier = Modifier.size(20.dp))
                else Text("$n", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onPrimary)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (!ok) {
                    Spacer(Modifier.height(10.dp))
                    actions()
                }
            }
        }
    }
}
