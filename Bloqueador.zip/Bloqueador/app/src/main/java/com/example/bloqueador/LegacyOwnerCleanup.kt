package com.example.bloqueador

import android.content.Context
import android.os.Build
import android.os.UserManager

/**
 * Las versiones 2.3 y 2.4 podían convertir a Bloqueador en «propietario del dispositivo» con adb.
 * Esa función se quitó. Si quedó activa en este teléfono, aquí se deshace por completo
 * (se quitan las restricciones y Bloqueador deja de ser propietario), para que nada quede bloqueado sin poder quitarse.
 */
object LegacyOwnerCleanup {
    fun run(ctx: Context) {
        val d = dpm(ctx)
        val isOwner = try { d.isDeviceOwnerApp(ctx.packageName) } catch (e: Exception) { false }
        if (!isOwner) return
        val admin = adminComponent(ctx)
        val all = mutableListOf(
            UserManager.DISALLOW_SAFE_BOOT, UserManager.DISALLOW_FACTORY_RESET,
            UserManager.DISALLOW_APPS_CONTROL, UserManager.DISALLOW_CONFIG_VPN,
            UserManager.DISALLOW_ADD_USER, UserManager.DISALLOW_DEBUGGING_FEATURES
        )
        if (Build.VERSION.SDK_INT >= 28) {
            all += UserManager.DISALLOW_CONFIG_DATE_TIME
            all += UserManager.DISALLOW_USER_SWITCH
        }
        if (Build.VERSION.SDK_INT >= 29) all += UserManager.DISALLOW_CONFIG_PRIVATE_DNS
        for (r in all) try { d.clearUserRestriction(admin, r) } catch (e: Exception) { }
        try { d.setUninstallBlocked(admin, ctx.packageName, false) } catch (e: Exception) { }
        try { d.clearDeviceOwnerApp(ctx.packageName) } catch (e: Exception) { }
        DebugLog.add("propietario del dispositivo retirado (función eliminada)")
    }
}
