package com.example.bloqueador

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object StrictMode {
    private const val PREFS = "strict"

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isEnabled(ctx: Context): Boolean = p(ctx).getBoolean("enabled", false)

    private fun hash(password: String, salt: ByteArray): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, 10000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    fun enable(ctx: Context, password: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p(ctx).edit()
            .putBoolean("enabled", true)
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", hash(password, salt))
            .apply()
    }

    fun check(ctx: Context, password: String): Boolean {
        val expected = p(ctx).getString("hash", null) ?: return false
        val salt = Base64.decode(p(ctx).getString("salt", "") ?: "", Base64.NO_WRAP)
        return hash(password, salt) == expected
    }

    /** Desactiva el modo estricto solo si la contraseña es correcta. */
    fun disable(ctx: Context, password: String): Boolean {
        if (!check(ctx, password)) return false
        p(ctx).edit().putBoolean("enabled", false).apply()
        return true
    }
}
