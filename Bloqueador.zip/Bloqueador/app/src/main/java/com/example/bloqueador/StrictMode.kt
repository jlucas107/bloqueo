package com.example.bloqueador

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Modo estricto con desactivación diferida.
 *
 * Para apagarlo no basta la contraseña: la contraseña solo PIDE la desactivación.
 * Durante la espera elegida al activarlo (1 min de pruebas, 1 h o 24 h) todo sigue protegido. Pasado ese tiempo aparece el botón
 * «Desactivar ahora», que hay que usar dentro de [WINDOW_MS]; si no, la solicitud caduca
 * y hay que empezar de nuevo. Así las ganas del momento se pasan antes de poder apagarlo.
 *
 * Los tiempos usan el reloj de confianza (TrustedClock), y la pantalla de Fecha y hora
 * está bloqueada, así que cambiar la hora del teléfono no acorta la espera.
 */
object StrictMode {
    private const val PREFS = "strict"

    /** Espera por defecto desde que se pide la desactivación. */
    const val WAIT_MS = 24L * 60 * 60 * 1000

    /** Esperas que se pueden elegir al activar el modo estricto (no se cambian con él activo). */
    val WAIT_OPTIONS = listOf(
        60_000L to "1 min",
        60L * 60 * 1000 to "1 h",
        WAIT_MS to "24 h"
    )

    /** La espera que se eligió al activar el modo estricto. */
    fun waitMs(ctx: Context): Long = p(ctx).getLong("wait_ms", WAIT_MS)

    /** Tiempo para confirmar una vez terminada la espera; después la solicitud caduca. */
    const val WINDOW_MS = 24L * 60 * 60 * 1000

    sealed class Pending {
        object None : Pending()
        /** Esperando: faltan [remainingMs]. */
        class Waiting(val remainingMs: Long) : Pending()
        /** La espera terminó: se puede desactivar durante [remainingMs] más. */
        class Ready(val remainingMs: Long) : Pending()
    }

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isEnabled(ctx: Context): Boolean = p(ctx).getBoolean("enabled", false)

    private fun hash(password: String, salt: ByteArray): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, 10000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    fun enable(ctx: Context, password: String, waitMs: Long = WAIT_MS) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p(ctx).edit()
            .putBoolean("enabled", true)
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", hash(password, salt))
            .remove("request_at")
            .putLong("wait_ms", waitMs)
            .commit()
    }

    fun check(ctx: Context, password: String): Boolean {
        val expected = p(ctx).getString("hash", null) ?: return false
        val salt = Base64.decode(p(ctx).getString("salt", "") ?: "", Base64.NO_WRAP)
        return hash(password, salt) == expected
    }

    // ------------------------------------------------------------ Desactivación diferida

    /** Estado de la solicitud de desactivación. Si caducó, la borra. */
    fun pending(ctx: Context): Pending {
        val at = p(ctx).getLong("request_at", 0L)
        if (at <= 0L || !isEnabled(ctx)) return Pending.None
        val now = TrustedClock.nowMillis(ctx)
        val elapsed = now - at
        val wait = waitMs(ctx)
        return when {
            // Si el reloj va «hacia atrás» respecto a la solicitud, se reinicia la espera.
            elapsed < 0 -> {
                p(ctx).edit().putLong("request_at", now).apply()
                Pending.Waiting(wait)
            }
            elapsed < wait -> Pending.Waiting(wait - elapsed)
            elapsed < wait + WINDOW_MS -> Pending.Ready(wait + WINDOW_MS - elapsed)
            else -> {
                cancelRequest(ctx)
                Pending.None
            }
        }
    }

    /** Empieza la cuenta atrás si la contraseña es correcta. No desactiva nada todavía. */
    fun requestDisable(ctx: Context, password: String): Boolean {
        if (!check(ctx, password)) return false
        if (pending(ctx) == Pending.None) {
            p(ctx).edit().putLong("request_at", TrustedClock.nowMillis(ctx)).apply()
        }
        return true
    }

    /** Cancelar solo refuerza la protección, así que no pide contraseña. */
    fun cancelRequest(ctx: Context) {
        p(ctx).edit().remove("request_at").apply()
    }

    /** Desactiva el modo estricto solo si la espera ya terminó y la contraseña es correcta. */
    fun disableIfReady(ctx: Context, password: String): Boolean {
        if (pending(ctx) !is Pending.Ready) return false
        if (!check(ctx, password)) return false
        p(ctx).edit().putBoolean("enabled", false).remove("request_at").commit()
        return true
    }

    /** «5 h 20 min», «12 min»… */
    fun formatDuration(ms: Long): String {
        val totalMin = ((ms + 59_999) / 60_000).coerceAtLeast(1)
        val h = totalMin / 60
        val m = totalMin % 60
        return when {
            h > 0 && m > 0 -> "$h h $m min"
            h > 0 -> "$h h"
            else -> "$m min"
        }
    }
}
