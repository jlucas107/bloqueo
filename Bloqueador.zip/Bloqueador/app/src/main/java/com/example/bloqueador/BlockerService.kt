package com.example.bloqueador

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 1) Bloquea las apps de los horarios activos (el desbloqueo es automático al terminar el horario).
 * 2) Con el modo estricto activo, bloquea las pantallas de Ajustes / instalador desde donde se
 *    podría desinstalar la app, desactivar este servicio o cambiar la fecha y hora.
 */
class BlockerService : AccessibilityService() {

    private var lastScan = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        TrustedClock.maybeSync(this, force = true)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        TrustedClock.maybeSync(this)
        val isState = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED

        // ---- Protección del modo estricto ----
        if (pkg in PROTECTED_PACKAGES && StrictMode.isEnabled(this)) {
            val t = SystemClock.elapsedRealtime()
            if (isState || t - lastScan > 700) {
                lastScan = t
                if (isProtectedScreen(event, isState)) {
                    performGlobalAction(GLOBAL_ACTION_HOME)
                    showBlock(
                        "Pantalla protegida",
                        "El modo estricto está activo. Para cambiarlo, abre Bloqueador e ingresa tu contraseña.",
                        ""
                    )
                    return
                }
            }
        }

        // ---- Bloqueo por horario ----
        if (!isState) return
        val schedule = ScheduleStore.activeScheduleFor(this, pkg) ?: return
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        showBlock("$label está bloqueada", "Se desbloquea a las ${formatMinutes(schedule.endMin)}", schedule.name)
    }

    private fun showBlock(title: String, subtitle: String, schedule: String) {
        startActivity(Intent(this, BlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            putExtra("title", title)
            putExtra("subtitle", subtitle)
            putExtra("schedule", schedule)
        })
    }

    private fun isProtectedScreen(event: AccessibilityEvent, isState: Boolean): Boolean {
        if (isState) {
            val title = event.text.joinToString(" ").lowercase()
            if (TIME_TITLES.any { title.contains(it) }) return true
        }
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != event.packageName?.toString()) return false
        return screenText(root).contains("bloqueador")
    }

    private fun screenText(root: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || count > 500 || depth > 25) return
            count++
            n.text?.let { sb.append(it).append(' ') }
            n.contentDescription?.let { sb.append(it).append(' ') }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return sb.toString().lowercase()
    }

    override fun onInterrupt() {}

    companion object {
        private val PROTECTED_PACKAGES = setOf(
            "com.android.settings",
            "com.android.packageinstaller",
            "com.google.android.packageinstaller",
            "com.samsung.android.packageinstaller",
            "com.miui.packageinstaller",
            "com.android.vending"
        )
        private val TIME_TITLES = listOf(
            "fecha y hora", "hora y fecha", "zona horaria",
            "date & time", "date and time", "time zone"
        )
    }
}
