package com.example.bloqueador

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.TextView

/**
 * Flujo al bloquear una app (por horario o por pantalla protegida):
 *  1. Va al inicio.
 *  2. Cierra por completo los procesos de esa app.
 *  3. (Opcional) Abre Recientes y descarta la tarjeta de esa app.
 *  4. Vuelve al inicio y muestra el aviso de bloqueo.
 *
 * El desbloqueo es automático: al terminar el horario simplemente se deja de bloquear.
 */
class BlockerService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var busy = false
    // «Escudo»: capa negra que tapa la pantalla al instante y se traga los toques mientras se cierra Ajustes.
    private var shield: View? = null
    private var shieldLp: WindowManager.LayoutParams? = null
    private var lastScan = 0L
    private var lastOther = ""
    // Paquetes que alojan Ajustes en ESTE teléfono (varía según la marca).
    private val discovered = java.util.concurrent.CopyOnWriteArraySet<String>()
    // Navegadores instalados en este teléfono (para el bloqueo de sitios web).
    private val browsers = java.util.concurrent.CopyOnWriteArraySet<String>()
    private var lastWebScan = 0L
    private var lastUrl = ""
    private var webPkg = ""
    private val webRecheck = Runnable {
        val p = webPkg
        if (p.isNotEmpty()) checkWeb(p)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        TrustedClock.maybeSync(this, force = true)
        discoverSettingsPackages()
        discoverBrowsers()
        DebugLog.add("servicio conectado (estricto=${if (StrictMode.isEnabled(this)) "sí" else "NO"})")
        DebugLog.add("paquetes de Ajustes: ${discovered.joinToString()}")
        DebugLog.add("navegadores: ${(browsers + KNOWN_BROWSERS).joinToString { it.substringAfterLast('.') }}")
    }

    /** Pregunta al sistema qué app abre Accesibilidad, Ajustes, Fecha y hora e Info de app. */
    private fun discoverSettingsPackages() {
        val intents = listOf(
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
            Intent(Settings.ACTION_SETTINGS),
            Intent(Settings.ACTION_DATE_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
        for (i in intents) {
            try {
                packageManager.queryIntentActivities(i, 0).forEach {
                    val p = it.activityInfo.packageName
                    if (p != packageName) discovered.add(p)
                }
            } catch (e: Exception) {
                // seguimos con lo que haya
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || busy) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        TrustedClock.maybeSync(this)
        val isState = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED

        // ---- Protección del modo estricto ----
        if (isProtectedPackage(pkg)) {
            val strict = StrictMode.isEnabled(this)
            val isClick = event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED
            if (isState || isClick) {
                DebugLog.add(
                    "${if (isState) "PANTALLA" else "CLIC"} pkg=$pkg estricto=${if (strict) "sí" else "NO"} " +
                        "clase=${event.className?.toString()?.substringAfterLast('.')} " +
                        "texto=${event.text.joinToString(" ").take(60)}"
                )
            }
            if (strict) {
                val t = SystemClock.elapsedRealtime()
                if (isState || isClick || t - lastScan > 100) {
                    lastScan = t
                    val why = protectedReason(event, isState, isClick)
                    if (why != null) {
                        DebugLog.add("BLOQUEO ($why)")
                        blockProtected(pkg)
                        return
                    }
                }
                // Al cambiar de pantalla, el contenido de Ajustes tarda un instante en cargarse:
                // se vuelve a revisar un poco después para no depender de un solo vistazo.
                if (isState) {
                    handler.postDelayed({ recheck(pkg) }, 120)
                    handler.postDelayed({ recheck(pkg) }, 350)
                    handler.postDelayed({ recheck(pkg) }, 700)
                    handler.postDelayed({ recheck(pkg) }, 1400)
                }
            }
        } else if (isState) {
            // Para el diagnóstico: qué otras apps/pantallas ve el servicio.
            val key = "$pkg/${event.className}"
            if (key != lastOther) {
                lastOther = key
                DebugLog.add(
                    "otra pkg=$pkg clase=${event.className?.toString()?.substringAfterLast('.')} " +
                        "texto=${event.text.joinToString(" ").take(40)}"
                )
            }
        }

        // ---- Bloqueo de sitios web y contenido para adultos ----
        if (isBrowser(pkg) && WebFilter.isActive(this)) {
            val t = SystemClock.elapsedRealtime()
            if (isState || t - lastWebScan > 350) {
                lastWebScan = t
                if (checkWeb(pkg)) return
            }
            // Revisión final: el texto de la barra tarda un instante en actualizarse.
            webPkg = pkg
            handler.removeCallbacks(webRecheck)
            handler.postDelayed(webRecheck, 500)
        }

        // ---- Bloqueo por horario ----
        if (!isState) return
        val schedule = ScheduleStore.activeScheduleFor(this, pkg) ?: return
        closeAndBlock(
            pkg,
            "${appLabel(pkg)} está bloqueada",
            "",
            schedule.name,
            formatMinutes(schedule.endMin)
        )
    }

    // ------------------------------------------------------------------
    // Cierre completo + limpieza de recientes
    // ------------------------------------------------------------------

    private fun closeAndBlock(
        pkg: String, title: String, subtitle: String, schedule: String, until: String,
        strongClose: Boolean = false
    ) {
        busy = true
        // seguro por si algo se atasca
        handler.postDelayed({ busy = false; hideShield() }, 9000)
        val label = appLabel(pkg)

        // 1) Lo primero, tapar la pantalla: así no se puede tocar «Desactivar» mientras se cierra Ajustes.
        showShield(title)
        // 2) Ir al inicio.
        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({
            // El escudo deja pasar los gestos para poder limpiar Recientes.
            setShieldTouchable(false)
            killApp(pkg)
            if (strongClose || Prefs.cleanRecents(this)) {
                removeFromRecents(recentLabels(pkg, label, strongClose)) {
                    finishBlock(pkg, title, subtitle, schedule, until)
                }
            } else {
                finishBlock(pkg, title, subtitle, schedule, until)
            }
        }, 600)
    }

    private fun finishBlock(pkg: String, title: String, subtitle: String, schedule: String, until: String) {
        killApp(pkg)
        showBlock(title, subtitle, schedule, until)
        // Se quita el escudo cuando el aviso de bloqueo ya está encima.
        handler.postDelayed({ hideShield() }, 700)
        handler.postDelayed({ busy = false }, 500)
    }

    /** Cierra la app y, si es Ajustes, también los demás paquetes que la forman (p. ej. el de Accesibilidad). */
    private fun killApp(pkg: String) {
        val targets = HashSet<String>()
        targets.add(pkg)
        if (isProtectedPackage(pkg)) {
            targets.addAll(discovered)
            targets.add("com.android.settings")
            targets.add("com.samsung.accessibility")
        }
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        for (t in targets) {
            try {
                am.killBackgroundProcesses(t)
            } catch (e: Exception) {
                // si el sistema no lo permite, seguimos
            }
        }
    }

    /** Nombres de tarjeta a descartar en Recientes (Ajustes aparece como «Ajustes»). */
    private fun recentLabels(pkg: String, label: String, strong: Boolean): List<String> {
        val out = LinkedHashSet<String>()
        out.add(label)
        if (strong || isProtectedPackage(pkg)) {
            out.add(appLabel("com.android.settings"))
            out.add(appLabel("com.samsung.accessibility"))
        }
        // si no se pudo leer el nombre, appLabel devuelve el paquete: eso no sirve para buscar la tarjeta
        return out.filter { it.isNotBlank() && !it.contains('.') }
    }

    private fun removeFromRecents(labels: List<String>, onDone: () -> Unit) {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed({
            dismissNext(labels, 0) {
                handler.postDelayed({
                    performGlobalAction(GLOBAL_ACTION_HOME)
                    handler.postDelayed({ onDone() }, 400)
                }, 500)
            }
        }, 800)
    }

    private fun dismissNext(labels: List<String>, i: Int, done: () -> Unit) {
        if (i >= labels.size) {
            done()
            return
        }
        try {
            val root = rootInActiveWindow
            val card = if (root != null) findCard(root, labels[i].lowercase()) else null
            if (card != null && !tryDismiss(card)) swipeUp(card)
        } catch (e: Exception) {
            // mejor esfuerzo
        }
        handler.postDelayed({ dismissNext(labels, i + 1, done) }, 450)
    }

    // ------------------------------------------------------------------
    // Escudo (capa que tapa la pantalla y bloquea los toques)
    // ------------------------------------------------------------------

    private fun showShield(message: String) {
        if (shield != null) return
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val root = FrameLayout(this).apply {
                setBackgroundColor(0xFF101418.toInt())
                isClickable = true
            }
            val tv = TextView(this).apply {
                text = message
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 20f
                gravity = Gravity.CENTER
            }
            root.addView(
                tv,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE
            )
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            wm.addView(root, lp)
            shield = root
            shieldLp = lp
        } catch (e: Exception) {
            shield = null
            shieldLp = null
        }
    }

    private fun setShieldTouchable(touchable: Boolean) {
        val v = shield ?: return
        val lp = shieldLp ?: return
        try {
            lp.flags = if (touchable) {
                lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            } else {
                lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(v, lp)
        } catch (e: Exception) {
            // sin cambios
        }
    }

    private fun hideShield() {
        val v = shield ?: return
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Exception) {
            // ya no estaba
        }
        shield = null
        shieldLp = null
    }

    override fun onDestroy() {
        hideShield()
        super.onDestroy()
    }

    /** Busca en la pantalla de Recientes la tarjeta cuyo texto/descripción contiene el nombre de la app. */
    private fun findCard(root: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val queue = java.util.ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count < 600) {
            val n = queue.poll() ?: break
            count++
            val t = (n.text?.toString() ?: "").lowercase()
            val d = (n.contentDescription?.toString() ?: "").lowercase()
            if ((t.isNotEmpty() && t.contains(label)) || (d.isNotEmpty() && d.contains(label))) {
                return bestCard(n)
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return null
    }

    /** Sube por los padres hasta quedarse con el contenedor de la tarjeta (sin llegar a toda la pantalla). */
    private fun bestCard(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        val dm = resources.displayMetrics
        val screenArea = dm.widthPixels.toLong() * dm.heightPixels
        var best = n
        var cur: AccessibilityNodeInfo? = n.parent
        var i = 0
        val r = Rect()
        while (cur != null && i < 4) {
            cur.getBoundsInScreen(r)
            if (r.width().toLong() * r.height() > screenArea * 0.7) break
            best = cur
            cur = cur.parent
            i++
        }
        return best
    }

    /** Intenta descartar la tarjeta con las acciones de accesibilidad que ofrezca el launcher. */
    private fun tryDismiss(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 4) {
            val actions = n.actionList
            if (actions.any { it.id == AccessibilityNodeInfo.ACTION_DISMISS } &&
                n.performAction(AccessibilityNodeInfo.ACTION_DISMISS)
            ) return true

            val custom = actions.firstOrNull {
                val l = it.label?.toString()?.lowercase() ?: ""
                l.contains("cerrar") || l.contains("close") || l.contains("dismiss") ||
                    l.contains("descartar") || l.contains("quitar")
            }
            if (custom != null && n.performAction(custom.id)) return true

            n = n.parent
            depth++
        }
        return false
    }

    /** Plan B: deslizar la tarjeta hacia arriba, como haría una persona. */
    private fun swipeUp(node: AccessibilityNodeInfo) {
        val r = Rect()
        node.getBoundsInScreen(r)
        if (r.isEmpty) return
        val path = Path().apply {
            moveTo(r.exactCenterX(), r.exactCenterY())
            lineTo(r.exactCenterX(), 5f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 180))
            .build()
        dispatchGesture(gesture, null, null)
    }

    // ------------------------------------------------------------------

    // ------------------------------------------------------------------
    // Sitios web y contenido para adultos
    // ------------------------------------------------------------------

    private fun isBrowser(pkg: String): Boolean = pkg in KNOWN_BROWSERS || pkg in browsers

    /** Pregunta al sistema qué apps abren enlaces https (los navegadores). */
    private fun discoverBrowsers() {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))
                .addCategory(Intent.CATEGORY_BROWSABLE)
            packageManager.queryIntentActivities(i, PackageManager.MATCH_ALL).forEach {
                val p = it.activityInfo.packageName
                if (p != packageName) browsers.add(p)
            }
        } catch (e: Exception) {
            // nos quedamos con la lista conocida
        }
    }

    /** Lee la barra de direcciones y bloquea si corresponde. Devuelve true si bloqueó. */
    private fun checkWeb(pkg: String): Boolean {
        if (busy || !WebFilter.isActive(this)) return false
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != pkg) return false
        val raw = findUrlText(root, pkg) ?: return false
        if (raw != lastUrl) {
            lastUrl = raw
            DebugLog.add("WEB ${pkg.substringAfterLast('.')} → ${raw.take(60)}")
        }
        val verdict = WebFilter.check(this, raw) ?: return false
        DebugLog.add("BLOQUEO WEB: ${verdict.label}")
        blockWeb(pkg, verdict)
        return true
    }

    /** Busca el texto de la barra de direcciones: primero por id conocido, luego de forma genérica. */
    private fun findUrlText(root: AccessibilityNodeInfo, pkg: String): String? {
        for (name in URL_BAR_IDS) {
            val nodes = try {
                root.findAccessibilityNodeInfosByViewId("$pkg:id/$name")
            } catch (e: Exception) {
                null
            }
            val text = nodes?.firstNotNullOfOrNull { n -> n.text?.toString()?.takeIf { it.isNotBlank() } }
            if (text != null) return text
        }
        return genericUrlText(root)
    }

    private fun genericUrlText(root: AccessibilityNodeInfo): String? {
        val queue = java.util.ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count < 400) {
            val n = queue.poll() ?: break
            count++
            val id = n.viewIdResourceName?.lowercase() ?: ""
            val t = n.text?.toString()
            if (!t.isNullOrBlank() &&
                (id.contains("url") || id.contains("omnibox") || id.contains("location_bar"))
            ) return t
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return null
    }

    /**
     * Saca al navegador de la página prohibida (abre una pestaña segura) y muestra el aviso.
     * No se mata el navegador: así no se pierden las demás pestañas ni se vuelve a abrir la página bloqueada.
     */
    private fun blockWeb(pkg: String, v: WebFilter.Verdict) {
        busy = true
        handler.postDelayed({ busy = false }, 3000)
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(SAFE_URL)).apply {
                setPackage(pkg)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
        handler.postDelayed({ showBlock("Sitio bloqueado", v.subtitle, "", "") }, 350)
    }

    private fun appLabel(pkg: String): String =
        try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }

    private fun showBlock(title: String, subtitle: String, schedule: String, until: String) {
        startActivity(Intent(this, BlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            putExtra("title", title)
            putExtra("subtitle", subtitle)
            putExtra("schedule", schedule)
            putExtra("until", until)
        })
    }

    private fun blockProtected(pkg: String) {
        closeAndBlock(
            pkg,
            "Pantalla protegida",
            "El modo estricto está activo. Para cambiarlo, abre Bloqueador e ingresa tu contraseña.",
            "",
            "",
            strongClose = true
        )
    }

    /** Revisión diferida: mira lo que hay en pantalla ahora mismo. */
    private fun recheck(pkg: String) {
        if (busy || !StrictMode.isEnabled(this)) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return
        val text = screenText(root)
        val why = textReason(text)
        DebugLog.add("revisión: ${text.take(90)}")
        if (why != null) {
            DebugLog.add("BLOQUEO ($why)")
            blockProtected(pkg)
        }
    }

    /** La pantalla de Ajustes del propio servicio muestra el nombre «Bloqueador». */
    private fun textReason(text: String): String? =
        if (text.contains("bloqueador")) "texto: bloqueador" else null

    /** Texto del elemento tocado (y de sus padres cercanos), p. ej. la fila «Accesibilidad». */
    private fun clickedText(event: AccessibilityEvent): String {
        val sb = StringBuilder(event.text.joinToString(" "))
        var n: AccessibilityNodeInfo? = event.source
        var i = 0
        while (n != null && i < 4) {
            n.text?.let { sb.append(' ').append(it) }
            n.contentDescription?.let { sb.append(' ').append(it) }
            n = n.parent
            i++
        }
        return sb.toString().lowercase()
    }

    /** Devuelve el motivo por el que esta pantalla debe cerrarse, o null si no hay que cerrarla. */
    private fun protectedReason(event: AccessibilityEvent, isState: Boolean, isClick: Boolean): String? {
        if (isClick) {
            val clicked = clickedText(event)
            if (clicked.contains("bloqueador")) return "clic: bloqueador"
            DNS_TITLES.firstOrNull { clicked.contains(it) }?.let { return "clic: $it" }
        }
        if (isState) {
            val title = event.text.joinToString(" ").lowercase()
            TIME_TITLES.firstOrNull { title.contains(it) }?.let { return "título: $it" }
            DNS_TITLES.firstOrNull { title.contains(it) }?.let { return "título: $it" }
            if (title.contains("bloqueador")) return "título: bloqueador"
        }
        val root = rootInActiveWindow ?: return null
        if (root.packageName?.toString() != event.packageName?.toString()) return null
        return textReason(screenText(root))
    }

    private fun screenText(root: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || count > 500 || depth > 25) return
            count++
            n.text?.let { sb.append(it).append(' ') }
            n.contentDescription?.let { sb.append(it).append(' ') }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return sb.toString().lowercase()
    }

    override fun onInterrupt() {}

    private fun isProtectedPackage(pkg: String): Boolean =
        pkg in discovered || pkg in PROTECTED_PACKAGES || pkg.contains("accessibility") || pkg.endsWith(".settings") || pkg.contains(".settings.")

    companion object {
        // Página a la que se redirige el navegador al bloquear un sitio.
        private const val SAFE_URL = "https://www.google.com/"

        // Nombres de la barra de direcciones; se prueban como "<paquete>:id/<nombre>",
        // así sirven también para Chrome Beta, Brave, Edge, etc.
        private val URL_BAR_IDS = listOf(
            "url_bar", "location_bar_edit_text", "mozac_browser_toolbar_url_view",
            "url_field", "omnibarTextInput", "url"
        )

        private val KNOWN_BROWSERS = setOf(
            "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary",
            "org.chromium.chrome", "com.sec.android.app.sbrowser", "com.sec.android.app.sbrowser.beta",
            "org.mozilla.firefox", "org.mozilla.firefox_beta", "org.mozilla.fenix", "org.mozilla.focus",
            "com.microsoft.emmx", "com.brave.browser", "com.opera.browser", "com.opera.mini.native",
            "com.duckduckgo.mobile.android", "com.kiwibrowser.browser", "com.vivaldi.browser",
            "com.mi.globalbrowser", "com.UCMobile.intl", "com.google.android.apps.chrome"
        )

        private val PROTECTED_PACKAGES = setOf(
            "com.samsung.accessibility",
            "com.miui.securitycenter",
            "com.android.permissioncontroller",
            "com.google.android.permissioncontroller",
            "com.android.settings",
            "com.android.packageinstaller",
            "com.google.android.packageinstaller",
            "com.samsung.android.packageinstaller",
            "com.miui.packageinstaller",
            "com.android.vending"
        )
        // Pantalla de DNS privado: quitarla o cambiarla saltaría el filtro de adultos.
        // Solo se compara con el título/clic (no con todo el texto) para no bloquear «Red e internet» entera.
        private val DNS_TITLES = listOf("dns privado", "dns privada", "private dns")
        private val TIME_TITLES = listOf(
            "fecha y hora", "hora y fecha", "zona horaria",
            "date & time", "date and time", "time zone"
        )
    }
}
