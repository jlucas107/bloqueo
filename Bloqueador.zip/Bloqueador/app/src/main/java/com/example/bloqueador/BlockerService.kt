package com.example.bloqueador

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Flujo al bloquear una app (por horario o por pantalla protegida):
 *  1. Va al inicio.
 *  2. Cierra por completo los procesos de esa app.
 *  3. (Opcional) Abre Recientes y descarta la tarjeta de esa app.
 *  4. Vuelve al inicio y muestra el aviso de bloqueo.
 *
 * El desbloqueo es automático: al terminar el horario simplemente se deja de bloquear.
 */
class BlockerService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var busy = false
    private var lastScan = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        TrustedClock.maybeSync(this, force = true)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || busy) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        TrustedClock.maybeSync(this)
        val isState = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED

        // ---- Protección del modo estricto ----
        if (pkg in PROTECTED_PACKAGES && StrictMode.isEnabled(this)) {
            val t = SystemClock.elapsedRealtime()
            if (isState || t - lastScan > 700) {
                lastScan = t
                if (isProtectedScreen(event, isState)) {
                    closeAndBlock(
                        pkg,
                        "Pantalla protegida",
                        "El modo estricto está activo. Para cambiarlo, abre Bloqueador e ingresa tu contraseña.",
                        ""
                    )
                    return
                }
            }
        }

        // ---- Bloqueo por horario ----
        if (!isState) return
        val schedule = ScheduleStore.activeScheduleFor(this, pkg) ?: return
        closeAndBlock(
            pkg,
            "${appLabel(pkg)} está bloqueada",
            "Se desbloquea a las ${formatMinutes(schedule.endMin)}",
            schedule.name
        )
    }

    // ------------------------------------------------------------------
    // Cierre completo + limpieza de recientes
    // ------------------------------------------------------------------

    private fun closeAndBlock(pkg: String, title: String, subtitle: String, schedule: String) {
        busy = true
        handler.postDelayed({ busy = false }, 8000) // seguro por si algo se atasca
        val label = appLabel(pkg)

        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({
            killApp(pkg)
            if (Prefs.cleanRecents(this)) {
                removeFromRecents(label) { finishBlock(pkg, title, subtitle, schedule) }
            } else {
                finishBlock(pkg, title, subtitle, schedule)
            }
        }, 600)
    }

    private fun finishBlock(pkg: String, title: String, subtitle: String, schedule: String) {
        killApp(pkg)
        showBlock(title, subtitle, schedule)
        handler.postDelayed({ busy = false }, 500)
    }

    private fun killApp(pkg: String) {
        try {
            (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(pkg)
        } catch (e: Exception) {
            // si el sistema no lo permite, seguimos
        }
    }

    private fun removeFromRecents(label: String, onDone: () -> Unit) {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed({
            try {
                val root = rootInActiveWindow
                val card = if (root != null) findCard(root, label.lowercase()) else null
                if (card != null && !tryDismiss(card)) swipeUp(card)
            } catch (e: Exception) {
                // mejor esfuerzo
            }
            handler.postDelayed({
                performGlobalAction(GLOBAL_ACTION_HOME)
                handler.postDelayed({ onDone() }, 400)
            }, 700)
        }, 800)
    }

    /** Busca en la pantalla de Recientes la tarjeta cuyo texto/descripción contiene el nombre de la app. */
    private fun findCard(root: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val queue = java.util.ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count < 600) {
            val n = queue.poll() ?: break
            count++
            val t = (n.text?.toString() ?: "").lowercase()
            val d = (n.contentDescription?.toString() ?: "").lowercase()
            if ((t.isNotEmpty() && t.contains(label)) || (d.isNotEmpty() && d.contains(label))) {
                return bestCard(n)
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return null
    }

    /** Sube por los padres hasta quedarse con el contenedor de la tarjeta (sin llegar a toda la pantalla). */
    private fun bestCard(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        val dm = resources.displayMetrics
        val screenArea = dm.widthPixels.toLong() * dm.heightPixels
        var best = n
        var cur: AccessibilityNodeInfo? = n.parent
        var i = 0
        val r = Rect()
        while (cur != null && i < 4) {
            cur.getBoundsInScreen(r)
            if (r.width().toLong() * r.height() > screenArea * 0.7) break
            best = cur
            cur = cur.parent
            i++
        }
        return best
    }

    /** Intenta descartar la tarjeta con las acciones de accesibilidad que ofrezca el launcher. */
    private fun tryDismiss(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 4) {
            val actions = n.actionList
            if (actions.any { it.id == AccessibilityNodeInfo.ACTION_DISMISS } &&
                n.performAction(AccessibilityNodeInfo.ACTION_DISMISS)
            ) return true

            val custom = actions.firstOrNull {
                val l = it.label?.toString()?.lowercase() ?: ""
                l.contains("cerrar") || l.contains("close") || l.contains("dismiss") ||
                    l.contains("descartar") || l.contains("quitar")
            }
            if (custom != null && n.performAction(custom.id)) return true

            n = n.parent
            depth++
        }
        return false
    }

    /** Plan B: deslizar la tarjeta hacia arriba, como haría una persona. */
    private fun swipeUp(node: AccessibilityNodeInfo) {
        val r = Rect()
        node.getBoundsInScreen(r)
        if (r.isEmpty) return
        val path = Path().apply {
            moveTo(r.exactCenterX(), r.exactCenterY())
            lineTo(r.exactCenterX(), 5f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 180))
            .build()
        dispatchGesture(gesture, null, null)
    }

    // ------------------------------------------------------------------

    private fun appLabel(pkg: String): String =
        try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }

    private fun showBlock(title: String, subtitle: String, schedule: String) {
        startActivity(Intent(this, BlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            putExtra("title", title)
            putExtra("subtitle", subtitle)
            putExtra("schedule", schedule)
        })
    }

    private fun isProtectedScreen(event: AccessibilityEvent, isState: Boolean): Boolean {
        if (isState) {
            val title = event.text.joinToString(" ").lowercase()
            if (TIME_TITLES.any { title.contains(it) }) return true
        }
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != event.packageName?.toString()) return false
        return screenText(root).contains("bloqueador")
    }

    private fun screenText(root: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || count > 500 || depth > 25) return
            count++
            n.text?.let { sb.append(it).append(' ') }
            n.contentDescription?.let { sb.append(it).append(' ') }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return sb.toString().lowercase()
    }

    override fun onInterrupt() {}

    companion object {
        private val PROTECTED_PACKAGES = setOf(
            "com.android.settings",
            "com.android.packageinstaller",
            "com.google.android.packageinstaller",
            "com.samsung.android.packageinstaller",
            "com.miui.packageinstaller",
            "com.android.vending"
        )
        private val TIME_TITLES = listOf(
            "fecha y hora", "hora y fecha", "zona horaria",
            "date & time", "date and time", "time zone"
        )
    }
}
