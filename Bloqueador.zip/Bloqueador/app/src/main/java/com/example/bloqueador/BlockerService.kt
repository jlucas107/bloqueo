package com.example.bloqueador

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Flujo al bloquear una app (por horario o por pantalla protegida):
 *  1. Va al inicio.
 *  2. Cierra por completo los procesos de esa app.
 *  3. (Opcional) Abre Recientes y descarta la tarjeta de esa app.
 *  4. Vuelve al inicio y muestra el aviso de bloqueo.
 *
 * El desbloqueo es automático: al terminar el horario simplemente se deja de bloquear.
 */
class BlockerService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var busy = false
    private var lastScan = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        TrustedClock.maybeSync(this, force = true)
        DebugLog.add("servicio conectado (estricto=${if (StrictMode.isEnabled(this)) "sí" else "NO"})")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || busy) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        TrustedClock.maybeSync(this)
        val isState = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED

        // ---- Protección del modo estricto ----
        if (isProtectedPackage(pkg)) {
            val strict = StrictMode.isEnabled(this)
            val isClick = event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED
            if (isState || isClick) {
                DebugLog.add(
                    "${if (isState) "PANTALLA" else "CLIC"} pkg=$pkg estricto=${if (strict) "sí" else "NO"} " +
                        "clase=${event.className?.toString()?.substringAfterLast('.')} " +
                        "texto=${event.text.joinToString(" ").take(60)}"
                )
            }
            if (strict) {
                val t = SystemClock.elapsedRealtime()
                if (isState || isClick || t - lastScan > 300) {
                    lastScan = t
                    val why = protectedReason(event, isState, isClick)
                    if (why != null) {
                        DebugLog.add("BLOQUEO ($why)")
                        blockProtected(pkg)
                        return
                    }
                }
                // Al cambiar de pantalla, el contenido de Ajustes tarda un instante en cargarse:
                // se vuelve a revisar un poco después para no depender de un solo vistazo.
                if (isState) {
                    handler.postDelayed({ recheck(pkg) }, 600)
                    handler.postDelayed({ recheck(pkg) }, 1400)
                }
            }
        }

        // ---- Bloqueo por horario ----
        if (!isState) return
        val schedule = ScheduleStore.activeScheduleFor(this, pkg) ?: return
        closeAndBlock(
            pkg,
            "${appLabel(pkg)} está bloqueada",
            "",
            schedule.name,
            formatMinutes(schedule.endMin)
        )
    }

    // ------------------------------------------------------------------
    // Cierre completo + limpieza de recientes
    // ------------------------------------------------------------------

    private fun closeAndBlock(pkg: String, title: String, subtitle: String, schedule: String, until: String) {
        busy = true
        handler.postDelayed({ busy = false }, 8000) // seguro por si algo se atasca
        val label = appLabel(pkg)

        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({
            killApp(pkg)
            if (Prefs.cleanRecents(this)) {
                removeFromRecents(label) { finishBlock(pkg, title, subtitle, schedule, until) }
            } else {
                finishBlock(pkg, title, subtitle, schedule, until)
            }
        }, 600)
    }

    private fun finishBlock(pkg: String, title: String, subtitle: String, schedule: String, until: String) {
        killApp(pkg)
        showBlock(title, subtitle, schedule, until)
        handler.postDelayed({ busy = false }, 500)
    }

    private fun killApp(pkg: String) {
        try {
            (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(pkg)
        } catch (e: Exception) {
            // si el sistema no lo permite, seguimos
        }
    }

    private fun removeFromRecents(label: String, onDone: () -> Unit) {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed({
            try {
                val root = rootInActiveWindow
                val card = if (root != null) findCard(root, label.lowercase()) else null
                if (card != null && !tryDismiss(card)) swipeUp(card)
            } catch (e: Exception) {
                // mejor esfuerzo
            }
            handler.postDelayed({
                performGlobalAction(GLOBAL_ACTION_HOME)
                handler.postDelayed({ onDone() }, 400)
            }, 700)
        }, 800)
    }

    /** Busca en la pantalla de Recientes la tarjeta cuyo texto/descripción contiene el nombre de la app. */
    private fun findCard(root: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val queue = java.util.ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        while (queue.isNotEmpty() && count < 600) {
            val n = queue.poll() ?: break
            count++
            val t = (n.text?.toString() ?: "").lowercase()
            val d = (n.contentDescription?.toString() ?: "").lowercase()
            if ((t.isNotEmpty() && t.contains(label)) || (d.isNotEmpty() && d.contains(label))) {
                return bestCard(n)
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return null
    }

    /** Sube por los padres hasta quedarse con el contenedor de la tarjeta (sin llegar a toda la pantalla). */
    private fun bestCard(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        val dm = resources.displayMetrics
        val screenArea = dm.widthPixels.toLong() * dm.heightPixels
        var best = n
        var cur: AccessibilityNodeInfo? = n.parent
        var i = 0
        val r = Rect()
        while (cur != null && i < 4) {
            cur.getBoundsInScreen(r)
            if (r.width().toLong() * r.height() > screenArea * 0.7) break
            best = cur
            cur = cur.parent
            i++
        }
        return best
    }

    /** Intenta descartar la tarjeta con las acciones de accesibilidad que ofrezca el launcher. */
    private fun tryDismiss(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 4) {
            val actions = n.actionList
            if (actions.any { it.id == AccessibilityNodeInfo.ACTION_DISMISS } &&
                n.performAction(AccessibilityNodeInfo.ACTION_DISMISS)
            ) return true

            val custom = actions.firstOrNull {
                val l = it.label?.toString()?.lowercase() ?: ""
                l.contains("cerrar") || l.contains("close") || l.contains("dismiss") ||
                    l.contains("descartar") || l.contains("quitar")
            }
            if (custom != null && n.performAction(custom.id)) return true

            n = n.parent
            depth++
        }
        return false
    }

    /** Plan B: deslizar la tarjeta hacia arriba, como haría una persona. */
    private fun swipeUp(node: AccessibilityNodeInfo) {
        val r = Rect()
        node.getBoundsInScreen(r)
        if (r.isEmpty) return
        val path = Path().apply {
            moveTo(r.exactCenterX(), r.exactCenterY())
            lineTo(r.exactCenterX(), 5f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 180))
            .build()
        dispatchGesture(gesture, null, null)
    }

    // ------------------------------------------------------------------

    private fun appLabel(pkg: String): String =
        try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }

    private fun showBlock(title: String, subtitle: String, schedule: String, until: String) {
        startActivity(Intent(this, BlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            putExtra("title", title)
            putExtra("subtitle", subtitle)
            putExtra("schedule", schedule)
            putExtra("until", until)
        })
    }

    private fun blockProtected(pkg: String) {
        closeAndBlock(
            pkg,
            "Pantalla protegida",
            "El modo estricto está activo. Para cambiarlo, abre Bloqueador e ingresa tu contraseña.",
            "",
            ""
        )
    }

    /** Revisión diferida: mira lo que hay en pantalla ahora mismo. */
    private fun recheck(pkg: String) {
        if (busy || !StrictMode.isEnabled(this)) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return
        val text = screenText(root)
        val why = textReason(text)
        DebugLog.add("revisión: ${text.take(90)}")
        if (why != null) {
            DebugLog.add("BLOQUEO ($why)")
            blockProtected(pkg)
        }
    }

    /** La pantalla de Ajustes del propio servicio muestra el nombre «Bloqueador». */
    private fun textReason(text: String): String? =
        if (text.contains("bloqueador")) "texto: bloqueador" else null

    /** Texto del elemento tocado (y de sus padres cercanos), p. ej. la fila «Accesibilidad». */
    private fun clickedText(event: AccessibilityEvent): String {
        val sb = StringBuilder(event.text.joinToString(" "))
        var n: AccessibilityNodeInfo? = event.source
        var i = 0
        while (n != null && i < 4) {
            n.text?.let { sb.append(' ').append(it) }
            n.contentDescription?.let { sb.append(' ').append(it) }
            n = n.parent
            i++
        }
        return sb.toString().lowercase()
    }

    /** Devuelve el motivo por el que esta pantalla debe cerrarse, o null si no hay que cerrarla. */
    private fun protectedReason(event: AccessibilityEvent, isState: Boolean, isClick: Boolean): String? {
        if (isClick && clickedText(event).contains("bloqueador")) return "clic: bloqueador"
        if (isState) {
            val title = event.text.joinToString(" ").lowercase()
            TIME_TITLES.firstOrNull { title.contains(it) }?.let { return "título: $it" }
        }
        val root = rootInActiveWindow ?: return null
        if (root.packageName?.toString() != event.packageName?.toString()) return null
        return textReason(screenText(root))
    }

    private fun screenText(root: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || count > 500 || depth > 25) return
            count++
            n.text?.let { sb.append(it).append(' ') }
            n.contentDescription?.let { sb.append(it).append(' ') }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return sb.toString().lowercase()
    }

    override fun onInterrupt() {}

    private fun isProtectedPackage(pkg: String): Boolean =
        pkg in PROTECTED_PACKAGES || pkg.endsWith(".settings") || pkg.contains(".settings.")

    companion object {
        private val PROTECTED_PACKAGES = setOf(
            "com.miui.securitycenter",
            "com.android.permissioncontroller",
            "com.google.android.permissioncontroller",
            "com.android.settings",
            "com.android.packageinstaller",
            "com.google.android.packageinstaller",
            "com.samsung.android.packageinstaller",
            "com.miui.packageinstaller",
            "com.android.vending"
        )
        private val TIME_TITLES = listOf(
            "fecha y hora", "hora y fecha", "zona horaria",
            "date & time", "date and time", "time zone"
        )
    }
}
