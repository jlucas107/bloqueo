package com.example.bloqueador

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Se dispara cada vez que cambia la ventana en primer plano.
 * Si la app abierta está en un horario activo, muestra la pantalla de bloqueo.
 * Cuando el horario termina, simplemente deja de bloquear: el desbloqueo es automático.
 */
class BlockerService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        val schedule = ScheduleStore.activeScheduleFor(this, pkg) ?: return

        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }

        startActivity(Intent(this, BlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            putExtra("app", label)
            putExtra("until", formatMinutes(schedule.endMin))
            putExtra("schedule", schedule.name)
        })
    }

    override fun onInterrupt() {}
}
