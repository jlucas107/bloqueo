# Bloqueador

App de Android (Kotlin + Jetpack Compose) que bloquea apps en días y horas elegidos y las
desbloquea sola al terminar el horario.

## Modo estricto
- Protección contra desinstalación (administrador del dispositivo).
- Contraseña para entrar a la app, editar horarios o desactivar el modo.
- Hora a prueba de manipulación (reloj de confianza + hora de internet).
- Bloquea pantallas de Ajustes/instalador que muestren "Bloqueador" y las de Fecha y hora.

## Compilar
Sube Bloqueador.zip a un repositorio de GitHub: la pestaña Actions genera el APK.
La firma es fija (app/debug.keystore), así que las versiones nuevas se instalan encima de las anteriores.

## Auto-reparación de Accesibilidad (v1.1)
Android no permite impedir que apaguen un servicio de accesibilidad, pero con el permiso
`WRITE_SECURE_SETTINGS` la app lo vuelve a encender al instante (con el modo estricto activo).
Se concede una sola vez, con el teléfono conectado por USB:

    adb shell pm grant com.example.bloqueador android.permission.WRITE_SECURE_SETTINGS

Además, con el modo estricto activo se bloquean las pantallas de Accesibilidad de Ajustes.
Para apagar Accesibilidad a propósito: desactiva primero el modo estricto con tu contraseña.
