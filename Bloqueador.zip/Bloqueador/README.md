# Bloqueador

App de Android (Kotlin + Jetpack Compose) que bloquea apps en días y horas elegidos y las
desbloquea sola al terminar el horario.

## Modo estricto
- Protección contra desinstalación (administrador del dispositivo).
- Contraseña para entrar a la app, editar horarios o desactivar el modo.
- Hora a prueba de manipulación (reloj de confianza + hora de internet).
- Bloquea pantallas de Ajustes/instalador que muestren "Bloqueador" y las de Fecha y hora y DNS privado.

## Compilar
Sube Bloqueador.zip a un repositorio de GitHub: la pestaña Actions genera el APK.
La firma es fija (app/debug.keystore), así que las versiones nuevas se instalan encima de las anteriores.

## Protección de Accesibilidad
Con el modo estricto activo, si entras en Ajustes a la pantalla de Accesibilidad de Bloqueador (o a
cualquiera que muestre «Bloqueador»), la app la cierra y te manda al inicio. También bloquea Fecha y hora.
Para apagar Accesibilidad a propósito: desactiva primero el modo estricto con tu contraseña.
La pestaña Protección tiene un cuadro «Diagnóstico» con lo que detecta el servicio.

## Sitios web y contenido para adultos
La pestaña «Sitios web» permite:
- Activar el filtro de contenido para adultos (sitios conocidos, palabras clave en la dirección y búsquedas).
- Añadir tus propios sitios bloqueados (se bloquean también sus subdominios).

Funciona leyendo la barra de direcciones de los navegadores (Chrome, Firefox, Samsung Internet, Edge, Brave,
Opera, DuckDuckGo y cualquier otro que abra enlaces https). Al detectar un sitio bloqueado, el navegador pasa a
una pestaña segura y aparece el aviso. Con el modo estricto, quitar sitios requiere tu contraseña; añadir sitios también se puede desde la pantalla de entrada.
Limitaciones: no ve las páginas abiertas dentro de otras apps (WebView) ni si la barra de direcciones está oculta.
Para cubrir todas las apps, usa además DNS privado (family.adguard-dns.com (también bloquea anuncios)), como indica la pestaña.

Con el modo estricto activo, la pantalla de DNS privado también queda protegida: configura el DNS antes de activarlo.

## Cierre inmediato de Ajustes (v2.1)
Al detectar que alguien entra a la pantalla de Accesibilidad de Bloqueador (modo estricto), el servicio
tapa la pantalla al instante con una capa que bloquea los toques, va al inicio, cierra los procesos de
Ajustes (incluido el paquete de Accesibilidad de Samsung), descarta sus tarjetas de Recientes y muestra el aviso.

## Desactivación con espera de 24 horas (v2.2)
La contraseña ya no apaga el modo estricto al instante: solo **pide** la desactivación.
- Durante 24 horas todo sigue protegido y la pestaña Protección muestra cuánto falta. Puedes cancelar la solicitud en cualquier momento (sin contraseña).
- Pasadas las 24 horas aparece «Desactivar ahora» (pide la contraseña otra vez). Tienes 24 horas para usarlo; si no, la solicitud caduca y hay que empezar de nuevo.
- La espera usa el reloj de confianza, así que cambiar la hora del teléfono no la acorta.

## Bloqueo por horario aunque la app ya esté abierta (v2.2)
Antes solo se revisaba el horario al cambiar de pantalla. Ahora también se revisa la app abierta cada 15 segundos
y mientras la usas (como máximo cada 4 segundos), así que si el horario empieza con Instagram abierto, se cierra igual.

## Batería, alertas y propietario del dispositivo (v2.3)
- **Batería sin restricciones:** en Protección, «Permitir» abre el diálogo de Android para que el ahorro de batería no apague a Bloqueador. Funciona también con el modo estricto activo (el servicio deja pasar solo ese diálogo durante 30 s).
- **Alertas de manipulación:** si hubo un arranque sin Bloqueador (posible modo seguro), si el servicio estuvo apagado 3 min o más sin reiniciar, o si se quitó la anti-desinstalación, aparece un aviso rojo en Protección.
- **Propietario del dispositivo (adb):** con el modo estricto activo, Android bloquea el modo seguro, el restablecimiento desde Ajustes, añadir usuarios, desinstalar/detener Bloqueador, cambiar la hora, configurar VPN y (opcional) el DNS, que se fija en family.adguard-dns.com. Opcionalmente también las opciones de desarrollador. Todo se levanta al desactivar el modo estricto (tras la espera de 24 h).

### Cómo activar el propietario del dispositivo
1. Instala esta versión y abre la app una vez.
2. Ajustes → Cuentas: quita todas las cuentas (Google, Samsung…). En Samsung borra también la Carpeta segura y Dual Messenger si los usas (crean usuarios extra y Android no lo permite).
3. Activa la depuración USB, conecta el teléfono y ejecuta:
   `adb shell dpm set-device-owner com.example.bloqueador/.AdminReceiver`
   Debe responder «Success».
4. Vuelve a añadir tus cuentas y abre Bloqueador: en Protección verás «Propietario del dispositivo» en verde.
Nota: el restablecimiento desde el modo recuperación (botones físicos) no se puede bloquear, pero borra todo el teléfono.

## Instalar en un celular nuevo (v2.4)
**Sin PC:** instala el APK y ábrelo. El asistente de configuración te lleva paso a paso (unos 2 minutos):
Accesibilidad (incluye cómo «Permitir ajustes restringidos» en Android 13+), batería, anti-desinstalación y DNS familiar.
Al final, activa el modo estricto en Protección.

**Con PC (recomendado, más protección):** la descarga de GitHub Actions trae `Bloqueador.apk` e `instalar.bat`.
1. En el celular activa la Depuración USB y conéctalo.
2. Pon la carpeta `platform-tools` (adb) junto a `instalar.bat`, o tenla instalada.
3. Doble clic en `instalar.bat`. Instala la app, da el permiso especial, quita las restricciones de batería,
   activa la Accesibilidad y (si quieres) pone el DNS familiar. No pide quitar cuentas.

**Permiso especial** (WRITE_SECURE_SETTINGS): con el modo estricto activo, si alguien apaga la Accesibilidad,
Bloqueador la vuelve a encender sola (al instante, al reiniciar y cada 15 min), y mantiene el DNS familiar y la hora automática.

**Llevar la configuración:** Protección → «Llevar a otro celular» → Exportar. En el otro celular, Importar (también desde el asistente).
Importar solo añade horarios y sitios, nunca borra. La contraseña no se copia.

El propietario del dispositivo (sección anterior) queda como opción avanzada; `instalar.bat` también lo ofrece al final.

## Espera elegible (v2.5)
Al activar el modo estricto eliges cuánto tarda en poder desactivarse: 1 min (para pruebas), 1 h o 24 h.
Con el modo estricto activo no se puede cambiar; para cambiarla, desactívalo (cumpliendo la espera) y actívalo de nuevo con otra.
