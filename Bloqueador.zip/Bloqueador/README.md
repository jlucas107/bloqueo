# Bloqueador

App de Android (Kotlin + Jetpack Compose) que bloquea apps en días y horas elegidos, bloquea sitios web y
contenido para adultos, y se protege para que no se pueda desactivar ni desinstalar fácilmente.

## Compilar
Sube el contenido de esta carpeta a un repositorio de GitHub: la pestaña Actions genera el APK
(descarga «Bloqueador-apk»). La firma es fija (app/debug.keystore), así que las versiones nuevas se instalan
encima de las anteriores sin perder horarios ni contraseña.

## Instalar en un celular
Instala el APK y ábrelo. El asistente de configuración te lleva paso a paso (unos 2 minutos):
Accesibilidad (incluye cómo «Permitir ajustes restringidos» en Android 13+), batería sin restricciones,
anti-desinstalación y DNS familiar (family.adguard-dns.com). Al final, activa el modo estricto en Protección.
Para traer tus horarios de otro celular: Protección → «Llevar a otro celular» → Exportar allá e Importar aquí.

## Pestañas
- **Horarios:** el reloj del día muestra cada horario como un arco de su color y la aguja ámbar marca la hora actual.
  Las tarjetas de abajo usan el mismo color que su arco.
- **Protección:** medidor de capas activas (Accesibilidad, Batería, Anti-desinstalación, DNS familiar, Modo estricto),
  alertas si alguien se saltó la protección, modo estricto y copia de configuración.
- **Sitios web:** filtro de contenido para adultos y tu lista de sitios bloqueados (con subdominios).

## Modo estricto
- Contraseña para entrar a la app.
- Protege la pantalla de Accesibilidad de Bloqueador, la anti-desinstalación, Fecha y hora y DNS privado.
- Hora a prueba de cambios (reloj de confianza + hora de internet).
- Desactivarlo no es inmediato: la contraseña solo pide la desactivación y hay que esperar el tiempo elegido
  al activarlo (1 min para pruebas, 1 h o 24 h). Pasada la espera hay 24 h para confirmarlo; si no, caduca.

## Detección de manipulación
Aviso rojo en Protección si hubo un arranque sin Bloqueador (posible modo seguro), si el servicio estuvo
apagado 3 min o más sin reiniciar, o si se quitó la anti-desinstalación con el modo estricto activo.

## Diseño (v3.0)
- Colores: Noche #151B3D (encabezados, pantalla de bloqueo), Niebla #F1F2F7 (fondo), Cobalto #3446D4 (acciones),
  Ámbar #F2A93B (solo para el «ahora»).
- Fuentes: Bricolage Grotesque (títulos y horas) y Figtree (texto), ambas con licencia SIL Open Font License
  (ver LICENCIA_FUENTES_*.txt).

## Notas
- Las versiones 2.3 y 2.4 tenían funciones con adb (propietario del dispositivo y permiso especial). Se quitaron;
  si quedó activo el propietario del dispositivo, la app lo retira sola al abrirse.
- Limitación del filtro web: no ve las páginas abiertas dentro de otras apps; para eso está el DNS familiar.

## v3.1
- Se quitó la pantalla de Diagnóstico.
- **Categorías de apps:** en el editor, las apps salen agrupadas (Redes sociales, Juegos, Videos, Mensajería,
  Navegadores, Música, Compras, Noticias, Fotos, Estudio y trabajo, Otras), con filtros y un botón
  «Elegir todas» por categoría. Se clasifican con una lista de apps conocidas, la categoría que declara cada app
  y pistas en el nombre del paquete.
- **Rendimiento:** la revisión de la barra de direcciones va en un hilo aparte, espera a que termine el scroll
  (máximo una vez cada 1,5 s), recuerda dónde está la barra en cada navegador y no recorre la página web.
  Los horarios se guardan en memoria y el editor ya no carga todos los íconos al abrirse.
