# Bloqueador

App de Android (Kotlin + Jetpack Compose) que bloquea apps en días y horas elegidos,
y las desbloquea sola al terminar el horario.

## Cómo abrirla
1. Abre Android Studio (Koala o más reciente) -> File > Open -> carpeta `Bloqueador`.
2. Espera a que Gradle sincronice (descarga todo solo).
3. Conecta tu teléfono (depuración USB) o usa un emulador y pulsa Run.

## Primer uso
1. Abre la app y pulsa "Abrir Accesibilidad" -> activa "Bloqueador".
2. Crea un horario: nombre, días, hora de inicio/fin y apps.
3. Prueba con un rango que incluya la hora actual.
