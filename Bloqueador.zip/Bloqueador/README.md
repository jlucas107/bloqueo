# Bloqueador

App de Android (Kotlin + Jetpack Compose) que bloquea apps en días y horas elegidos y las
desbloquea sola al terminar el horario.

## Modo estricto
- Protección contra desinstalación (administrador del dispositivo).
- Contraseña para entrar a la app, editar horarios o desactivar el modo.
- Hora a prueba de manipulación (reloj de confianza + hora de internet).
- Bloquea pantallas de Ajustes/instalador que muestren "Bloqueador" y las de Fecha y hora.

## Compilar
Sube Bloqueador.zip a un repositorio de GitHub: la pestaña Actions genera el APK.
La firma es fija (app/debug.keystore), así que las versiones nuevas se instalan encima de las anteriores.

## Protección de Accesibilidad
Con el modo estricto activo, si entras en Ajustes a la pantalla de Accesibilidad de Bloqueador (o a
cualquiera que muestre «Bloqueador»), la app la cierra y te manda al inicio. También bloquea Fecha y hora.
Para apagar Accesibilidad a propósito: desactiva primero el modo estricto con tu contraseña.
La pestaña Protección tiene un cuadro «Diagnóstico» con lo que detecta el servicio.
