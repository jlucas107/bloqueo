# Bloqueador

App de Android (Kotlin + Jetpack Compose) que bloquea apps en días y horas elegidos y las
desbloquea sola al terminar el horario.

## Modo estricto
- Protección contra desinstalación (administrador del dispositivo).
- Contraseña para entrar a la app, editar horarios o desactivar el modo.
- Hora a prueba de manipulación (reloj de confianza + hora de internet).
- Bloquea pantallas de Ajustes/instalador que muestren "Bloqueador" y las de Fecha y hora y DNS privado.

## Compilar
Sube Bloqueador.zip a un repositorio de GitHub: la pestaña Actions genera el APK.
La firma es fija (app/debug.keystore), así que las versiones nuevas se instalan encima de las anteriores.

## Protección de Accesibilidad
Con el modo estricto activo, si entras en Ajustes a la pantalla de Accesibilidad de Bloqueador (o a
cualquiera que muestre «Bloqueador»), la app la cierra y te manda al inicio. También bloquea Fecha y hora.
Para apagar Accesibilidad a propósito: desactiva primero el modo estricto con tu contraseña.
La pestaña Protección tiene un cuadro «Diagnóstico» con lo que detecta el servicio.

## Sitios web y contenido para adultos
La pestaña «Sitios web» permite:
- Activar el filtro de contenido para adultos (sitios conocidos, palabras clave en la dirección y búsquedas).
- Añadir tus propios sitios bloqueados (se bloquean también sus subdominios).

Funciona leyendo la barra de direcciones de los navegadores (Chrome, Firefox, Samsung Internet, Edge, Brave,
Opera, DuckDuckGo y cualquier otro que abra enlaces https). Al detectar un sitio bloqueado, el navegador pasa a
una pestaña segura y aparece el aviso. Con el modo estricto, quitar sitios requiere tu contraseña; añadir sitios también se puede desde la pantalla de entrada.
Limitaciones: no ve las páginas abiertas dentro de otras apps (WebView) ni si la barra de direcciones está oculta.
Para cubrir todas las apps, usa además DNS privado (family.adguard-dns.com (también bloquea anuncios)), como indica la pestaña.

Con el modo estricto activo, la pantalla de DNS privado también queda protegida: configura el DNS antes de activarlo.

## Cierre inmediato de Ajustes (v2.1)
Al detectar que alguien entra a la pantalla de Accesibilidad de Bloqueador (modo estricto), el servicio
tapa la pantalla al instante con una capa que bloquea los toques, va al inicio, cierra los procesos de
Ajustes (incluido el paquete de Accesibilidad de Samsung), descarta sus tarjetas de Recientes y muestra el aviso.
